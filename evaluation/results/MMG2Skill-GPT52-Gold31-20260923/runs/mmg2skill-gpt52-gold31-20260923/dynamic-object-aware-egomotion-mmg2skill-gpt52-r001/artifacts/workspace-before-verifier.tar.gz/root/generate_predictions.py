import json
import math
from dataclasses import dataclass
from typing import Dict, List, Tuple

import cv2
import numpy as np


VALID_LABELS = {
    "Stay",
    "Dolly In",
    "Dolly Out",
    "Pan Left",
    "Pan Right",
    "Tilt Up",
    "Tilt Down",
    "Roll Left",
    "Roll Right",
}


@dataclass
class Transform:
    # 2x3 affine mapping prev -> curr
    M: np.ndarray


def read_frame(cap: cv2.VideoCapture, frame_id: int) -> np.ndarray:
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_id)
    ok, frame = cap.read()
    if not ok or frame is None:
        raise RuntimeError(f"Failed to read frame {frame_id}")
    return frame


def estimate_affine(prev_gray: np.ndarray, curr_gray: np.ndarray) -> Transform:
    prev_pts = cv2.goodFeaturesToTrack(
        prev_gray,
        maxCorners=800,
        qualityLevel=0.01,
        minDistance=8,
        blockSize=7,
    )
    if prev_pts is None or len(prev_pts) < 20:
        return Transform(np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32))

    curr_pts, st, _err = cv2.calcOpticalFlowPyrLK(
        prev_gray,
        curr_gray,
        prev_pts,
        None,
        winSize=(21, 21),
        maxLevel=3,
        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01),
    )

    if curr_pts is None or st is None:
        return Transform(np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32))

    st = st.reshape(-1).astype(bool)
    prev_in = prev_pts.reshape(-1, 2)[st]
    curr_in = curr_pts.reshape(-1, 2)[st]
    if prev_in.shape[0] < 20:
        return Transform(np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32))

    M, _inliers = cv2.estimateAffinePartial2D(
        prev_in,
        curr_in,
        method=cv2.RANSAC,
        ransacReprojThreshold=3.0,
        maxIters=2000,
        confidence=0.99,
        refineIters=10,
    )
    if M is None:
        M = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32)
    return Transform(M.astype(np.float32))


def affine_params(M: np.ndarray) -> Tuple[float, float, float, float]:
    a, b, tx = float(M[0, 0]), float(M[0, 1]), float(M[0, 2])
    c, d, ty = float(M[1, 0]), float(M[1, 1]), float(M[1, 2])
    scale = math.sqrt(a * a + c * c)
    rot = math.atan2(c, a)
    dx, dy = tx, ty
    return dx, dy, rot, scale


def median_filter_1d(x: np.ndarray, k: int = 3) -> np.ndarray:
    assert k % 2 == 1
    r = k // 2
    y = x.copy()
    for i in range(len(x)):
        lo = max(0, i - r)
        hi = min(len(x), i + r + 1)
        y[i] = float(np.median(x[lo:hi]))
    return y


def labels_from_params(dx: float, dy: float, rot: float, scale: float) -> List[str]:
    labels: List[str] = []

    scale_thr = 0.015
    trans_thr = 3.0
    rot_thr = 0.01

    if abs(scale - 1.0) > scale_thr:
        labels.append("Dolly In" if scale > 1.0 else "Dolly Out")

    if abs(dx) > trans_thr:
        # Image shifts right when camera pans left.
        labels.append("Pan Left" if dx > 0 else "Pan Right")

    if abs(dy) > trans_thr:
        # Image shifts down when camera tilts up.
        labels.append("Tilt Up" if dy > 0 else "Tilt Down")

    if abs(rot) > rot_thr:
        labels.append("Roll Left" if rot > 0 else "Roll Right")

    if not labels:
        labels = ["Stay"]

    return labels


def compress_intervals(per_sample_labels: List[List[str]]) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    S = len(per_sample_labels)
    start = 0
    curr = tuple(per_sample_labels[0])
    for i in range(1, S):
        nxt = tuple(per_sample_labels[i])
        if nxt != curr:
            out[f"{start}->{i}"] = list(curr)
            start = i
            curr = nxt
    out[f"{start}->{S}"] = list(curr)
    return out


def robust_threshold(diff_vals: np.ndarray) -> float:
    if diff_vals.size == 0:
        return 255.0
    med = float(np.median(diff_vals))
    mad = float(np.median(np.abs(diff_vals - med)))
    thr = med + 3.0 * 1.4826 * mad
    return max(thr, 12.0)


def mask_to_csr(mask: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    H, W = mask.shape
    rows, cols = np.nonzero(mask)
    if rows.size == 0:
        data = np.empty((0,), dtype=np.uint8)
        indices = np.empty((0,), dtype=np.int32)
        indptr = np.zeros((H + 1,), dtype=np.int32)
        return data, indices, indptr

    order = np.lexsort((cols, rows))
    rows = rows[order]
    cols = cols[order]

    indices = cols.astype(np.int32, copy=False)
    data = np.ones((indices.size,), dtype=np.uint8)
    counts = np.bincount(rows, minlength=H).astype(np.int32, copy=False)
    indptr = np.concatenate(([0], np.cumsum(counts))).astype(np.int32, copy=False)
    return data, indices, indptr


def main() -> None:
    video_path = "/root/input.mp4"
    target_fps = 5

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise SystemExit(f"Cannot open {video_path}")

    src_fps = float(cap.get(cv2.CAP_PROP_FPS))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    step = max(1, int(round(src_fps / target_fps)))
    sample_frame_ids = list(range(0, total_frames, step))
    S = len(sample_frame_ids)

    frames_gray: List[np.ndarray] = []
    for fid in sample_frame_ids:
        frame = read_frame(cap, fid)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        frames_gray.append(gray)
    cap.release()

    transforms: List[Transform] = [Transform(np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32))]
    dx = np.zeros((S,), dtype=np.float32)
    dy = np.zeros((S,), dtype=np.float32)
    rot = np.zeros((S,), dtype=np.float32)
    scale = np.ones((S,), dtype=np.float32)

    for i in range(1, S):
        t = estimate_affine(frames_gray[i - 1], frames_gray[i])
        transforms.append(t)
        dxi, dyi, ri, si = affine_params(t.M)
        dx[i], dy[i], rot[i], scale[i] = dxi, dyi, ri, si

    dx_s = median_filter_1d(dx, 3)
    dy_s = median_filter_1d(dy, 3)
    rot_s = median_filter_1d(rot, 3)
    scale_s = median_filter_1d(scale, 3)

    per_sample_labels: List[List[str]] = []
    for i in range(S):
        if i == 0:
            per_sample_labels.append(["Stay"])
        else:
            per_sample_labels.append(labels_from_params(float(dx_s[i]), float(dy_s[i]), float(rot_s[i]), float(scale_s[i])))

    intervals = compress_intervals(per_sample_labels)

    json_path = "/root/pred_instructions.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(intervals, f, indent=2, sort_keys=True)

    # Dynamic masks
    npz_out: Dict[str, np.ndarray] = {}
    npz_out["shape"] = np.array([H, W], dtype=np.int32)

    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    ones = np.full((H, W), 255, dtype=np.uint8)
    min_area = int(0.0003 * H * W)  # ~277 for 720p

    for i in range(S):
        if i == 0:
            mask = np.zeros((H, W), dtype=bool)
        else:
            M = transforms[i].M
            warped_prev = cv2.warpAffine(
                frames_gray[i - 1],
                M,
                (W, H),
                flags=cv2.INTER_LINEAR,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0,
            )
            valid = cv2.warpAffine(
                ones,
                M,
                (W, H),
                flags=cv2.INTER_NEAREST,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0,
            )
            valid = valid > 0

            diff = cv2.absdiff(frames_gray[i], warped_prev)
            thr = robust_threshold(diff[valid].astype(np.float32))

            raw = (diff.astype(np.float32) > thr) & valid
            raw_u8 = (raw.astype(np.uint8) * 255)
            raw_u8 = cv2.morphologyEx(raw_u8, cv2.MORPH_OPEN, kernel, iterations=1)
            raw_u8 = cv2.morphologyEx(raw_u8, cv2.MORPH_CLOSE, kernel, iterations=1)

            n, lbl, stats, _cent = cv2.connectedComponentsWithStats(raw_u8, connectivity=8)
            keep = np.zeros((n,), dtype=bool)
            keep[0] = False
            for k in range(1, n):
                if int(stats[k, cv2.CC_STAT_AREA]) >= min_area:
                    keep[k] = True

            mask = keep[lbl]

        data, indices, indptr = mask_to_csr(mask)
        npz_out[f"f_{i}_data"] = data
        npz_out[f"f_{i}_indices"] = indices
        npz_out[f"f_{i}_indptr"] = indptr

    npz_path = "/root/pred_dyn_masks.npz"
    np.savez_compressed(npz_path, **npz_out)

    # Validation (per output-validation skill)
    j = json.load(open(json_path, "r", encoding="utf-8"))
    npz = np.load(npz_path)

    import re

    pat = re.compile(r"^(\d+)->(\d+)$")
    for k, v in j.items():
        m = pat.match(k)
        assert m, f"Bad interval key: {k}"
        assert isinstance(v, list) and len(v) > 0, f"Bad labels at {k}"
        for lab in v:
            assert lab in VALID_LABELS, f"Invalid label {lab}"

    assert "shape" in npz, "NPZ missing shape"
    shp = np.array(npz["shape"]).astype(int)
    assert shp.shape == (2,), f"Bad shape: {shp}"
    H2, W2 = int(shp[0]), int(shp[1])
    assert H2 == H and W2 == W, "shape mismatch"

    # Determine S from NPZ keys
    S2 = 0
    while f"f_{S2}_data" in npz:
        S2 += 1
    assert S2 == S, f"NPZ frame count mismatch: {S2} vs {S}"

    # Coverage check for JSON intervals
    covered = np.zeros((S,), dtype=np.uint8)
    for k in j.keys():
        a, b = map(int, k.split("->"))
        assert 0 <= a < b <= S
        covered[a:b] += 1
    assert covered.min() == 1 and covered.max() == 1, "Intervals do not exactly cover [0,S)"

    for i in range(S):
        data = npz[f"f_{i}_data"]
        indices = npz[f"f_{i}_indices"]
        indptr = npz[f"f_{i}_indptr"]
        assert len(indptr) == H + 1
        assert int(indptr[-1]) == int(indices.size) == int(data.size)
        if indices.size:
            assert indices.min() >= 0 and indices.max() < W


if __name__ == "__main__":
    main()
