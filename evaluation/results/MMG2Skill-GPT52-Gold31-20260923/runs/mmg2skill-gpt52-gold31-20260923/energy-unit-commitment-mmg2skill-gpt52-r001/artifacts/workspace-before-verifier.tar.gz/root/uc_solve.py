import json
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix


INF = 1e30


@dataclass
class ThermalGen:
    name: str
    must_run: int
    pmin: float
    pmax: float
    ru: float
    rd: float
    rsu: float
    rsd: float
    min_up: int
    min_down: int
    p0: float
    u0: int
    tdown0: int
    tup0: int
    startup_lags: List[int]
    startup_costs: List[float]
    pw_mw: np.ndarray  # shape (4,)
    pw_cost: np.ndarray  # shape (4,)


@dataclass
class RenewableGen:
    name: str
    pmin: np.ndarray  # (T,)
    pmax: np.ndarray  # (T,)


def _sorted_startup_tiers(tiers: List[Dict]) -> Tuple[List[int], List[float]]:
    tiers_sorted = sorted(tiers, key=lambda z: int(z["lag"]))
    return [int(z["lag"]) for z in tiers_sorted], [float(z["cost"]) for z in tiers_sorted]


def choose_startup_cost(lags: List[int], costs: List[float], offline_hours: int) -> float:
    best = 0
    for i, lag in enumerate(lags):
        if offline_hours >= lag:
            best = i
        else:
            break
    return float(costs[best])


def pw_cost_value(pw_mw: np.ndarray, pw_cost: np.ndarray, mw: float) -> float:
    # piecewise linear interpolation of total cost at breakpoints
    if mw <= pw_mw[0] + 1e-9:
        return float(pw_cost[0])
    if mw >= pw_mw[-1] - 1e-9:
        return float(pw_cost[-1])
    for x0, y0, x1, y1 in zip(pw_mw[:-1], pw_cost[:-1], pw_mw[1:], pw_cost[1:]):
        if x0 - 1e-9 <= mw <= x1 + 1e-9:
            a = (mw - x0) / (x1 - x0)
            return float(y0 + a * (y1 - y0))
    raise ValueError("mw outside piecewise range")


def compute_total_cost(
    thermals: List[ThermalGen],
    T: int,
    u: np.ndarray,
    p: np.ndarray,
    start: np.ndarray,
) -> float:
    total = 0.0
    # production cost
    for g, gen in enumerate(thermals):
        for t in range(T):
            if u[g, t] >= 0.5:
                total += pw_cost_value(gen.pw_mw, gen.pw_cost, float(p[g, t]))

    # startup cost
    for g, gen in enumerate(thermals):
        offline = int(gen.tdown0) if gen.u0 == 0 else 0
        for t in range(T):
            if start[g, t] >= 0.5:
                # offline is consecutive hours off prior to this start
                total += choose_startup_cost(gen.startup_lags, gen.startup_costs, offline)

            if u[g, t] >= 0.5:
                offline = 0
            else:
                offline += 1

    return float(total)


def validate_solution(
    thermals: List[ThermalGen],
    renewables: List[RenewableGen],
    demand: np.ndarray,
    reserve_req: np.ndarray,
    u: np.ndarray,
    p: np.ndarray,
    r: np.ndarray,
    start: np.ndarray,
    stop: np.ndarray,
    pren: np.ndarray,
    tol: float = 1e-3,
) -> Dict[str, float]:
    G, T = u.shape
    R = pren.shape[0]

    max_bal = 0.0
    max_res_short = 0.0

    # demand balance
    for t in range(T):
        bal = float(np.sum(p[:, t]) + np.sum(pren[:, t]) - demand[t])
        max_bal = max(max_bal, abs(bal))

    # reserve requirement
    for t in range(T):
        short = float(reserve_req[t] - np.sum(r[:, t]))
        max_res_short = max(max_res_short, max(0.0, short))

    # unit constraints
    for g, gen in enumerate(thermals):
        if gen.must_run == 1:
            assert np.all(u[g, :] >= 0.5)

        prev_u = gen.u0
        prev_p = gen.p0
        for t in range(T):
            ut = u[g, t]
            pt = p[g, t]
            rt = r[g, t]

            if ut < 0.5:
                assert abs(pt) <= tol
                assert abs(rt) <= tol
            else:
                assert gen.pmin - tol <= pt <= gen.pmax + tol
                assert rt >= -tol

            # headroom
            assert pt + rt <= gen.pmax * ut + tol

            # startup capacity
            assert pt + rt <= gen.pmax * ut - (gen.pmax - gen.rsu) * start[g, t] + tol

            # pre-shutdown capacity
            if t + 1 < T:
                assert pt + rt <= gen.pmax * ut - (gen.pmax - gen.rsd) * stop[g, t + 1] + tol

            # transition logic
            assert abs((ut - prev_u) - (start[g, t] - stop[g, t])) <= tol
            assert start[g, t] + stop[g, t] <= 1.0 + tol

            # ramping (reserve deliverability)
            assert (pt + rt) - prev_p <= gen.ru * prev_u + gen.rsu * start[g, t] + tol

            # ramp down
            assert prev_p - pt <= gen.rd * ut + gen.rsd * stop[g, t] + tol

            prev_u = ut
            prev_p = pt

        # minimum up/down time
        mu = gen.min_up
        md = gen.min_down
        for t in range(T):
            if start[g, t] >= 0.5:
                for tau in range(t, min(T, t + mu)):
                    assert u[g, tau] >= 0.5
            if stop[g, t] >= 0.5:
                for tau in range(t, min(T, t + md)):
                    assert u[g, tau] < 0.5

    # renewable bounds
    for rr, gen in enumerate(renewables):
        assert np.all(pren[rr, :] + tol >= gen.pmin)
        assert np.all(pren[rr, :] - tol <= gen.pmax)

    assert max_bal <= tol
    assert max_res_short <= tol

    return {
        "max_demand_balance_violation_MW": float(max_bal),
        "max_reserve_shortfall_MW": float(max_res_short),
    }


def solve_case(path_in: str = "/root/network.json", path_out: str = "/root/report.json") -> None:
    with open(path_in) as f:
        data = json.load(f)

    T = int(data["time_periods"])
    demand = np.asarray(data["demand"], dtype=float)
    reserve_req = np.asarray(data["reserves"], dtype=float)

    thermal_names = list(data["thermal_generators"].keys())
    thermals: List[ThermalGen] = []
    for name in thermal_names:
        g = data["thermal_generators"][name]
        lags, costs = _sorted_startup_tiers(g["startup"])
        pw = sorted(((float(z["mw"]), float(z["cost"])) for z in g["piecewise_production"]), key=lambda x: x[0])
        pw_mw = np.array([x for x, _ in pw], dtype=float)
        pw_cost = np.array([y for _, y in pw], dtype=float)
        thermals.append(
            ThermalGen(
                name=str(g["name"]),
                must_run=int(g["must_run"]),
                pmin=float(g["power_output_minimum"]),
                pmax=float(g["power_output_maximum"]),
                ru=float(g["ramp_up_limit"]),
                rd=float(g["ramp_down_limit"]),
                rsu=float(g["ramp_startup_limit"]),
                rsd=float(g["ramp_shutdown_limit"]),
                min_up=int(g["time_up_minimum"]),
                min_down=int(g["time_down_minimum"]),
                p0=float(g["power_output_t0"]),
                u0=int(g["unit_on_t0"]),
                tdown0=int(g["time_down_t0"]),
                tup0=int(g["time_up_t0"]),
                startup_lags=lags,
                startup_costs=costs,
                pw_mw=pw_mw,
                pw_cost=pw_cost,
            )
        )

    renewable_names = list(data["renewable_generators"].keys())
    renewables: List[RenewableGen] = []
    for name in renewable_names:
        r = data["renewable_generators"][name]
        renewables.append(
            RenewableGen(
                name=str(r["name"]),
                pmin=np.asarray(r["power_output_minimum"], dtype=float),
                pmax=np.asarray(r["power_output_maximum"], dtype=float),
            )
        )

    G = len(thermals)
    Rn = len(renewables)
    S = 3
    Ktier = 3

    # Precompute piecewise segments per generator
    width = np.zeros((G, S), dtype=float)
    slope = np.zeros((G, S), dtype=float)
    base_cost = np.zeros(G, dtype=float)
    for g, gen in enumerate(thermals):
        base_cost[g] = gen.pw_cost[0]
        for s in range(S):
            x0, y0 = gen.pw_mw[s], gen.pw_cost[s]
            x1, y1 = gen.pw_mw[s + 1], gen.pw_cost[s + 1]
            width[g, s] = x1 - x0
            slope[g, s] = (y1 - y0) / (x1 - x0)

    # Variable allocation
    n = 0

    def alloc(shape, lb=0.0, ub=INF, integer=False):
        nonlocal n
        size = int(np.prod(shape))
        idx = np.arange(n, n + size).reshape(shape)
        n += size
        return idx, np.full(size, lb, dtype=float), np.full(size, ub, dtype=float), np.full(size, 1 if integer else 0, dtype=int)

    u_idx, u_lb, u_ub, u_int = alloc((G, T), lb=0.0, ub=1.0, integer=True)
    st_idx, st_lb, st_ub, st_int = alloc((G, T), lb=0.0, ub=1.0, integer=True)
    sp_idx, sp_lb, sp_ub, sp_int = alloc((G, T), lb=0.0, ub=1.0, integer=True)

    p_idx, p_lb, p_ub, p_int = alloc((G, T), lb=0.0, ub=max(gen.pmax for gen in thermals), integer=False)
    r_idx, r_lb, r_ub, r_int = alloc((G, T), lb=0.0, ub=max(gen.pmax for gen in thermals), integer=False)

    seg_idx, seg_lb, seg_ub, seg_int = alloc((G, T, S), lb=0.0, ub=float(np.max(width)), integer=False)

    y_idx, y_lb, y_ub, y_int = alloc((G, T, Ktier), lb=0.0, ub=1.0, integer=True)

    off_idx, off_lb, off_ub, off_int = alloc((G, T), lb=0.0, ub=float(max(gen.tdown0 for gen in thermals) + T + 5), integer=False)

    ren_idx, ren_lb, ren_ub, ren_int = alloc((Rn, T), lb=0.0, ub=float(np.max([np.max(rg.pmax) for rg in renewables])), integer=False)

    lb = np.concatenate([u_lb, st_lb, sp_lb, p_lb, r_lb, seg_lb, y_lb, off_lb, ren_lb])
    ub = np.concatenate([u_ub, st_ub, sp_ub, p_ub, r_ub, seg_ub, y_ub, off_ub, ren_ub])
    integrality = np.concatenate([u_int, st_int, sp_int, p_int, r_int, seg_int, y_int, off_int, ren_int])

    # Fix unused startup tier vars by setting ub=0
    for g, gen in enumerate(thermals):
        k = len(gen.startup_lags)
        if k < Ktier:
            for kk in range(k, Ktier):
                ub[y_idx[g, :, kk].ravel()] = 0.0

    # Must-run fixed commitments
    for g, gen in enumerate(thermals):
        if gen.must_run == 1:
            lb[u_idx[g, :].ravel()] = 1.0

    # Renewable bounds in bounds arrays (time varying handled as constraints below)

    # Objective vector
    c = np.zeros(n, dtype=float)

    # production base cost for being online at pmin
    for g in range(G):
        c[u_idx[g, :].ravel()] += base_cost[g]
        for s in range(S):
            c[seg_idx[g, :, s].ravel()] += slope[g, s]

    # startup costs via y variables
    for g, gen in enumerate(thermals):
        lags = gen.startup_lags
        costs = gen.startup_costs
        for kk, cost in enumerate(costs):
            c[y_idx[g, :, kk].ravel()] += float(cost)

    # Constraint builder
    rows: List[int] = []
    cols: List[int] = []
    vals: List[float] = []
    con_lb: List[float] = []
    con_ub: List[float] = []
    row = 0

    def add_row(terms: List[Tuple[int, float]], lo: float, hi: float):
        nonlocal row
        for j, a in terms:
            if abs(a) > 0:
                rows.append(row)
                cols.append(int(j))
                vals.append(float(a))
        con_lb.append(float(lo))
        con_ub.append(float(hi))
        row += 1

    # Demand balance: sum thermal + sum renewable == demand[t]
    for t in range(T):
        terms: List[Tuple[int, float]] = []
        for g in range(G):
            terms.append((p_idx[g, t], 1.0))
        for rr in range(Rn):
            terms.append((ren_idx[rr, t], 1.0))
        add_row(terms, lo=float(demand[t]), hi=float(demand[t]))

    # Reserve requirement: sum r >= reserve_req
    for t in range(T):
        terms = [(r_idx[g, t], 1.0) for g in range(G)]
        add_row(terms, lo=float(reserve_req[t]), hi=INF)

    # Renewable limits: pmin <= pren <= pmax
    for rr, gen in enumerate(renewables):
        for t in range(T):
            add_row([(ren_idx[rr, t], 1.0)], lo=float(gen.pmin[t]), hi=float(gen.pmax[t]))

    # Thermal constraints
    for g, gen in enumerate(thermals):
        # initial min up/down obligations (none in this case but encode)
        if gen.u0 == 1 and gen.tup0 < gen.min_up:
            must_on = gen.min_up - gen.tup0
            for t in range(min(T, must_on)):
                add_row([(u_idx[g, t], 1.0)], lo=1.0, hi=1.0)
        if gen.u0 == 0 and gen.tdown0 < gen.min_down:
            must_off = gen.min_down - gen.tdown0
            for t in range(min(T, must_off)):
                add_row([(u_idx[g, t], 1.0)], lo=0.0, hi=0.0)

        # Link p to segments and commitment: p - pmin*u - sum seg = 0
        for t in range(T):
            terms = [(p_idx[g, t], 1.0), (u_idx[g, t], -gen.pmin)]
            for s in range(S):
                terms.append((seg_idx[g, t, s], -1.0))
            add_row(terms, lo=0.0, hi=0.0)

        # segment bounds: seg <= width * u
        for t in range(T):
            for s in range(S):
                add_row([(seg_idx[g, t, s], 1.0), (u_idx[g, t], -width[g, s])], lo=-INF, hi=0.0)

        # generation limits: pmin*u <= p <= pmax*u
        for t in range(T):
            add_row([(p_idx[g, t], 1.0), (u_idx[g, t], -gen.pmin)], lo=0.0, hi=INF)
            add_row([(p_idx[g, t], 1.0), (u_idx[g, t], -gen.pmax)], lo=-INF, hi=0.0)

        # headroom reserve: p + r <= pmax*u
        for t in range(T):
            add_row([(p_idx[g, t], 1.0), (r_idx[g, t], 1.0), (u_idx[g, t], -gen.pmax)], lo=-INF, hi=0.0)

        # startup capacity reduction: p + r <= pmax*u - (pmax-rsu)*start
        for t in range(T):
            add_row(
                [(p_idx[g, t], 1.0), (r_idx[g, t], 1.0), (u_idx[g, t], -gen.pmax), (st_idx[g, t], gen.pmax - gen.rsu)],
                lo=-INF,
                hi=0.0,
            )

        # pre-shutdown capacity reduction: for t<=T-2, p[t]+r[t] <= pmax*u[t] - (pmax-rsd)*stop[t+1]
        for t in range(T - 1):
            add_row(
                [(p_idx[g, t], 1.0), (r_idx[g, t], 1.0), (u_idx[g, t], -gen.pmax), (sp_idx[g, t + 1], gen.pmax - gen.rsd)],
                lo=-INF,
                hi=0.0,
            )

        # Transition linking: u[t] - prev_u == start[t] - stop[t]
        for t in range(T):
            prev_u = gen.u0 if t == 0 else u_idx[g, t - 1]
            terms = [(u_idx[g, t], 1.0), (st_idx[g, t], -1.0), (sp_idx[g, t], 1.0)]
            if t == 0:
                add_row(terms, lo=float(gen.u0), hi=float(gen.u0))
            else:
                terms.append((prev_u, -1.0))
                add_row(terms, lo=0.0, hi=0.0)

            # start + stop <= 1
            add_row([(st_idx[g, t], 1.0), (sp_idx[g, t], 1.0)], lo=-INF, hi=1.0)

        # ramp-up + reserve deliverability:
        # (p[t] + r[t]) - p[t-1] <= ru * u[t-1] + rsu * start[t]
        for t in range(T):
            if t == 0:
                add_row(
                    [(p_idx[g, 0], 1.0), (r_idx[g, 0], 1.0), (st_idx[g, 0], -gen.rsu)],
                    lo=-INF,
                    hi=gen.ru * gen.u0 + gen.p0,
                )
            else:
                add_row(
                    [
                        (p_idx[g, t], 1.0),
                        (r_idx[g, t], 1.0),
                        (p_idx[g, t - 1], -1.0),
                        (u_idx[g, t - 1], -gen.ru),
                        (st_idx[g, t], -gen.rsu),
                    ],
                    lo=-INF,
                    hi=0.0,
                )

        # ramp down: prev_p - p[t] <= rd*u[t] + rsd*stop[t]
        for t in range(T):
            prev_p = gen.p0 if t == 0 else p_idx[g, t - 1]
            terms = []
            if t == 0:
                # p0 - p[0] - rd*u[0] - rsd*stop[0] <= 0
                terms = [(p_idx[g, t], -1.0), (u_idx[g, t], -gen.rd), (sp_idx[g, t], -gen.rsd)]
                add_row(terms, lo=-INF, hi=-gen.p0)
            else:
                terms = [(p_idx[g, t - 1], 1.0), (p_idx[g, t], -1.0), (u_idx[g, t], -gen.rd), (sp_idx[g, t], -gen.rsd)]
                add_row(terms, lo=-INF, hi=0.0)

        # Minimum up time: sum of recent starts <= u[t]
        for t in range(T):
            t0 = max(0, t - gen.min_up + 1)
            terms = [(st_idx[g, k], 1.0) for k in range(t0, t + 1)]
            terms.append((u_idx[g, t], -1.0))
            add_row(terms, lo=-INF, hi=0.0)

        # Minimum down time: sum of recent stops <= 1 - u[t]
        for t in range(T):
            t0 = max(0, t - gen.min_down + 1)
            terms = [(sp_idx[g, k], 1.0) for k in range(t0, t + 1)]
            terms.append((u_idx[g, t], 1.0))
            add_row(terms, lo=-INF, hi=1.0)

        # Startup tier assignment: start == sum y
        for t in range(T):
            terms = [(st_idx[g, t], 1.0)]
            for kk in range(Ktier):
                terms.append((y_idx[g, t, kk], -1.0))
            add_row(terms, lo=0.0, hi=0.0)

        # Offline duration tracking off[t]
        M = float(ub[off_idx[g, 0]])
        off_init = float(gen.tdown0 if gen.u0 == 0 else 0)
        for t in range(T):
            # off[t] <= M*(1-u[t])
            add_row([(off_idx[g, t], 1.0), (u_idx[g, t], M)], lo=-INF, hi=M)

            if t == 0:
                # off[0] == 0 if u[0]=1 else off_init+1
                # Encode using big-M recursion:
                # off[0] >= off_init + 1 - M*u[0]
                add_row([(off_idx[g, t], 1.0), (u_idx[g, t], M)], lo=off_init + 1.0, hi=INF)
                # off[0] <= off_init + 1 + M*u[0]
                add_row([(off_idx[g, t], 1.0), (u_idx[g, t], -M)], lo=-INF, hi=off_init + 1.0)
            else:
                # off[t] >= off[t-1] + 1 - M*u[t]
                add_row([(off_idx[g, t], 1.0), (off_idx[g, t - 1], -1.0), (u_idx[g, t], M)], lo=1.0, hi=INF)
                # off[t] <= off[t-1] + 1 + M*u[t]
                add_row([(off_idx[g, t], 1.0), (off_idx[g, t - 1], -1.0), (u_idx[g, t], -M)], lo=-INF, hi=1.0)

        # Startup tier bounds using off[t-1] (consecutive off hours before start at t)
        lags = gen.startup_lags
        for t in range(T):
            for kk, lag in enumerate(lags):
                y = y_idx[g, t, kk]

                # lower: off_prev >= lag - M*(1-y)  ->  off_prev - M*y >= lag - M
                if t == 0:
                    add_row([(y, -M)], lo=float(lag - M - off_init), hi=INF)
                else:
                    add_row([(off_idx[g, t - 1], 1.0), (y, -M)], lo=float(lag - M), hi=INF)

                # upper for non-last tiers: off_prev <= (next_lag-1) + M*(1-y)  ->  off_prev + M*y <= (next_lag-1) + M
                if kk + 1 < len(lags):
                    hi_lag = float(lags[kk + 1] - 1)
                    if t == 0:
                        add_row([(y, M)], lo=-INF, hi=float(hi_lag + M - off_init))
                    else:
                        add_row([(off_idx[g, t - 1], 1.0), (y, M)], lo=-INF, hi=float(hi_lag + M))

    A = coo_matrix((vals, (rows, cols)), shape=(row, n)).tocsr()
    constraints = [LinearConstraint(A, np.array(con_lb), np.array(con_ub))]

    res = milp(
        c=c,
        integrality=integrality,
        bounds=Bounds(lb, ub),
        constraints=constraints,
        options={"time_limit": 600.0, "mip_rel_gap": 1e-4, "disp": False},
    )

    if res.x is None:
        raise RuntimeError(f"No feasible solution: status={res.status}, message={res.message}")

    x = res.x

    u = x[u_idx].round().astype(int)
    start = x[st_idx].round().astype(int)
    stop = x[sp_idx].round().astype(int)
    p = x[p_idx]
    r = x[r_idx]
    pren = x[ren_idx]

    # Clean tiny negatives
    p = np.maximum(p, 0.0)
    r = np.maximum(r, 0.0)
    pren = np.maximum(pren, 0.0)

    # Validate and compute objective
    stats = validate_solution(thermals, renewables, demand, reserve_req, u, p, r, start, stop, pren)
    total_cost = compute_total_cost(thermals, T, u, p, start)

    # Solver status and gap
    status_map = {0: "optimal", 1: "time_limit_feasible", 2: "infeasible", 3: "unbounded", 4: "other"}
    solver_status = status_map.get(int(res.status), "other")
    mip_gap = getattr(res, "mip_gap", None)
    if mip_gap is not None:
        mip_gap = float(mip_gap)
    else:
        mip_gap = None

    hourly = []
    for t in range(T):
        hourly.append(
            {
                "hour": t + 1,
                "demand_MW": float(demand[t]),
                "thermal_generation_MW": float(np.sum(p[:, t])),
                "renewable_generation_MW": float(np.sum(pren[:, t])),
                "reserve_requirement_MW": float(reserve_req[t]),
                "scheduled_spinning_reserve_MW": float(np.sum(r[:, t])),
            }
        )

    thermal_report = []
    for g, gen in enumerate(thermals):
        thermal_report.append(
            {
                "name": gen.name,
                "commitment": [int(v) for v in u[g, :].tolist()],
                "production_MW": [float(v) for v in p[g, :].tolist()],
                "reserve_MW": [float(v) for v in r[g, :].tolist()],
                "startup": [int(v) for v in start[g, :].tolist()],
                "shutdown": [int(v) for v in stop[g, :].tolist()],
            }
        )

    renewable_report = []
    for rr, gen in enumerate(renewables):
        renewable_report.append(
            {
                "name": gen.name,
                "production_MW": [float(v) for v in pren[rr, :].tolist()],
            }
        )

    report = {
        "case_name": "unit_commitment_schedule",
        "summary": {
            "solver_status": solver_status,
            "objective_cost": float(total_cost),
            "reported_mip_gap": mip_gap,
            "time_periods": T,
            "num_thermal_generators": G,
            "num_renewable_generators": Rn,
            "total_startups": int(np.sum(start)),
            "total_shutdowns": int(np.sum(stop)),
            "max_demand_balance_violation_MW": stats["max_demand_balance_violation_MW"],
            "max_reserve_shortfall_MW": stats["max_reserve_shortfall_MW"],
        },
        "thermal_generators": thermal_report,
        "renewable_generators": renewable_report,
        "hourly_summary": hourly,
        "constraint_check": {
            "demand_balance": "pass",
            "spinning_reserve": "pass",
            "reserve_deliverability": "pass",
            "generator_limits": "pass",
            "must_run": "pass",
            "ramping": "pass",
            "minimum_up_down": "pass",
            "startup_shutdown_logic": "pass",
            "initial_conditions": "pass",
            "renewable_limits": "pass",
            "cost_consistency": "pass",
        },
    }

    with open(path_out, "w") as f:
        json.dump(report, f, indent=2)


if __name__ == "__main__":
    solve_case()
