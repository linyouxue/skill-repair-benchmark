import java.nio.charset.Charset
import java.time.{LocalDate, LocalDateTime}
import java.time.format.DateTimeFormatter
import java.util.Locale

import scala.collection.immutable

// ============================================================================
// Enums and Constants
// ============================================================================

sealed trait TokenType extends Product with Serializable {
  def value: String
}

object TokenType {
  case object STRING extends TokenType { val value: String = "string" }
  case object NUMERIC extends TokenType { val value: String = "numeric" }
  case object TEMPORAL extends TokenType { val value: String = "temporal" }
  case object STRUCTURED extends TokenType { val value: String = "structured" }
  case object BINARY extends TokenType { val value: String = "binary" }
  case object NULL extends TokenType { val value: String = "null" }
}

// ============================================================================
// Core Token Classes
// ============================================================================

final case class Token(
  value: String,
  tokenType: TokenType,
  metadata: Map[String, Any] = Map.empty
) extends Serializable {
  def withMetadata(kv: (String, Any)*): Token =
    copy(metadata = metadata ++ kv.toMap)
}

trait Tokenizable extends Serializable {
  def toToken: String
}

// ============================================================================
// Tokenizer Implementations
// ============================================================================

trait BaseTokenizer[-T] extends Serializable {
  def tokenize(value: T): Token

  def tokenizeBatch(values: Iterable[T]): Iterator[Token] =
    values.iterator.map(tokenize)
}

sealed trait StrOrBytes extends Product with Serializable

object StrOrBytes {
  final case class Str(value: String) extends StrOrBytes
  final case class Bytes(value: Array[Byte]) extends StrOrBytes

  def apply(value: String): StrOrBytes = Str(value)
  def apply(value: Array[Byte]): StrOrBytes = Bytes(value)
}

final class StringTokenizer(
  encoding: String = "utf-8",
  normalizer: String => String = identity
) extends BaseTokenizer[StrOrBytes] {

  private val charset: Charset = Charset.forName(encoding)

  override def tokenize(value: StrOrBytes): Token = {
    val strValue = value match {
      case StrOrBytes.Str(s) => s
      case StrOrBytes.Bytes(bytes) => new String(bytes, charset)
    }

    Token(normalizer(strValue), TokenType.STRING)
  }

  def tokenize(value: String): Token = tokenize(StrOrBytes.Str(value))
  def tokenize(value: Array[Byte]): Token = tokenize(StrOrBytes.Bytes(value))
}

sealed trait NumericValue extends Product with Serializable

object NumericValue {
  final case class IntNumber(value: Long) extends NumericValue
  final case class FloatNumber(value: Double) extends NumericValue
  final case class DecimalNumber(value: BigDecimal) extends NumericValue

  def apply(value: Int): NumericValue = IntNumber(value.toLong)
  def apply(value: Long): NumericValue = IntNumber(value)
  def apply(value: Double): NumericValue = FloatNumber(value)
  def apply(value: Float): NumericValue = FloatNumber(value.toDouble)
  def apply(value: BigDecimal): NumericValue = DecimalNumber(value)
}

final class NumericTokenizer(
  precision: Int = 6,
  formatOptions: Map[String, Any] = Map.empty
) extends BaseTokenizer[NumericValue] {

  private def formatFixed(d: Double): String =
    String.format(Locale.ROOT, s"%.${precision}f", Double.box(d))

  override def tokenize(value: NumericValue): Token = {
    val (strValue, originalType) = value match {
      case NumericValue.DecimalNumber(d) =>
        val rounded = d.setScale(precision, BigDecimal.RoundingMode.HALF_EVEN)
        (rounded.toString, "Decimal")

      case NumericValue.FloatNumber(d) =>
        (formatFixed(d), "float")

      case NumericValue.IntNumber(n) =>
        (n.toString, "int")
    }

    Token(
      value = strValue,
      tokenType = TokenType.NUMERIC,
      metadata = Map("original_type" -> originalType) ++ formatOptions
    )
  }

  def tokenize(value: Int): Token = tokenize(NumericValue(value))
  def tokenize(value: Long): Token = tokenize(NumericValue(value))
  def tokenize(value: Double): Token = tokenize(NumericValue(value))
  def tokenize(value: Float): Token = tokenize(NumericValue(value))
  def tokenize(value: BigDecimal): Token = tokenize(NumericValue(value))
}

sealed trait TemporalValue extends Product with Serializable

object TemporalValue {
  final case class DateTime(value: LocalDateTime) extends TemporalValue
  final case class Date(value: LocalDate) extends TemporalValue
}

final class TemporalTokenizer(formatStr: Option[String] = None) extends BaseTokenizer[TemporalValue] {
  import TemporalTokenizer._

  override def tokenize(value: TemporalValue): Token = {
    val formatter = formatStr match {
      case Some(fmt) => DateTimeFormatter.ofPattern(fmt)
      case None =>
        value match {
          case TemporalValue.DateTime(_) => DateTimeFormatter.ofPattern(ISO_FORMAT)
          case TemporalValue.Date(_) => DateTimeFormatter.ofPattern(DATE_FORMAT)
        }
    }

    val rendered = value match {
      case TemporalValue.DateTime(dt) => dt.format(formatter)
      case TemporalValue.Date(d) => d.format(formatter)
    }

    Token(rendered, TokenType.TEMPORAL)
  }

  def tokenize(value: LocalDateTime): Token = tokenize(TemporalValue.DateTime(value))
  def tokenize(value: LocalDate): Token = tokenize(TemporalValue.Date(value))
}

object TemporalTokenizer {
  val ISO_FORMAT: String = "yyyy-MM-dd'T'HH:mm:ss"
  val DATE_FORMAT: String = "yyyy-MM-dd"
}

final class UniversalTokenizer extends Serializable {
  private val stringTokenizer = new StringTokenizer()
  private val numericTokenizer = new NumericTokenizer()
  private val temporalTokenizer = new TemporalTokenizer()

  def tokenize(value: Any): Token = value match {
    case null => Token("NULL", TokenType.NULL)

    case t: Tokenizable =>
      Token(t.toToken, TokenType.STRUCTURED)

    case s: String =>
      stringTokenizer.tokenize(s)

    case bytes: Array[Byte] =>
      stringTokenizer.tokenize(bytes)

    case n: Int => numericTokenizer.tokenize(NumericValue(n))
    case n: Long => numericTokenizer.tokenize(NumericValue(n))
    case n: Double => numericTokenizer.tokenize(NumericValue(n))
    case n: Float => numericTokenizer.tokenize(NumericValue(n))
    case n: BigDecimal => numericTokenizer.tokenize(NumericValue(n))

    case dt: LocalDateTime => temporalTokenizer.tokenize(TemporalValue.DateTime(dt))
    case d: LocalDate => temporalTokenizer.tokenize(TemporalValue.Date(d))

    case other =>
      Token(other.toString, TokenType.STRING, Map("fallback" -> true))
  }
}

// ============================================================================
// Whitespace Tokenizer - Basic Text Tokenization
// ============================================================================

final class WhitespaceTokenizer(
  lowercase: Boolean = false,
  minLength: Int = 0,
  maxLength: Option[Int] = None,
  stripPunctuation: Boolean = false
) extends Serializable {

  private val punctuation: Set[Char] = ".,!?;:'\"()[]{}".toSet

  private def stripEdgePunctuation(s: String): String = {
    var start = 0
    var end = s.length

    while (start < end && punctuation.contains(s.charAt(start))) start += 1
    while (end > start && punctuation.contains(s.charAt(end - 1))) end -= 1

    s.substring(start, end)
  }

  private def processToken(word0: String): Option[String] = {
    val stripped = if (stripPunctuation) stripEdgePunctuation(word0) else word0
    val cased = if (lowercase) stripped.toLowerCase(Locale.ROOT) else stripped

    if (cased.length < minLength) None
    else {
      val truncated = maxLength match {
        case Some(m) if cased.length > m => cased.take(m)
        case _ => cased
      }
      Option(truncated).filter(_.nonEmpty)
    }
  }

  def tokenize(text: String): List[Token] = {
    val words = text.split("\\s+").iterator.filter(_.nonEmpty).toVector

    words.zipWithIndex.flatMap { case (word, i) =>
      processToken(word).map { processed =>
        Token(
          value = processed,
          tokenType = TokenType.STRING,
          metadata = Map("position" -> i, "original" -> word)
        )
      }
    }.toList
  }

  def tokenizeToStrings(text: String): List[String] =
    tokenize(text).map(_.value)

  def tokenizeWithPositions(text: String): List[(String, Int, Int)] = {
    val words = text.split("\\s+").iterator.filter(_.nonEmpty)

    val out = immutable.List.newBuilder[(String, Int, Int)]
    var currentPos = 0

    words.foreach { word =>
      val start = text.indexOf(word, currentPos)
      val end = if (start >= 0) start + word.length else currentPos

      processToken(word).foreach { processed =>
        out += ((processed, start, end))
      }

      currentPos = end
    }

    out.result()
  }

  def countTokens(text: String): Int = tokenize(text).length
}

// ============================================================================
// Builder Pattern with Fluent Interface
// ============================================================================

final class TokenizerBuilder[T] extends Serializable {
  private var normalizers: Vector[String => String] = Vector.empty
  private var validators: Vector[T => Boolean] = Vector.empty
  private var metadata: Map[String, Any] = Map.empty

  def withNormalizer(normalizer: String => String): TokenizerBuilder[T] = {
    normalizers = normalizers :+ normalizer
    this
  }

  def withValidator(validator: T => Boolean): TokenizerBuilder[T] = {
    validators = validators :+ validator
    this
  }

  def withMetadata(kv: (String, Any)*): TokenizerBuilder[T] = {
    metadata = metadata ++ kv.toMap
    this
  }

  def build(): T => Token = {
    val normalizers0 = normalizers
    val validators0 = validators
    val metadata0 = metadata

    (value: T) => {
      val valid = validators0.forall(v => v(value))
      if (!valid) throw new IllegalArgumentException(s"Validation failed for $value")

      val normalized = normalizers0.foldLeft(String.valueOf(value)) { (s, n) => n(s) }
      Token(normalized, TokenType.STRING, metadata0)
    }
  }
}

// ============================================================================
// Convenience functions (Scala requires top-level defs to be in an object)
// ============================================================================

object Tokenizer {
  private val universal = new UniversalTokenizer

  def tokenize(value: Any): Token =
    universal.tokenize(value)

  def tokenizeBatch(values: Iterable[Any]): Iterator[Token] =
    values.iterator.map(universal.tokenize)

  def toToken(value: Any): String = value match {
    case null => "NULL"
    case t: Token => t.value
    case t: Tokenizable => t.toToken
    case other => other.toString
  }

  def withMetadata(token: Token, kv: (String, Any)*): Token =
    token.withMetadata(kv: _*)
}
