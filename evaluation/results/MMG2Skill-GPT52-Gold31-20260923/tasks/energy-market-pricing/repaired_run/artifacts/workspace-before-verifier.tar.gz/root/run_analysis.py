import json
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import cvxpy as cp
import numpy as np
import scipy.sparse as sp


BINDING_THRESHOLD_PCT = 99.0
TARGET_LINE = (64, 1501)


@dataclass(frozen=True)
class CaseResult:
    total_cost: float
    lmp_by_bus: List[Dict[str, Any]]
    reserve_mcp: float
    binding_lines: List[Dict[str, Any]]
    target_line_binding: bool


def _build_B_and_shift(
    buses: np.ndarray, branches: np.ndarray
) -> Tuple[sp.csr_matrix, np.ndarray, Dict[int, int]]:
    n_bus = buses.shape[0]
    bus_num_to_idx = {int(buses[i, 0]): i for i in range(n_bus)}

    rows: List[int] = []
    cols: List[int] = []
    data: List[float] = []
    shift_injection = np.zeros(n_bus, dtype=float)  # per-unit

    # MATPOWER branch columns (0-index):
    # 0 fbus, 1 tbus, 2 r, 3 x, 4 b, 5 rateA, 6 rateB, 7 rateC,
    # 8 ratio (tap), 9 angle (shift degrees), 10 status, 11 angmin, 12 angmax
    for br in branches:
        status = int(br[10]) if branches.shape[1] > 10 else 1
        if status == 0:
            continue

        x = float(br[3])
        if x == 0:
            continue

        f = bus_num_to_idx[int(br[0])]
        t = bus_num_to_idx[int(br[1])]

        tap = float(br[8]) if branches.shape[1] > 8 else 0.0
        if tap == 0.0:
            tap = 1.0

        shift_deg = float(br[9]) if branches.shape[1] > 9 else 0.0
        shift_rad = shift_deg * np.pi / 180.0

        b = (1.0 / x) / tap

        # Bbus contributions (symmetric)
        rows += [f, t, f, t]
        cols += [f, t, t, f]
        data += [b, b, -b, -b]

        # Phase-shift constant injection term, in per-unit
        # Injection contribution at f: -b*shift, at t: +b*shift
        if shift_rad != 0.0:
            shift_injection[f] += -b * shift_rad
            shift_injection[t] += +b * shift_rad

    B = sp.coo_matrix((data, (rows, cols)), shape=(n_bus, n_bus)).tocsr()
    return B, shift_injection, bus_num_to_idx


def _generator_cost_expr(gencost: np.ndarray, Pg_pu: cp.Expression, baseMVA: float) -> cp.Expression:
    # MATPOWER gencost polynomial (MODEL=2). P is in MW.
    cost = 0
    for i in range(gencost.shape[0]):
        model = int(gencost[i, 0])
        if model != 2:
            raise ValueError(f"Unsupported gencost MODEL={model} for generator {i}")

        ncost = int(gencost[i, 3])
        P = Pg_pu[i] * baseMVA

        if ncost >= 3:
            c2, c1, c0 = float(gencost[i, 4]), float(gencost[i, 5]), float(gencost[i, 6])
            cost += c2 * cp.square(P) + c1 * P + c0
        elif ncost == 2:
            c1, c0 = float(gencost[i, 4]), float(gencost[i, 5])
            cost += c1 * P + c0
        elif ncost == 1:
            c0 = float(gencost[i, 4])
            cost += c0
        else:
            cost += 0

    return cost


def solve_case(data: Dict[str, Any], branches: np.ndarray) -> CaseResult:
    baseMVA = float(data["baseMVA"])
    buses = np.asarray(data["bus"], dtype=float)
    gens = np.asarray(data["gen"], dtype=float)
    gencost = np.asarray(data["gencost"], dtype=float)
    reserve_capacity = np.asarray(data["reserve_capacity"], dtype=float)
    reserve_requirement = float(data["reserve_requirement"])

    n_bus = buses.shape[0]
    n_gen = gens.shape[0]

    B, shift_injection, bus_num_to_idx = _build_B_and_shift(buses, branches)

    slack_idx = next(i for i in range(n_bus) if int(buses[i, 1]) == 3)
    gen_bus_idx = np.array([bus_num_to_idx[int(gens[i, 0])] for i in range(n_gen)], dtype=int)

    Pg = cp.Variable(n_gen)  # per-unit
    Rg = cp.Variable(n_gen)  # MW
    theta = cp.Variable(n_bus)  # radians

    constraints: List[Any] = []

    # Slack angle reference
    constraints.append(theta[slack_idx] == 0)

    # Generator bounds and reserve coupling
    for i in range(n_gen):
        status = int(gens[i, 7]) if gens.shape[1] > 7 else 1
        pmax = float(gens[i, 8])
        pmin = float(gens[i, 9])

        if status == 0:
            constraints += [Pg[i] == 0, Rg[i] == 0]
            continue

        constraints += [Pg[i] >= pmin / baseMVA, Pg[i] <= pmax / baseMVA]
        constraints += [Rg[i] >= 0, Rg[i] <= float(reserve_capacity[i])]
        constraints += [Pg[i] * baseMVA + Rg[i] <= pmax]

    # Reserve requirement
    reserve_con = cp.sum(Rg) >= reserve_requirement
    constraints.append(reserve_con)

    # Branch thermal limits
    # Use MATPOWER DC flow: flow_MW = b*(theta_f - theta_t - shift)*baseMVA
    for br in branches:
        status = int(br[10]) if branches.shape[1] > 10 else 1
        if status == 0:
            continue

        x = float(br[3])
        if x == 0:
            continue

        rateA = float(br[5])
        if rateA <= 0:
            continue

        tap = float(br[8]) if branches.shape[1] > 8 else 0.0
        if tap == 0.0:
            tap = 1.0

        shift_deg = float(br[9]) if branches.shape[1] > 9 else 0.0
        shift_rad = shift_deg * np.pi / 180.0

        b = (1.0 / x) / tap
        f = bus_num_to_idx[int(br[0])]
        t = bus_num_to_idx[int(br[1])]

        flow = b * (theta[f] - theta[t] - shift_rad) * baseMVA
        constraints += [flow <= rateA, flow >= -rateA]

    # Nodal balance constraints (store references for duals)
    balance_constraints: List[Any] = []
    for i in range(n_bus):
        gen_mask = gen_bus_idx == i
        pg_at_bus = cp.sum(Pg[gen_mask]) if np.any(gen_mask) else 0
        pd_pu = float(buses[i, 2]) / baseMVA

        con = (pg_at_bus - pd_pu == (B[i, :] @ theta) + float(shift_injection[i]))
        balance_constraints.append(con)
        constraints.append(con)

    objective = cp.Minimize(_generator_cost_expr(gencost, Pg, baseMVA))
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.CLARABEL)

    if prob.status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE}:
        raise RuntimeError(f"Solve failed with status: {prob.status}")

    total_cost = float(prob.value)

    # LMPs: for balance written as (gen_pu - load_pu == ...), LMP = -dual/baseMVA
    lmp_by_bus = []
    for i in range(n_bus):
        lam = balance_constraints[i].dual_value
        lam_s = None if lam is None else float(np.squeeze(lam))
        lmp = 0.0 if lam_s is None else float(-lam_s / baseMVA)
        lmp_by_bus.append({
            "bus": int(buses[i, 0]),
            "lmp_dollars_per_MWh": round(lmp, 2),
        })
    lmp_by_bus.sort(key=lambda x: x["bus"])

    reserve_dual = reserve_con.dual_value
    reserve_mcp = 0.0 if reserve_dual is None else float(np.squeeze(reserve_dual))

    # Binding lines report
    binding_lines: List[Dict[str, Any]] = []
    target_line_binding = False

    theta_val = np.asarray(theta.value).reshape(-1)
    for br in branches:
        status = int(br[10]) if branches.shape[1] > 10 else 1
        if status == 0:
            continue

        x = float(br[3])
        if x == 0:
            continue

        rateA = float(br[5])
        if rateA <= 0:
            continue

        tap = float(br[8]) if branches.shape[1] > 8 else 0.0
        if tap == 0.0:
            tap = 1.0

        shift_deg = float(br[9]) if branches.shape[1] > 9 else 0.0
        shift_rad = shift_deg * np.pi / 180.0

        b = (1.0 / x) / tap
        fbus = int(br[0])
        tbus = int(br[1])
        f = bus_num_to_idx[fbus]
        t = bus_num_to_idx[tbus]

        flow = b * (theta_val[f] - theta_val[t] - shift_rad) * baseMVA
        loading_pct = abs(flow) / rateA * 100.0

        if loading_pct >= BINDING_THRESHOLD_PCT:
            binding_lines.append({
                "from": fbus,
                "to": tbus,
                "flow_MW": round(float(flow), 2),
                "limit_MW": round(float(rateA), 2),
            })

        if (fbus, tbus) == TARGET_LINE or (tbus, fbus) == TARGET_LINE:
            if loading_pct >= BINDING_THRESHOLD_PCT:
                target_line_binding = True

    return CaseResult(
        total_cost=round(total_cost, 2),
        lmp_by_bus=lmp_by_bus,
        reserve_mcp=round(float(reserve_mcp), 2),
        binding_lines=binding_lines,
        target_line_binding=target_line_binding,
    )


def _relax_target_line(branches: np.ndarray, pct: float) -> np.ndarray:
    out = branches.copy()
    found = False

    for k in range(out.shape[0]):
        a = int(out[k, 0])
        b = int(out[k, 1])
        if (a, b) == TARGET_LINE or (b, a) == TARGET_LINE:
            out[k, 5] = float(out[k, 5]) * (1.0 + pct)
            found = True

    if not found:
        raise ValueError(f"Did not find target line {TARGET_LINE[0]}-{TARGET_LINE[1]} in branch data")

    return out


def main() -> None:
    with open("/root/network.json") as f:
        data = json.load(f)

    branches = np.asarray(data["branch"], dtype=float)

    base = solve_case(data, branches)
    cf_branches = _relax_target_line(branches, 0.20)
    cf = solve_case(data, cf_branches)

    # Impact analysis
    cost_reduction = round(base.total_cost - cf.total_cost, 2)

    base_lmp = {d["bus"]: float(d["lmp_dollars_per_MWh"]) for d in base.lmp_by_bus}
    cf_lmp = {d["bus"]: float(d["lmp_dollars_per_MWh"]) for d in cf.lmp_by_bus}

    deltas = []
    for bus in sorted(base_lmp.keys()):
        b = base_lmp[bus]
        c = cf_lmp.get(bus, b)
        deltas.append({"bus": bus, "base_lmp": b, "cf_lmp": c, "delta": round(c - b, 2)})

    buses_with_largest_lmp_drop = sorted(deltas, key=lambda x: x["delta"])[:3]

    congestion_relieved = bool(base.target_line_binding and (not cf.target_line_binding))

    report = {
        "base_case": {
            "total_cost_dollars_per_hour": base.total_cost,
            "lmp_by_bus": base.lmp_by_bus,
            "reserve_mcp_dollars_per_MWh": base.reserve_mcp,
            "binding_lines": base.binding_lines,
        },
        "counterfactual": {
            "total_cost_dollars_per_hour": cf.total_cost,
            "lmp_by_bus": cf.lmp_by_bus,
            "reserve_mcp_dollars_per_MWh": cf.reserve_mcp,
            "binding_lines": cf.binding_lines,
        },
        "impact_analysis": {
            "cost_reduction_dollars_per_hour": cost_reduction,
            "buses_with_largest_lmp_drop": buses_with_largest_lmp_drop,
            "congestion_relieved": congestion_relieved,
        },
    }

    with open("/root/report.json", "w") as f:
        json.dump(report, f, indent=2, sort_keys=False)


if __name__ == "__main__":
    main()
