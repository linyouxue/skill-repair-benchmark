---
name: add-skill
description: Import an existing skill from a GitHub repository URL into the current workspace. Use only when the user provides or references a GitHub URL/repo to fetch from (e.g., `/add-skill https://github.com/OpenHands/extensions/tree/main/skills/codereview` or "add the codereview skill from https://github.com/OpenHands/extensions/"). Handles fetching the skill files and placing them in .agents/skills/. This does not author new skills — to create a new skill from scratch (no source URL), use the skill-creator skill instead.
---

# Add Skill

Import skills from GitHub repositories into the current workspace.

## Workflow

When a user requests to add a skill from a GitHub URL:

1. **Parse the URL** to extract repository owner, name, and skill path
2. **Fetch the skill** using the bundled script. Run it from this skill's
   directory (the directory containing this SKILL.md file):
   ```bash
   python3 scripts/fetch_skill.py "<github-url>" "<workspace-path>"
   ```
3. **Verify** that SKILL.md exists in the destination
4. **Inform the user** the skill is now available

## URL Formats Supported

- `https://github.com/owner/repo/tree/main/path/to/skill`
- `https://github.com/owner/repo/skill-name`
- `github.com/owner/repo/skill-name`
- `owner/repo/skill-name` (shorthand)

## Example

User: `/add-skill https://github.com/OpenHands/extensions/tree/main/skills/codereview`

```bash
# Run the fetch script
python3 scripts/fetch_skill.py "https://github.com/OpenHands/extensions/tree/main/skills/codereview" "/path/to/workspace"

# Verify installation
ls /path/to/workspace/.agents/skills/codereview/SKILL.md
```

On Windows, use `python` if `python3` is not available and verify with PowerShell, for example: `Test-Path C:\path\to\workspace\.agents\skills\codereview\SKILL.md`.

Response: "✅ Added `codereview` to your workspace. The skill is now available."

## Notes

- Installs workspace-locally into `<workspace>/.agents/skills/<skill-name>/`,
  not globally; that workspace is where the skill becomes available
- Creates `.agents/skills/` directory if it doesn't exist
- Uses `GITHUB_TOKEN` for authentication (required for private repos)
- Warns before overwriting existing skills with the same name
