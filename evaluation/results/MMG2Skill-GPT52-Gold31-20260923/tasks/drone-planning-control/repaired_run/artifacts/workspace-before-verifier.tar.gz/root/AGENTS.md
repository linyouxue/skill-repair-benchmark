# Repository notes (OpenHands)

- `system_params.yaml` defines quadrotor physical parameters and acceleration limits.
- Natural-language command files live in `commands/*.txt` (one command per file).
- Main pipeline script: `run_all.py`.
  - Parses commands via `flight_plan_parser.py`.
  - Generates a time-parameterized min-jerk trajectory via `trajectory_planner.py` and clips planned accelerations to `accel_limit_*`.
  - Runs closed-loop simulation (`simulator.py`) using:
    - motor allocation + lag model: `motor_model.py`
    - RK4-integrated dynamics: `quad_dynamics.py`
    - position/attitude PID loops: `controllers.py`
  - Computes metrics via `stepinfo_3d.py` and plots via `plot_quadrotor.py`.
  - Writes per-command outputs to `/root/results/<label>/`.

- Practical note: the simulator initializes motor RPMs at hover RPM (not `rpm_min`) to avoid an artificial initial drop in altitude.
