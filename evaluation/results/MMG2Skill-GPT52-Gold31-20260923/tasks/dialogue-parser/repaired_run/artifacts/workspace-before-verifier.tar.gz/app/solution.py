import json
import re
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Tuple


_SECTION_RE = re.compile(r"^\s*\[([^\]]+)\]\s*$")
_LINE_RE = re.compile(r"^\s*([^:]+):\s*(.*?)\s*->\s*([A-Za-z0-9_]+)\s*$")
_CHOICE_RE = re.compile(r"^\s*(\d+)\.\s*(.*?)\s*->\s*([A-Za-z0-9_]+)\s*$")


def _parse_sections(text: str) -> Tuple[List[str], Dict[str, List[str]]]:
    order: List[str] = []
    sections: Dict[str, List[str]] = {}

    current_id: str | None = None
    buf: List[str] = []

    def flush() -> None:
        nonlocal current_id, buf
        if current_id is None:
            return
        normalized = [ln.strip() for ln in buf if ln.strip()]
        if current_id in sections:
            if sections[current_id] != normalized:
                raise ValueError(f"Duplicate section [{current_id}] with different content")
        else:
            sections[current_id] = normalized
            order.append(current_id)
        buf = []

    for raw in text.splitlines():
        m = _SECTION_RE.match(raw)
        if m:
            flush()
            current_id = m.group(1).strip()
            if not current_id:
                raise ValueError("Empty section header [] is not allowed")
            continue

        if current_id is None:
            if raw.strip():
                raise ValueError(f"Content outside any section: {raw!r}")
            continue

        buf.append(raw)

    flush()
    return order, sections


def parse_script(text: str) -> Dict[str, Any]:
    """Parse a bracketed-section dialogue script into a validated graph.

    Returns:
        {"nodes": [{"id","text","speaker","type"}...],
         "edges": [{"from","to","text"}...]}
    """

    order, sections = _parse_sections(text)
    if not order:
        raise ValueError("No sections found")

    nodes_by_id: Dict[str, Dict[str, str]] = {}
    nodes_in_order: List[Dict[str, str]] = []
    edges: List[Dict[str, str]] = []

    referenced_targets: List[str] = []

    def add_node(node: Dict[str, str]) -> None:
        node_id = node["id"]
        if node_id in nodes_by_id:
            return
        nodes_by_id[node_id] = node
        nodes_in_order.append(node)

    for sec_id in order:
        lines = sections[sec_id]

        if len(lines) == 1:
            m_line = _LINE_RE.match(lines[0])
            m_choice = _CHOICE_RE.match(lines[0])

            if m_line:
                speaker = m_line.group(1).strip()
                text_body = m_line.group(2).strip()
                target = m_line.group(3).strip()

                add_node({
                    "id": sec_id,
                    "type": "line",
                    "speaker": speaker,
                    "text": text_body,
                })
                edges.append({"from": sec_id, "to": target, "text": ""})
                referenced_targets.append(target)
                continue

            if m_choice:
                # Allow a single choice line section.
                add_node({
                    "id": sec_id,
                    "type": "choice",
                    "speaker": "",
                    "text": "",
                })
                choice_text = m_choice.group(2).strip()
                target = m_choice.group(3).strip()
                edges.append({"from": sec_id, "to": target, "text": choice_text})
                referenced_targets.append(target)
                continue

            raise ValueError(f"Section [{sec_id}] has a nonconforming line: {lines[0]!r}")

        if len(lines) >= 1 and all(_CHOICE_RE.match(ln) for ln in lines):
            add_node({
                "id": sec_id,
                "type": "choice",
                "speaker": "",
                "text": "",
            })
            for ln in lines:
                m = _CHOICE_RE.match(ln)
                assert m is not None
                choice_text = m.group(2).strip()
                target = m.group(3).strip()
                edges.append({"from": sec_id, "to": target, "text": choice_text})
                referenced_targets.append(target)
            continue

        raise ValueError(
            f"Section [{sec_id}] must be either one speaker line or all numbered choices"
        )

    # Implicit End node if referenced but not defined.
    if "End" in referenced_targets and "End" not in nodes_by_id:
        add_node({"id": "End", "type": "line", "speaker": "", "text": ""})

    # Validate edge targets exist.
    for e in edges:
        if e["to"] not in nodes_by_id:
            raise ValueError(f"Edge target [{e['to']}] referenced but not defined")

    # Reachability check from the first section.
    start = order[0]
    adj: Dict[str, List[str]] = {}
    for e in edges:
        adj.setdefault(e["from"], []).append(e["to"])

    visited: set[str] = set()
    q: deque[str] = deque([start])
    while q:
        cur = q.popleft()
        if cur in visited:
            continue
        visited.add(cur)
        for nxt in adj.get(cur, []):
            if nxt not in visited:
                q.append(nxt)

    unreachable = [n["id"] for n in nodes_in_order if n["id"] not in visited]
    if unreachable:
        raise ValueError(f"Unreachable nodes from start [{start}]: {unreachable}")

    return {"nodes": nodes_in_order, "edges": edges}


def _dot_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', "\\\"").replace("\n", "\\n")


def graph_to_dot(graph: Dict[str, Any]) -> str:
    nodes: List[Dict[str, str]] = graph["nodes"]
    edges: List[Dict[str, str]] = graph["edges"]

    lines: List[str] = ["digraph Dialogue {", "  rankdir=LR;"]

    for n in nodes:
        node_id = n["id"]
        ntype = n.get("type", "line")
        shape = "diamond" if ntype == "choice" else "box"

        speaker = n.get("speaker", "")
        text = n.get("text", "")
        if ntype == "line" and (speaker or text):
            label = node_id
            if speaker:
                label += f"\\n{speaker}:"
            if text:
                label += f"\\n{text}"
        else:
            label = node_id

        lines.append(
            f"  \"{_dot_escape(node_id)}\" [shape={shape}, label=\"{_dot_escape(label)}\"];"
        )

    for e in edges:
        frm = e["from"]
        to = e["to"]
        label = e.get("text", "")
        if label:
            lines.append(
                f"  \"{_dot_escape(frm)}\" -> \"{_dot_escape(to)}\" [label=\"{_dot_escape(label)}\"];"
            )
        else:
            lines.append(f"  \"{_dot_escape(frm)}\" -> \"{_dot_escape(to)}\";")

    lines.append("}")
    return "\n".join(lines) + "\n"


def main() -> None:
    script_path = Path("/app/script.txt")
    out_json = Path("/app/dialogue.json")
    out_dot = Path("/app/dialogue.dot")

    text = script_path.read_text(encoding="utf-8")
    graph = parse_script(text)

    out_json.write_text(json.dumps(graph, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    out_dot.write_text(graph_to_dot(graph), encoding="utf-8")


if __name__ == "__main__":
    main()
