import json
import re
from collections import deque
from typing import Any, Dict, List, Tuple


_SECTION_RE = re.compile(r"^\s*\[([^\]]+)\]\s*$")
_LINE_RE = re.compile(r"^\s*([^:]+):\s*(.*?)\s*->\s*([\w-]+)\s*$")
_CHOICE_RE = re.compile(r"^\s*(\d+)\.\s*(.*?)\s*->\s*([\w-]+)\s*$")


def _split_sections(text: str) -> Tuple[List[str], Dict[str, List[str]]]:
    order: List[str] = []
    sections: Dict[str, List[str]] = {}

    current_id: str | None = None
    current_lines: List[str] = []

    def flush() -> None:
        nonlocal current_id, current_lines
        if current_id is None:
            return
        if current_id in sections:
            raise ValueError(f"Duplicate section id: {current_id}")
        sections[current_id] = current_lines
        order.append(current_id)
        current_id = None
        current_lines = []

    for raw in text.splitlines():
        m = _SECTION_RE.match(raw)
        if m:
            flush()
            current_id = m.group(1).strip()
            continue

        if current_id is None:
            if raw.strip():
                raise ValueError(f"Content outside any section: {raw!r}")
            continue

        line = raw.strip()
        if not line:
            continue
        current_lines.append(line)

    flush()

    if not order:
        raise ValueError("No sections found")

    return order, sections


def parse_script(text: str) -> Dict[str, Any]:
    """Parse bracketed-section dialogue script into a graph dict.

    Returns:
        {"nodes": [{"id","text","speaker","type"}, ...],
         "edges": [{"from","to","text"}, ...]}

    Raises:
        ValueError on invalid structure or unreachable nodes.
    """

    order, sections = _split_sections(text)

    nodes_by_id: Dict[str, Dict[str, str]] = {}
    node_order: List[str] = []
    edges: List[Dict[str, str]] = []

    def ensure_node(node_id: str, node: Dict[str, str]) -> None:
        if node_id in nodes_by_id:
            return
        nodes_by_id[node_id] = node
        node_order.append(node_id)

    for section_id in order:
        lines = sections[section_id]
        if not lines:
            ensure_node(section_id, {"id": section_id, "text": "", "speaker": "", "type": "line"})
            continue

        choice_matches = [_CHOICE_RE.match(ln) for ln in lines]
        line_match = _LINE_RE.match(lines[0]) if len(lines) == 1 else None

        if all(m is not None for m in choice_matches):
            ensure_node(section_id, {"id": section_id, "text": "", "speaker": "", "type": "choice"})
            for m in choice_matches:  # type: ignore[assignment]
                choice_text = m.group(2).strip()
                target = m.group(3).strip()
                edges.append({"from": section_id, "to": target, "text": choice_text})
        elif line_match is not None:
            speaker = line_match.group(1).strip()
            text_part = line_match.group(2).strip()
            target = line_match.group(3).strip()
            ensure_node(section_id, {"id": section_id, "text": text_part, "speaker": speaker, "type": "line"})
            edges.append({"from": section_id, "to": target, "text": ""})
        else:
            kind = "mixed" if any(m is not None for m in choice_matches) else "unrecognized"
            raise ValueError(f"Invalid section '{section_id}' ({kind}): {lines!r}")

    # Create any missing edge targets as placeholder nodes (including implicit End).
    for e in edges:
        tgt = e["to"]
        if tgt not in nodes_by_id:
            ensure_node(tgt, {"id": tgt, "text": "", "speaker": "", "type": "line"})

    # Reachability validation.
    start = order[0]
    adj: Dict[str, List[str]] = {}
    for e in edges:
        adj.setdefault(e["from"], []).append(e["to"])

    visited: set[str] = set()
    q: deque[str] = deque([start])
    while q:
        cur = q.popleft()
        if cur in visited:
            continue
        visited.add(cur)
        for nxt in adj.get(cur, []):
            if nxt not in visited:
                q.append(nxt)

    unreachable = [nid for nid in node_order if nid not in visited]
    if unreachable:
        raise ValueError(f"Unreachable nodes from start '{start}': {unreachable}")

    nodes = [nodes_by_id[nid] for nid in node_order]
    return {"nodes": nodes, "edges": edges}


def _dot_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def graph_to_dot(graph: Dict[str, Any]) -> str:
    nodes: List[Dict[str, str]] = graph["nodes"]
    edges: List[Dict[str, str]] = graph["edges"]

    lines: List[str] = []
    lines.append("digraph Dialogue {")
    lines.append("  rankdir=LR;")
    lines.append("  node [fontname=\"Helvetica\"]; ")

    for n in nodes:
        node_id = n["id"]
        ntype = n.get("type", "line")
        shape = "diamond" if ntype == "choice" else "box"

        label = node_id
        if ntype == "line":
            speaker = n.get("speaker", "")
            text = n.get("text", "")
            if speaker or text:
                snippet = text
                if len(snippet) > 90:
                    snippet = snippet[:87] + "..."
                if speaker:
                    label = f"{node_id}\\n{speaker}: {snippet}"
                else:
                    label = f"{node_id}\\n{snippet}"

        lines.append(f"  \"{_dot_escape(node_id)}\" [shape={shape}, label=\"{_dot_escape(label)}\"]; ")

    for e in edges:
        frm = e["from"]
        to = e["to"]
        txt = e.get("text", "")
        if txt:
            lines.append(
                f"  \"{_dot_escape(frm)}\" -> \"{_dot_escape(to)}\" [label=\"{_dot_escape(txt)}\"];"
            )
        else:
            lines.append(f"  \"{_dot_escape(frm)}\" -> \"{_dot_escape(to)}\";")

    lines.append("}")
    return "\n".join(lines) + "\n"


def main() -> None:
    script_path = "/app/script.txt"
    json_path = "/app/dialogue.json"
    dot_path = "/app/dialogue.dot"

    with open(script_path, "r", encoding="utf-8") as f:
        text = f.read()

    graph = parse_script(text)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2, ensure_ascii=False)
        f.write("\n")

    with open(dot_path, "w", encoding="utf-8") as f:
        f.write(graph_to_dot(graph))


if __name__ == "__main__":
    main()
