/* global d3 */

(function () {
  const BUBBLE_W = 760;
  const BUBBLE_H = 560;
  const SPARK_W = 760;
  const SPARK_H = 160;
  const ETF_RADIUS = 14;

  const bubbleSvg = d3.select('#bubbleSvg');
  const sparkSvg = d3.select('#sparkSvg');
  const tooltip = d3.select('#tooltip');
  const detailsMeta = d3.select('#detailsMeta');

  let selectedTicker = null;
  const historyCache = new Map();

  function parseMarketCap(v) {
    if (v == null) return null;
    const s = String(v).trim();
    if (!s) return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function formatMarketCap(v) {
    if (v == null || !Number.isFinite(v)) return '—';
    const abs = Math.abs(v);
    const fmt = (x) => d3.format(',.2f')(x).replace(/\.00$/, '');
    if (abs >= 1e12) return `${fmt(v / 1e12)}T`;
    if (abs >= 1e9) return `${fmt(v / 1e9)}B`;
    if (abs >= 1e6) return `${fmt(v / 1e6)}M`;
    if (abs >= 1e3) return `${fmt(v / 1e3)}K`;
    return fmt(v);
  }

  function showTooltip(event, d) {
    if (d.isEtf) return;
    tooltip
      .style('display', 'block')
      .html(
        `<div class="tt-title">${d.ticker}</div>` +
          `<div class="tt-row">${d.name}</div>` +
          `<div class="tt-row">Sector: ${d.sector}</div>`
      );
    moveTooltip(event);
  }

  function moveTooltip(event) {
    tooltip
      .style('left', `${event.pageX + 12}px`)
      .style('top', `${event.pageY + 12}px`);
  }

  function hideTooltip() {
    tooltip.style('display', 'none');
  }

  function computeSectorCenters(sectors) {
    const center = { x: BUBBLE_W / 2, y: BUBBLE_H / 2 };
    const ringR = Math.min(BUBBLE_W, BUBBLE_H) * 0.18;
    const out = new Map();

    sectors.forEach((s, i) => {
      const a = (i / sectors.length) * Math.PI * 2 - Math.PI / 2;
      out.set(s, {
        x: center.x + ringR * Math.cos(a),
        y: center.y + ringR * Math.sin(a)
      });
    });

    return out;
  }

  async function loadHistory(ticker) {
    if (historyCache.has(ticker)) return historyCache.get(ticker);

    const parseDate = d3.timeParse('%Y-%m-%d');

    const candidates = Array.from(
      new Set([ticker, ticker.toLowerCase(), ticker.toUpperCase()])
    );

    for (const t of candidates) {
      const path = `data/indiv-stock/${t}.csv`;

      try {
        const raw = await d3.csv(path);
        const data = raw
          .map((r) => {
            const date = parseDate(r.Date || r.date || r.DATE);
            const price = Number(
              r['Adjusted Close'] ??
                r['Adj Close'] ??
                r['AdjClose'] ??
                r['adj close'] ??
                r['adjClose'] ??
                r.Close ??
                r.close
            );
            if (!date || !Number.isFinite(price)) return null;
            return { date, price };
          })
          .filter(Boolean)
          .sort((a, b) => a.date - b.date);

        historyCache.set(ticker, data);
        return data;
      } catch (e) {
        // Try next candidate.
      }
    }

    historyCache.set(ticker, null);
    return null;
  }

  function clearSpark() {
    sparkSvg.selectAll('*').remove();
  }

  function renderSpark(data) {
    clearSpark();

    const margin = { top: 18, right: 14, bottom: 24, left: 44 };
    const w = SPARK_W - margin.left - margin.right;
    const h = SPARK_H - margin.top - margin.bottom;

    const g = sparkSvg
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const x = d3
      .scaleTime()
      .domain(d3.extent(data, (d) => d.date))
      .range([0, w]);

    const y = d3
      .scaleLinear()
      .domain(d3.extent(data, (d) => d.price))
      .nice()
      .range([h, 0]);

    const area = d3
      .area()
      .x((d) => x(d.date))
      .y0(h)
      .y1((d) => y(d.price));

    const line = d3
      .line()
      .x((d) => x(d.date))
      .y((d) => y(d.price));

    g.append('path').datum(data).attr('class', 'spark-area').attr('d', area);
    g.append('path').datum(data).attr('class', 'spark-line').attr('d', line);

    g.append('g')
      .attr('class', 'axis')
      .attr('transform', `translate(0,${h})`)
      .call(d3.axisBottom(x).ticks(5));

    g.append('g').attr('class', 'axis').call(d3.axisLeft(y).ticks(4));
  }

  async function updateDetails(ticker, node) {
    if (!ticker) {
      detailsMeta.text('Select a stock to view its price history.');
      clearSpark();
      return;
    }

    const label = node ? `${node.ticker} · ${node.name}` : ticker;
    detailsMeta.text(`${label} — loading...`);
    clearSpark();

    const hist = await loadHistory(ticker);

    if (!hist || hist.length === 0) {
      detailsMeta.text(`${label} — no local price history file found.`);
      return;
    }

    detailsMeta.text(`${label} — ${hist.length} records`);
    renderSpark(hist);
  }

  function main(data) {
    const nodes = data
      .map((d) => {
        const marketCap = parseMarketCap(d.marketCap);
        const sector = (d.sector || '').trim();
        const ticker = (d.ticker || '').trim();
        const name = (d['full name'] || d.full_name || d.fullName || '').trim();
        const isEtf = sector === 'ETF' || marketCap == null;

        return {
          ticker,
          sector,
          name,
          marketCap,
          isEtf,
          r: ETF_RADIUS
        };
      })
      .filter((d) => d.ticker);

    nodes.sort((a, b) => d3.ascending(a.ticker, b.ticker));

    const sectors = Array.from(new Set(nodes.map((d) => d.sector))).sort(d3.ascending);
    const color = d3
      .scaleOrdinal()
      .domain(sectors)
      .range(d3.schemeTableau10.slice(0, sectors.length));

    const caps = nodes.filter((d) => !d.isEtf).map((d) => d.marketCap);
    const rScale = d3
      .scaleSqrt()
      .domain([d3.min(caps), d3.max(caps)])
      .range([10, 50]);

    nodes.forEach((d) => {
      d.r = d.isEtf ? ETF_RADIUS : rScale(d.marketCap);
    });

    // Legend
    const legend = d3.select('#legend');
    const legendItems = legend
      .selectAll('.legend-item')
      .data(sectors, (d) => d)
      .join('div')
      .attr('class', 'legend-item');

    legendItems
      .append('span')
      .attr('class', 'legend-swatch')
      .style('background', (d) => color(d));

    legendItems.append('span').text((d) => d);

    // Deterministic initial positions
    const cols = 10;
    const rows = Math.ceil(nodes.length / cols);
    const padX = 50;
    const padY = 50;
    const spanX = (BUBBLE_W - padX * 2) / (cols - 1);
    const spanY = rows > 1 ? (BUBBLE_H - padY * 2) / (rows - 1) : 0;

    nodes.forEach((d, i) => {
      d.x = padX + (i % cols) * spanX;
      d.y = padY + Math.floor(i / cols) * spanY;
    });

    const sectorCenters = computeSectorCenters(sectors);

    const sim = d3
      .forceSimulation(nodes)
      .force('center', d3.forceCenter(BUBBLE_W / 2, BUBBLE_H / 2))
      .force(
        'x',
        d3
          .forceX((d) => sectorCenters.get(d.sector).x)
          .strength(0.09)
      )
      .force(
        'y',
        d3
          .forceY((d) => sectorCenters.get(d.sector).y)
          .strength(0.09)
      )
      .force('collide', d3.forceCollide((d) => d.r + 1.6))
      .stop();

    for (let i = 0; i < 320; i++) sim.tick();

    bubbleSvg.selectAll('*').remove();

    const nodeSel = bubbleSvg
      .append('g')
      .attr('class', 'nodes')
      .selectAll('g.node')
      .data(nodes, (d) => d.ticker)
      .join('g')
      .attr('class', 'node')
      .attr('transform', (d) => `translate(${d.x},${d.y})`)
      .on('click', (event, d) => {
        event.stopPropagation();
        setSelected(d.ticker);
      })
      .on('mouseenter', (event, d) => showTooltip(event, d))
      .on('mousemove', (event, d) => {
        if (!d.isEtf) moveTooltip(event);
      })
      .on('mouseleave', hideTooltip);

    nodeSel
      .append('circle')
      .attr('r', (d) => d.r)
      .attr('fill', (d) => color(d.sector));

    nodeSel.append('text').text((d) => d.ticker);

    // Table
    const tbody = d3.select('#stockTable tbody');
    tbody.selectAll('*').remove();

    const rowsSel = tbody
      .selectAll('tr')
      .data(nodes, (d) => d.ticker)
      .join('tr')
      .attr('data-ticker', (d) => d.ticker)
      .on('click', (event, d) => {
        event.stopPropagation();
        setSelected(d.ticker);
      });

    rowsSel.append('td').text((d) => d.ticker);
    rowsSel.append('td').text((d) => d.name);
    rowsSel.append('td').text((d) => d.sector);
    rowsSel.append('td').text((d) => formatMarketCap(d.marketCap));

    function setSelected(ticker) {
      selectedTicker = ticker;

      nodeSel.classed('selected', (d) => d.ticker === selectedTicker);
      rowsSel.classed('selected', (d) => d.ticker === selectedTicker);

      if (selectedTicker) {
        const rowNode = rowsSel.filter((d) => d.ticker === selectedTicker).node();
        if (rowNode && rowNode.scrollIntoView) {
          rowNode.scrollIntoView({ block: 'nearest' });
        }
      }

      const node = selectedTicker ? nodes.find((n) => n.ticker === selectedTicker) : null;
      updateDetails(selectedTicker, node);
    }

    d3.select('body').on('click', () => setSelected(null));
    updateDetails(null, null);
  }

  d3
    .csv('data/stock-descriptions.csv')
    .then(main)
    .catch((e) => {
      const msg =
        'Failed to load CSV data. If you opened this as a file://' +
        ' URL, use a local web server instead (e.g. run: python3 -m http.server' +
        ' 8000 in /root/output and open http://localhost:8000).';

      detailsMeta.text(msg);
      clearSpark();

      const tbody = d3.select('#stockTable tbody');
      tbody.selectAll('*').remove();
      tbody
        .append('tr')
        .append('td')
        .attr('colspan', 4)
        .text(msg);

      // eslint-disable-next-line no-console
      console.error(e);
    });
})();
