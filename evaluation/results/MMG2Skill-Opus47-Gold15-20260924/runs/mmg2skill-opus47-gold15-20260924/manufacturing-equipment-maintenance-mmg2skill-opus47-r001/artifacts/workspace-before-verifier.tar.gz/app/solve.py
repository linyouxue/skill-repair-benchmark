"""Reflow profile compliance — Q1..Q5."""
import os, json, math
import pandas as pd

DATA_DIR = "/app/data"
OUT_DIR = "/app/output"
os.makedirs(OUT_DIR, exist_ok=True)

# ---- Handbook config (extracted from handbook.pdf) ----
# Page 4: preheat 100-150°C, ramp <2°C/s.
# Page 4: wetting time 30-60 s above liquidus; peak = liquidus + ~20°C.
cfg = {
    "preheat_tmin": 100.0,
    "preheat_tmax": 150.0,
    "ramp_limit_c_per_s": 2.0,
    "tal_min_s": 30.0,
    "tal_max_s": 60.0,
    "peak_margin_c": 20.0,
}

runs = pd.read_csv(os.path.join(DATA_DIR, "mes_log.csv"))
tc = pd.read_csv(os.path.join(DATA_DIR, "thermocouples.csv"))
defects = pd.read_csv(os.path.join(DATA_DIR, "test_defects.csv"))

runs["run_id"] = runs["run_id"].astype(str)
tc["run_id"] = tc["run_id"].astype(str)
tc["tc_id"] = tc["tc_id"].astype(str)
defects["run_id"] = defects["run_id"].astype(str)

runs = runs.sort_values(["run_id"], kind="mergesort").reset_index(drop=True)
tc = tc.sort_values(["run_id", "tc_id", "time_s"], kind="mergesort").reset_index(drop=True)


def r2(x):
    if x is None:
        return None
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        return None
    return float(round(float(x), 2))


def select_representative_tc(df_run):
    """Prefer largest_mass label; fallback to lowest peak temperature."""
    mass_syn = {"largest_mass", "large_mass", "thermal_mass", "heaviest",
                "big_mass", "component_body_large"}
    cand = df_run[df_run["tc_location"].astype(str).str.lower().isin(mass_syn)]
    if len(cand):
        return sorted(cand["tc_id"].unique())[0]
    peaks = df_run.groupby("tc_id")["temp_c"].max().reset_index()
    peaks = peaks.sort_values(["temp_c", "tc_id"], kind="mergesort")
    return peaks.iloc[0]["tc_id"]


def max_slope_in_temp_band(df_tc_one, tmin, tmax):
    g = df_tc_one.sort_values("time_s")
    t = g["time_s"].to_numpy(dtype=float)
    y = g["temp_c"].to_numpy(dtype=float)
    best = None
    for i in range(1, len(g)):
        dt = t[i] - t[i - 1]
        if dt <= 0:
            continue
        if (tmin <= y[i - 1] <= tmax) and (tmin <= y[i] <= tmax):
            s = (y[i] - y[i - 1]) / dt
            best = s if best is None else max(best, s)
    return best


def time_above_threshold_s(df_tc_one, thr):
    g = df_tc_one.sort_values("time_s")
    t = g["time_s"].to_numpy(dtype=float)
    y = g["temp_c"].to_numpy(dtype=float)
    total = 0.0
    for i in range(1, len(g)):
        t0, t1 = t[i - 1], t[i]
        y0, y1 = y[i - 1], y[i]
        if t1 <= t0:
            continue
        if y0 > thr and y1 > thr:
            total += (t1 - t0)
            continue
        crosses = (y0 <= thr < y1) or (y1 <= thr < y0)
        if crosses and (y1 != y0):
            frac = (thr - y0) / (y1 - y0)
            tcross = t0 + frac * (t1 - t0)
            if y0 <= thr and y1 > thr:
                total += (t1 - tcross)
            else:
                total += (tcross - t0)
    return total


# Pre-compute per run: representative TC + metrics
run_ids = sorted(runs["run_id"].unique())
per_run = {}
for rid in run_ids:
    df_run = tc[tc["run_id"] == rid]
    rep_tc = select_representative_tc(df_run)
    df_rep = df_run[df_run["tc_id"] == rep_tc]
    liquidus = float(runs.loc[runs["run_id"] == rid, "solder_liquidus_c"].iloc[0])

    max_ramp = max_slope_in_temp_band(df_rep, cfg["preheat_tmin"], cfg["preheat_tmax"])
    tal = time_above_threshold_s(df_rep, liquidus)
    peak = float(df_rep["temp_c"].max()) if len(df_rep) else None
    per_run[rid] = {
        "rep_tc": rep_tc,
        "liquidus": liquidus,
        "max_ramp": max_ramp,
        "tal": tal,
        "peak": peak,
    }

# ---------- Q1 ----------
violating_q1 = []
max_ramp_by_run = {}
for rid in run_ids:
    d = per_run[rid]
    mr = d["max_ramp"]
    max_ramp_by_run[rid] = {"tc_id": d["rep_tc"], "max_preheat_ramp_c_per_s": r2(mr)}
    if mr is not None and mr > cfg["ramp_limit_c_per_s"]:
        violating_q1.append(rid)

q1 = {
    "ramp_rate_limit_c_per_s": cfg["ramp_limit_c_per_s"],
    "violating_runs": sorted(violating_q1),
    "max_ramp_by_run": {k: max_ramp_by_run[k] for k in sorted(max_ramp_by_run)},
}
with open(os.path.join(OUT_DIR, "q01.json"), "w") as f:
    json.dump(q1, f, indent=2)

# ---------- Q2 ----------
q2 = []
for rid in run_ids:
    d = per_run[rid]
    tal = d["tal"]
    status = "compliant" if (tal is not None and cfg["tal_min_s"] <= tal <= cfg["tal_max_s"]) else "non-compliant"
    q2.append({
        "run_id": rid,
        "tc_id": d["rep_tc"],
        "tal_s": r2(tal),
        "required_min_tal_s": cfg["tal_min_s"],
        "required_max_tal_s": cfg["tal_max_s"],
        "status": status,
    })
q2 = sorted(q2, key=lambda x: x["run_id"])
with open(os.path.join(OUT_DIR, "q02.json"), "w") as f:
    json.dump(q2, f, indent=2)

# ---------- Q3 ----------
failing_q3 = []
min_peak_by_run = {}
for rid in run_ids:
    d = per_run[rid]
    required_min_peak = d["liquidus"] + cfg["peak_margin_c"]
    peak = d["peak"]
    min_peak_by_run[rid] = {
        "tc_id": d["rep_tc"],
        "peak_temp_c": r2(peak),
        "required_min_peak_c": r2(required_min_peak),
    }
    if peak is None or peak < required_min_peak:
        failing_q3.append(rid)

q3 = {
    "failing_runs": sorted(failing_q3),
    "min_peak_by_run": {k: min_peak_by_run[k] for k in sorted(min_peak_by_run)},
}
with open(os.path.join(OUT_DIR, "q03.json"), "w") as f:
    json.dump(q3, f, indent=2)

# ---------- Q4 ----------
# Handbook page 12: LINE SPEED (MIN) = boards_per_min * board_length_cm / loading_factor.
# Conveyor must run at least that fast to avoid product jams (sizing feasibility).
q4 = []
for rid in run_ids:
    row = runs[runs["run_id"] == rid].iloc[0]
    bpm = float(row["boards_per_min"])
    blen = float(row["board_length_cm"])
    lf = float(row["loading_factor"])
    actual = float(row["conveyor_speed_cm_min"])
    if lf > 0:
        req_min = bpm * blen / lf
    else:
        req_min = None
    meets = (req_min is not None) and (actual >= req_min)
    q4.append({
        "run_id": rid,
        "required_min_speed_cm_min": r2(req_min),
        "actual_speed_cm_min": r2(actual),
        "meets": bool(meets),
    })
q4 = sorted(q4, key=lambda x: x["run_id"])
with open(os.path.join(OUT_DIR, "q04.json"), "w") as f:
    json.dump(q4, f, indent=2)

# ---------- Q5 ----------
# Filter to runs compliant on Q1, Q2, Q3, Q4; rank by fp_yield_pct desc, boards_per_min desc, run_id asc.
q1_pass = {rid: (per_run[rid]["max_ramp"] is not None and per_run[rid]["max_ramp"] <= cfg["ramp_limit_c_per_s"])
           for rid in run_ids}
q2_pass = {r["run_id"]: (r["status"] == "compliant") for r in q2}
q3_pass = {rid: rid not in failing_q3 for rid in run_ids}
q4_pass = {r["run_id"]: r["meets"] for r in q4}

# Get fp_yield_pct per run from defects SUMMARY rows
yield_by_run = {}
sum_rows = defects[defects["inspection_stage"] == "SUMMARY"]
for _, r in sum_rows.iterrows():
    yield_by_run[str(r["run_id"])] = float(r["fp_yield_pct"]) if pd.notna(r["fp_yield_pct"]) else None

boards_per_min_by_run = dict(zip(runs["run_id"], runs["boards_per_min"].astype(float)))
family_by_run = dict(zip(runs["run_id"], runs["board_family"].astype(str)))

families = sorted(set(family_by_run.values()))
q5 = []
for fam in families:
    fam_runs = [rid for rid, f in family_by_run.items() if f == fam]
    fam_runs_sorted = sorted(fam_runs)
    eligible = [rid for rid in fam_runs_sorted
                if q1_pass.get(rid) and q2_pass.get(rid) and q3_pass.get(rid) and q4_pass.get(rid)]
    pool = eligible if eligible else fam_runs_sorted

    def sort_key(rid):
        y = yield_by_run.get(rid)
        b = boards_per_min_by_run.get(rid, 0.0)
        return (-(y if y is not None else -1e9), -b, rid)

    ranked = sorted(pool, key=sort_key)
    best = ranked[0]
    runners = sorted([rid for rid in fam_runs_sorted if rid != best])
    q5.append({
        "board_family": fam,
        "best_run_id": best,
        "runner_up_run_ids": runners,
    })

q5 = sorted(q5, key=lambda x: x["board_family"])
with open(os.path.join(OUT_DIR, "q05.json"), "w") as f:
    json.dump(q5, f, indent=2)

# Print summaries
print("Q1 violating:", len(violating_q1))
print("Q2 non-compliant:", sum(1 for r in q2 if r["status"] != "compliant"))
print("Q3 failing:", len(failing_q3))
print("Q4 not-meets:", sum(1 for r in q4 if not r["meets"]))
print("Q5 families:", len(q5))
for row in q5:
    print(" ", row["board_family"], "->", row["best_run_id"], "runners:", len(row["runner_up_run_ids"]))
