// Stock market visualization: sector-clustered bubble chart + linked data table.
// Uses D3 v6. Deterministic layout (fixed simulation seed via sorted inputs and
// fixed number of ticks; no randomness, no transitions).

const CHART_WIDTH = 860;
const CHART_HEIGHT = 640;
const MARGIN = { top: 20, right: 20, bottom: 20, left: 20 };

const SECTOR_ORDER = [
    "Information Technology",
    "Financial",
    "Industry",
    "Energy",
    "ETF",
];

const SECTOR_COLORS = {
    "Information Technology": "#2563eb",
    "Financial": "#059669",
    "Industry": "#d97706",
    "Energy": "#dc2626",
    "ETF": "#7c3aed",
};

// Fixed uniform bubble radius for ETFs (no market cap available).
const ETF_RADIUS = 22;

function formatMarketCap(value) {
    if (value == null || isNaN(value) || value === 0) return "—";
    const abs = Math.abs(value);
    if (abs >= 1e12) return (value / 1e12).toFixed(2) + "T";
    if (abs >= 1e9) return (value / 1e9).toFixed(2) + "B";
    if (abs >= 1e6) return (value / 1e6).toFixed(2) + "M";
    if (abs >= 1e3) return (value / 1e3).toFixed(2) + "K";
    return value.toFixed(0);
}

function parseRow(d) {
    const mc = d.marketCap && d.marketCap.trim() !== "" ? +d.marketCap : null;
    return {
        ticker: d.ticker,
        sector: d.sector,
        name: d["full name"],
        marketCap: Number.isFinite(mc) ? mc : null,
        country: d.country || "",
        website: d.website || "",
    };
}

d3.csv("data/stock-descriptions.csv", parseRow).then((rawData) => {
    // Deterministic ordering: by sector then by descending market cap then ticker.
    const data = rawData.slice().sort((a, b) => {
        const sa = SECTOR_ORDER.indexOf(a.sector);
        const sb = SECTOR_ORDER.indexOf(b.sector);
        if (sa !== sb) return sa - sb;
        const ma = a.marketCap || 0;
        const mb = b.marketCap || 0;
        if (mb !== ma) return mb - ma;
        return d3.ascending(a.ticker, b.ticker);
    });

    buildBubbleChart(data);
    buildTable(data);
});

function buildBubbleChart(data) {
    const innerW = CHART_WIDTH - MARGIN.left - MARGIN.right;
    const innerH = CHART_HEIGHT - MARGIN.top - MARGIN.bottom;

    // Radius scale for companies (has market cap). ETFs use fixed radius.
    const nonEtfCaps = data
        .filter((d) => d.sector !== "ETF" && d.marketCap)
        .map((d) => d.marketCap);
    const radius = d3
        .scaleSqrt()
        .domain([d3.min(nonEtfCaps), d3.max(nonEtfCaps)])
        .range([14, 55]);

    data.forEach((d) => {
        d.r = d.sector === "ETF" ? ETF_RADIUS : radius(d.marketCap);
    });

    // Cluster centers arranged around the middle of the plot area so that
    // all sectors stay reasonably centered rather than being pushed to edges.
    const sectors = SECTOR_ORDER.filter((s) =>
        data.some((d) => d.sector === s)
    );
    const clusterCenters = computeClusterCenters(sectors, innerW, innerH);

    // Deterministic initial positions: place each bubble at its cluster center
    // with a tiny sector-index offset so the force simulation converges the
    // same way on every run.
    data.forEach((d, i) => {
        const c = clusterCenters[d.sector];
        d.x = c.x + ((i % 7) - 3);
        d.y = c.y + ((i % 5) - 2);
    });

    const svg = d3
        .select("#bubble-chart")
        .append("svg")
        .attr("viewBox", `0 0 ${CHART_WIDTH} ${CHART_HEIGHT}`)
        .attr("preserveAspectRatio", "xMidYMid meet");

    const g = svg
        .append("g")
        .attr("transform", `translate(${MARGIN.left},${MARGIN.top})`);

    // Force simulation: cluster by sector via forceX/forceY toward each
    // sector's cluster center, plus forceCollide to prevent overlap.
    const simulation = d3
        .forceSimulation(data)
        .force(
            "x",
            d3.forceX((d) => clusterCenters[d.sector].x).strength(0.18)
        )
        .force(
            "y",
            d3.forceY((d) => clusterCenters[d.sector].y).strength(0.18)
        )
        .force(
            "collide",
            d3.forceCollide((d) => d.r + 1.5).iterations(3)
        )
        .force("center", d3.forceCenter(innerW / 2, innerH / 2).strength(0.02))
        .stop();

    // Run a fixed number of ticks for a deterministic layout.
    const TICKS = 400;
    for (let i = 0; i < TICKS; i++) simulation.tick();

    // Clamp inside plot area to avoid stragglers.
    data.forEach((d) => {
        d.x = Math.max(d.r, Math.min(innerW - d.r, d.x));
        d.y = Math.max(d.r, Math.min(innerH - d.r, d.y));
    });

    const nodeGroups = g
        .selectAll("g.node")
        .data(data, (d) => d.ticker)
        .enter()
        .append("g")
        .attr("class", "node")
        .attr("data-ticker", (d) => d.ticker)
        .attr("transform", (d) => `translate(${d.x},${d.y})`);

    nodeGroups
        .append("circle")
        .attr("class", "bubble")
        .attr("r", (d) => d.r)
        .attr("fill", (d) => SECTOR_COLORS[d.sector] || "#64748b")
        .attr("fill-opacity", 0.85);

    nodeGroups
        .append("text")
        .attr("class", "bubble-label")
        .text((d) => d.ticker)
        .style("font-size", (d) => {
            // Scale label size within a small range so long tickers still fit.
            const size = Math.max(9, Math.min(14, d.r * 0.45));
            return `${size}px`;
        });

    // Interactivity: tooltip + click selection wired to the table.
    const tooltip = d3.select("#tooltip");

    nodeGroups
        .on("mouseover", function (event, d) {
            if (d.sector === "ETF") return; // No tooltip for ETFs.
            tooltip
                .classed("visible", true)
                .html(
                    `<div class="tt-ticker">${d.ticker}</div>` +
                        `<div class="tt-name">${d.name}</div>` +
                        `<div class="tt-sector">${d.sector}</div>`
                )
                .style("left", event.pageX + 12 + "px")
                .style("top", event.pageY - 12 + "px");
        })
        .on("mousemove", function (event, d) {
            if (d.sector === "ETF") return;
            tooltip
                .style("left", event.pageX + 12 + "px")
                .style("top", event.pageY - 12 + "px");
        })
        .on("mouseout", function () {
            tooltip.classed("visible", false);
        })
        .on("click", function (event, d) {
            selectTicker(d.ticker);
        });

    buildLegend(sectors);
}

function computeClusterCenters(sectors, innerW, innerH) {
    // Place sector centers on a compact ring around the middle so that all
    // clusters sit near the visual center of the chart.
    const centers = {};
    const cx = innerW / 2;
    const cy = innerH / 2;
    const radius = Math.min(innerW, innerH) * 0.22;
    const n = sectors.length;

    sectors.forEach((s, i) => {
        // Start at top and go clockwise.
        const angle = -Math.PI / 2 + (i * 2 * Math.PI) / n;
        centers[s] = {
            x: cx + radius * Math.cos(angle),
            y: cy + radius * Math.sin(angle),
        };
    });

    return centers;
}

function buildLegend(sectors) {
    const legend = d3.select("#legend");
    legend
        .selectAll("div.legend-item")
        .data(sectors)
        .enter()
        .append("div")
        .attr("class", "legend-item")
        .html(
            (s) =>
                `<span class="legend-swatch" style="background:${SECTOR_COLORS[s]}"></span>` +
                `<span>${s}</span>`
        );
}

function buildTable(data) {
    const tbody = d3.select("#stock-table tbody");

    const rows = tbody
        .selectAll("tr")
        .data(data, (d) => d.ticker)
        .enter()
        .append("tr")
        .attr("data-ticker", (d) => d.ticker)
        .on("click", function (event, d) {
            selectTicker(d.ticker);
        });

    rows.append("td").attr("class", "ticker-cell").text((d) => d.ticker);
    rows.append("td").text((d) => d.name);
    rows.append("td").text((d) => d.sector);
    rows.append("td")
        .attr("class", "market-cap-cell")
        .text((d) => formatMarketCap(d.marketCap));
}

function selectTicker(ticker) {
    // Toggle selected class on both the bubble and the matching table row.
    const alreadySelected = d3
        .select(`.node[data-ticker="${ticker}"] circle`)
        .classed("selected");

    d3.selectAll(".bubble").classed("selected", false);
    d3.selectAll("#stock-table tbody tr").classed("selected", false);

    if (!alreadySelected) {
        d3.select(`.node[data-ticker="${ticker}"] circle`).classed(
            "selected",
            true
        );
        const row = d3.select(`#stock-table tbody tr[data-ticker="${ticker}"]`);
        row.classed("selected", true);
        // Scroll the selected row into view within the scrollable table.
        const rowNode = row.node();
        if (rowNode && rowNode.scrollIntoView) {
            rowNode.scrollIntoView({ block: "nearest" });
        }
    }
}
