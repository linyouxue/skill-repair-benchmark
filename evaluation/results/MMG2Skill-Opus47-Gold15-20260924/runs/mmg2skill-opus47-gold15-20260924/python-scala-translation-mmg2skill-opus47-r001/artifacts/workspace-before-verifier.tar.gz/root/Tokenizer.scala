import java.time.{LocalDate, LocalDateTime}
import java.time.format.DateTimeFormatter
import java.nio.charset.{Charset, StandardCharsets}

import scala.language.implicitConversions

// ============================================================================
// Token types
// ============================================================================

sealed abstract class TokenType(val value: String)

object TokenType {
  case object STRING     extends TokenType("string")
  case object NUMERIC    extends TokenType("numeric")
  case object TEMPORAL   extends TokenType("temporal")
  case object STRUCTURED extends TokenType("structured")
  case object BINARY     extends TokenType("binary")
  case object NULL       extends TokenType("null")
}

// ============================================================================
// Structural typing: anything that can produce its own token string
// ============================================================================

trait Tokenizable {
  def toToken: String
}

// ============================================================================
// Core immutable Token
// ============================================================================

final case class Token(
    value: String,
    tokenType: TokenType,
    metadata: Map[String, Any] = Map.empty
) {
  def withMetadata(entries: (String, Any)*): Token =
    copy(metadata = metadata ++ entries)
}

// ============================================================================
// Base tokenizer
// ============================================================================

abstract class BaseTokenizer[A] {
  def tokenize(value: A): Token

  def tokenizeBatch(values: IterableOnce[A]): Iterator[Token] =
    values.iterator.map(tokenize)
}

// ============================================================================
// StringTokenizer: accepts either String or Array[Byte]
// ============================================================================

sealed trait StringLike
object StringLike {
  final case class StringValue(s: String)      extends StringLike
  final case class BytesValue(bytes: Array[Byte]) extends StringLike

  implicit def fromString(s: String): StringLike        = StringValue(s)
  implicit def fromBytes(b: Array[Byte]): StringLike    = BytesValue(b)
}

final class StringTokenizer(
    val encoding: Charset = StandardCharsets.UTF_8,
    val normalizer: String => String = identity
) extends BaseTokenizer[StringLike] {

  def tokenize(value: StringLike): Token = {
    val raw = value match {
      case StringLike.StringValue(s) => s
      case StringLike.BytesValue(b)  => new String(b, encoding)
    }
    Token(normalizer(raw), TokenType.STRING)
  }
}

object StringTokenizer {
  def apply(
      encoding: Charset = StandardCharsets.UTF_8,
      normalizer: String => String = identity
  ): StringTokenizer = new StringTokenizer(encoding, normalizer)
}

// ============================================================================
// NumericTokenizer: precision-aware numeric formatting
// ============================================================================

final class NumericTokenizer[A](
    val precision: Int = 6,
    val formatOptions: Map[String, Any] = Map.empty
)(implicit num: Numeric[A])
    extends BaseTokenizer[A] {

  def tokenize(value: A): Token = {
    val strValue = value match {
      case d: BigDecimal => s"%.${precision}f".format(d)
      case f: Double     => s"%.${precision}f".format(f)
      case f: Float      => s"%.${precision}f".format(f)
      case other         => other.toString
    }
    Token(
      strValue,
      TokenType.NUMERIC,
      Map("original_type" -> value.getClass.getSimpleName)
    )
  }
}

object NumericTokenizer {
  def apply[A: Numeric](
      precision: Int = 6,
      formatOptions: Map[String, Any] = Map.empty
  ): NumericTokenizer[A] = new NumericTokenizer[A](precision, formatOptions)
}

// ============================================================================
// TemporalTokenizer: handles LocalDateTime and LocalDate uniformly
// ============================================================================

sealed trait Temporal
object Temporal {
  final case class DateTimeValue(v: LocalDateTime) extends Temporal
  final case class DateValue(v: LocalDate)         extends Temporal

  implicit def fromDateTime(v: LocalDateTime): Temporal = DateTimeValue(v)
  implicit def fromDate(v: LocalDate): Temporal         = DateValue(v)
}

final class TemporalTokenizer(val pattern: Option[String] = None)
    extends BaseTokenizer[Temporal] {

  import TemporalTokenizer._

  def tokenize(value: Temporal): Token = {
    val formatted = value match {
      case Temporal.DateTimeValue(dt) =>
        pattern.map(DateTimeFormatter.ofPattern).getOrElse(IsoFormat).format(dt)
      case Temporal.DateValue(d) =>
        pattern.map(DateTimeFormatter.ofPattern).getOrElse(DateFormat).format(d)
    }
    Token(formatted, TokenType.TEMPORAL)
  }
}

object TemporalTokenizer {
  val IsoFormat: DateTimeFormatter  = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
  val DateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

  def apply(pattern: Option[String] = None): TemporalTokenizer =
    new TemporalTokenizer(pattern)
}

// ============================================================================
// UniversalTokenizer: dispatch by runtime type
// ============================================================================

final class UniversalTokenizer(
    stringTokenizer: StringTokenizer     = StringTokenizer(),
    numericTokenizer: NumericTokenizer[BigDecimal] =
      NumericTokenizer[BigDecimal](),
    temporalTokenizer: TemporalTokenizer = TemporalTokenizer()
) {

  def tokenize(value: Any): Token = value match {
    case null                => Token("NULL", TokenType.NULL)
    case t: Tokenizable      => Token(t.toToken, TokenType.STRUCTURED)
    case s: String           => stringTokenizer.tokenize(StringLike.StringValue(s))
    case b: Array[Byte]      => stringTokenizer.tokenize(StringLike.BytesValue(b))
    case i: Int              => numericTokenizer.tokenize(BigDecimal(i))
      .copy(metadata = Map("original_type" -> "Integer"))
    case l: Long             => numericTokenizer.tokenize(BigDecimal(l))
      .copy(metadata = Map("original_type" -> "Long"))
    case d: Double           => numericTokenizer.tokenize(BigDecimal(d))
      .copy(metadata = Map("original_type" -> "Double"))
    case f: Float            => numericTokenizer.tokenize(BigDecimal(f.toDouble))
      .copy(metadata = Map("original_type" -> "Float"))
    case bd: BigDecimal      => numericTokenizer.tokenize(bd)
    case dt: LocalDateTime   => temporalTokenizer.tokenize(Temporal.DateTimeValue(dt))
    case ld: LocalDate       => temporalTokenizer.tokenize(Temporal.DateValue(ld))
    case other               => Token(other.toString, TokenType.STRING, Map("fallback" -> true))
  }

  def tokenizeBatch(values: IterableOnce[Any]): Iterator[Token] =
    values.iterator.map(tokenize)
}

object UniversalTokenizer {
  def apply(): UniversalTokenizer = new UniversalTokenizer()
}

// ============================================================================
// WhitespaceTokenizer: split text into word tokens
// ============================================================================

final class WhitespaceTokenizer(
    val lowercase: Boolean       = false,
    val minLength: Int           = 0,
    val maxLength: Option[Int]   = None,
    val stripPunctuation: Boolean = false
) {

  import WhitespaceTokenizer._

  private def processToken(word: String): Option[String] = {
    val stripped =
      if (stripPunctuation) word.dropWhile(Punctuation.contains).reverse
        .dropWhile(Punctuation.contains).reverse
      else word

    val cased = if (lowercase) stripped.toLowerCase else stripped

    val truncated = maxLength match {
      case Some(m) if cased.length > m => cased.take(m)
      case _                            => cased
    }

    if (truncated.isEmpty || truncated.length < minLength) None
    else Some(truncated)
  }

  def tokenize(text: String): List[Token] =
    Whitespace.split(text).iterator
      .filter(_.nonEmpty)
      .zipWithIndex
      .flatMap { case (word, i) =>
        processToken(word).map { processed =>
          Token(
            processed,
            TokenType.STRING,
            Map("position" -> i, "original" -> word)
          )
        }
      }
      .toList

  def tokenizeToStrings(text: String): List[String] =
    tokenize(text).map(_.value)

  def tokenizeWithPositions(text: String): List[(String, Int, Int)] = {
    val builder = List.newBuilder[(String, Int, Int)]
    var cursor  = 0
    for (word <- Whitespace.split(text) if word.nonEmpty) {
      val start = text.indexOf(word, cursor)
      val end   = start + word.length
      processToken(word).foreach(p => builder += ((p, start, end)))
      cursor = end
    }
    builder.result()
  }

  def countTokens(text: String): Int = tokenize(text).size
}

object WhitespaceTokenizer {
  private val Whitespace  = "\\s+".r
  private val Punctuation: Set[Char] = ".,!?;:'\"()[]{}".toSet

  def apply(
      lowercase: Boolean       = false,
      minLength: Int           = 0,
      maxLength: Option[Int]   = None,
      stripPunctuation: Boolean = false
  ): WhitespaceTokenizer =
    new WhitespaceTokenizer(lowercase, minLength, maxLength, stripPunctuation)
}

// ============================================================================
// TokenizerBuilder: immutable fluent builder
// ============================================================================

final case class TokenizerBuilder[A](
    normalizers: Vector[String => String] = Vector.empty,
    validators:  Vector[A => Boolean]     = Vector.empty,
    metadata:    Map[String, Any]         = Map.empty
) {

  def withNormalizer(normalizer: String => String): TokenizerBuilder[A] =
    copy(normalizers = normalizers :+ normalizer)

  def withValidator(validator: A => Boolean): TokenizerBuilder[A] =
    copy(validators = validators :+ validator)

  def withMetadata(entries: (String, Any)*): TokenizerBuilder[A] =
    copy(metadata = metadata ++ entries)

  def build(): A => Token = { value =>
    validators.find(v => !v(value)).foreach { _ =>
      throw new IllegalArgumentException(s"Validation failed for $value")
    }
    val normalized = normalizers.foldLeft(value.toString)((acc, f) => f(acc))
    Token(normalized, TokenType.STRING, metadata)
  }
}

object TokenizerBuilder {
  def apply[A](): TokenizerBuilder[A] = new TokenizerBuilder[A]()
}
