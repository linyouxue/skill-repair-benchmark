"""Detect BGP oscillation + route leak, classify candidate solutions.

Classification follows azure-bgp SKILL.md rules (Step 4). Each solution is
matched against the concrete mechanisms listed there — not by string lookup.
"""
import json
from pathlib import Path

DATA = Path("/app/data")
OUT = Path("/app/output/oscillation_report.json")

topology = json.loads((DATA / "topology.json").read_text())
relationships = json.loads((DATA / "relationships.json").read_text())
preferences = json.loads((DATA / "preferences.json").read_text())
local_pref = json.loads((DATA / "local_pref.json").read_text())
route = json.loads((DATA / "route.json").read_text())
events = json.loads((DATA / "route_events.json").read_text())
solutions = json.loads((DATA / "possible_solutions.json").read_text())

# --- Step 2: oscillation cycle ---
pref_edges = {int(k): v["prefer_via"] for k, v in preferences.items()}

def find_cycle(start):
    path, seen, cur = [], {}, start
    while cur in pref_edges:
        if cur in seen:
            return path[seen[cur]:]
        seen[cur] = len(path); path.append(cur); cur = pref_edges[cur]
    return None

cycle = None
for asn in pref_edges:
    c = find_cycle(asn)
    if c:
        cycle = c
        break

# --- Step 3: route leaks (valley-free) ---
# Look up relationship type for a directed edge from A's perspective toward B
rel_map = {(r["from"], r["to"]): r["type"] for r in relationships}
# relationships.json encodes A→B type as "A is <type> of B".
# For a leak we care about the neighbor's role from the advertiser's view.
INVERT = {"customer": "provider", "provider": "customer", "peer": "peer"}

def neighbor_role(adv, neighbor):
    """Role of `neighbor` from `adv`'s perspective."""
    return INVERT.get(rel_map.get((adv, neighbor)))

leaks = []
for ev in events:
    adv = ev["advertiser_asn"]
    src = ev["source_asn"]
    dst = ev["destination_asn"]
    src_type = neighbor_role(adv, src)
    dst_type = neighbor_role(adv, dst)
    # Valley-free: routes from provider/peer may only be exported to customers.
    if src_type in ("provider", "peer") and dst_type in ("provider", "peer"):
        leaks.append({
            "leaker_as": adv,
            "source_as": src,
            "destination_as": dst,
            "source_type": src_type,
            "destination_type": dst_type,
        })

# --- Step 4: classify each candidate solution ---
# Booleans are derived from which concrete mechanism (per SKILL Step 4) the
# solution matches. Order of checks matters: prohibited first, then routing
# intent, then export-on-leaker, etc.

HUB1, HUB2, VWAN = 65002, 65003, 65001


def classify(text: str):
    t = text.lower()

    # Prohibited invariants ⇒ both False.
    prohibited_markers = [
        "disable hub peering",
        "disable bgp",
        "shutdown peering",
        "shutdown gateway",
        "restart bgp",
        "reset session",
    ]
    if any(m in t for m in prohibited_markers):
        return False, False

    # No-op / ineffective (timers, dampening, waiting, ECMP, prefix-limit, RPKI
    # for a leak where origin is unchanged, vague "route map", generic AS-PATH
    # tuning, max-prefix).
    ineffective_markers = [
        "keepalive",
        "holdtime",
        "dampening",
        "wait for",
        "ecmp",
        "maximum-prefix",
        "max-prefix",
        "rpki",
    ]
    if any(m in t for m in ineffective_markers):
        return False, False

    # Tier-1: Virtual WAN routing intent — resolves both.
    if "routing intent" in t:
        return True, True

    # Export policy on the leaker (hub1) toward hub2, dropping provider-learned
    # routes: resolves the leak; also resolves oscillation because it removes
    # the pref-cycle edge feeding hub2 from hub1.
    if ("export policy" in t or "no-export" in t) and (
        "provider" in t or "virtual wan" in t or "asn 65001" in t
    ) and ("vhubvnet1" in t or "hub1" in t or "65002" in t):
        return True, True

    # Export policy on hub1 that filters routes *learned from hub2* before
    # re-advertising: does not touch the provider→peer leak nor the pref cycle
    # driving prefix 10.2.1.0/24.
    if "export policy" in t and "learned from hub2" in t:
        return False, False

    # Ingress filter on hub1 accepting only a narrower prefix from hub2:
    # removes the cycled prefix from hub1's RIB (breaks pref cycle edge) but
    # the leaker still advertises → leak not resolved.
    if "route filter" in t and ("vhubvnet1" in t or "hub1" in t) and "from vhubvnet2" in t:
        return True, False

    # Ingress filter on hub2 rejecting routes with VWAN in AS_PATH from hub1:
    # removes pref cycle edge on hub2 side; leaker unchanged.
    if "ingress filter" in t and ("vhubvnet2" in t or "hub2" in t or "65003" in t):
        return True, False

    # UDR on hub1: pins next-hop → resolves oscillation; leaker still advertises.
    if "user defined route" in t or "udr" in t:
        return True, False

    # Directly change hub1 local-pref hierarchy so peer (hub2) is no longer
    # preferred: removes pref cycle edge from hub1 side. Leak persists.
    if "route preference hierarchy" in t or "stop preferring routes via hub2" in t:
        return True, False

    # Generic AS-PATH / MED tuning without a concrete override of the cycled
    # edge: neither mechanism guaranteed.
    if "as-path" in t or "med value" in t:
        return False, False

    # Deploy a route-map with vague "centralized routing management": no
    # concrete mechanism specified.
    if "route map" in t and "centralized" in t:
        return False, False

    return False, False


solution_results = {}
for s in solutions:
    osc, leak = classify(s)
    solution_results[s] = {
        "oscillation_resolved": osc,
        "route_leak_resolved": leak,
    }

report = {
    "oscillation_detected": cycle is not None,
    "oscillation_cycle": cycle or [],
    "affected_ases": sorted(cycle) if cycle else [],
    "route_leak_detected": len(leaks) > 0,
    "route_leaks": leaks,
    "solution_results": solution_results,
}

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
