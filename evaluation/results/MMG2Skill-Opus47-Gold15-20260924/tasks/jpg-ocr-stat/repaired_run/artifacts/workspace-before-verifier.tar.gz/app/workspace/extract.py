import os
import re
from collections import Counter

import pandas as pd
import pytesseract
from PIL import Image, ImageFilter, ImageOps

IMG_DIR = "/app/workspace/dataset/img"
OUT_XLSX = "/app/workspace/stat_ocr.xlsx"

# Priority tiers, most-specific first (indexed 0..3).
KEYWORD_TIERS = [
    ["GRAND TOTAL"],
    ["TOTAL RM", "TOTAL: RM"],
    ["TOTAL AMOUNT"],
    ["TOTAL", "AMOUNT", "TOTAL DUE", "AMOUNT DUE", "BALANCE DUE", "NETT TOTAL", "NET TOTAL"],
]

# Exclusion keywords as listed in the task hint. Only applied to tier-3 (generic
# TOTAL/AMOUNT) matches; strong-keyword tiers (0-2) always take precedence.
EXCLUSIONS = [
    "SUBTOTAL",
    "SUB TOTAL",
    "TAX",
    "GST",
    "SST",
    "DISCOUNT",
    "CHANGE",
    "CASH TENDERED",
]

NUM_RE = re.compile(r"(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})\b")


def ocr_variants(image_path):
    img = Image.open(image_path)
    gray = ImageOps.autocontrast(ImageOps.grayscale(img))
    up2 = gray.resize((gray.width * 2, gray.height * 2), Image.LANCZOS)
    up3 = gray.resize((gray.width * 3, gray.height * 3), Image.LANCZOS).filter(ImageFilter.SHARPEN)
    return [
        pytesseract.image_to_string(img),
        pytesseract.image_to_string(gray, config="--psm 6"),
        pytesseract.image_to_string(up2, config="--psm 6"),
        pytesseract.image_to_string(up3, config="--psm 4"),
    ]


def line_has_exclusion(line_up):
    for kw in EXCLUSIONS:
        if kw in line_up:
            return True
    return False


def match_tier(line_up):
    """Return index of highest-priority tier whose keyword appears, else -1."""
    for tier_idx, kws in enumerate(KEYWORD_TIERS):
        for kw in kws:
            if kw in line_up:
                return tier_idx
    return -1


def last_number(text):
    matches = NUM_RE.findall(text)
    if not matches:
        return None
    return float(matches[-1].replace(",", ""))


SUMMARY_SECTION_RE = re.compile(r"\b(GST|TAX|SST)\s+SUMMARY\b")


def find_totals_from_text(text):
    """Return list of (tier_index, value) candidates from a single OCR variant."""
    candidates = []
    lines = [ln.rstrip() for ln in text.splitlines()]
    n = len(lines)
    in_summary = False
    for i, line in enumerate(lines):
        line_up = line.upper()
        if not line_up.strip():
            continue
        if SUMMARY_SECTION_RE.search(line_up):
            in_summary = True
            continue
        if in_summary:
            # GST/TAX summary table rows must not contribute total candidates.
            continue
        tier_idx = match_tier(line_up)
        if tier_idx < 0:
            continue
        # Apply exclusion filter to every tier per the task hint.
        if line_has_exclusion(line_up):
            continue

        val = last_number(line)
        if val is not None:
            candidates.append((tier_idx, val))
            continue

        # Two-line fallback: only for the strongest tier (GRAND TOTAL) and only
        # when the keyword line has no digits at all. Other tiers produce too
        # many false positives from OCR-mangled column headers.
        if tier_idx == 0 and not re.search(r"\d", line):
            for j in range(i + 1, n):
                nxt = lines[j].strip()
                if not nxt:
                    continue
                if line_has_exclusion(nxt.upper()):
                    break
                nxt_val = last_number(nxt)
                if nxt_val is not None:
                    candidates.append((tier_idx, nxt_val))
                break
    return candidates


VARIANT_WEIGHTS = [1, 1, 2, 3]


def aggregate(all_variant_candidates):
    flat = []  # (tier, val, variant_idx)
    tiers_present = set()
    for v_idx, cands in enumerate(all_variant_candidates):
        # Dedup so a value appearing multiple times in one variant still counts once.
        seen = set()
        for t, val in cands:
            key = (t, val)
            if key in seen:
                continue
            seen.add(key)
            flat.append((t, val, v_idx))
            tiers_present.add(t)
    if not flat:
        return None
    best_tier = min(tiers_present)
    tier_items = [(val, v_idx) for t, val, v_idx in flat if t == best_tier]
    weights = {}
    max_v_idx = {}
    for val, v_idx in tier_items:
        weights[val] = weights.get(val, 0) + VARIANT_WEIGHTS[v_idx]
        max_v_idx[val] = max(max_v_idx.get(val, -1), v_idx)
    best_weight = max(weights.values())
    top_vals = [v for v, w in weights.items() if w == best_weight]
    if len(top_vals) == 1:
        return top_vals[0]
    # Tiebreak: prefer value present in the highest-index (most-trusted) variant.
    return max(top_vals, key=lambda v: max_v_idx[v])


DATE_PATTERNS = [
    (re.compile(r"\b(\d{1,2})[/\-](\d{1,2})[/\-](\d{4})\b"), "dmy4"),
    (re.compile(r"\b(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})\b"), "ymd"),
    (re.compile(r"\b(\d{1,2})[/\-](\d{1,2})[/\-](\d{2})\b"), "dmy2"),
]


def extract_date(text):
    for pattern, kind in DATE_PATTERNS:
        m = pattern.search(text)
        if not m:
            continue
        try:
            if kind == "dmy4":
                d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            elif kind == "ymd":
                y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            elif kind == "dmy2":
                d, mo, y = int(m.group(1)), int(m.group(2)), 2000 + int(m.group(3))
            if 1 <= mo <= 12 and 1 <= d <= 31 and 1900 <= y <= 2100:
                return f"{y:04d}-{mo:02d}-{d:02d}"
        except ValueError:
            continue
    return None


def extract_date_multi(variants):
    for text in variants:
        d = extract_date(text)
        if d:
            return d
    return None


def process_image(path):
    variants = ocr_variants(path)
    variant_cands = [find_totals_from_text(t) for t in variants]
    total = aggregate(variant_cands)
    date = extract_date_multi(variants)
    return date, total


def main():
    files = sorted(f for f in os.listdir(IMG_DIR) if f.lower().endswith((".jpg", ".jpeg", ".png")))
    rows = []
    for fname in files:
        path = os.path.join(IMG_DIR, fname)
        try:
            date, total = process_image(path)
        except Exception as e:
            print(f"[ERROR] {fname}: {e}")
            date, total = None, None
        total_str = f"{total:.2f}" if total is not None else None
        print(f"{fname}\t{date}\t{total_str}")
        rows.append({"filename": fname, "date": date, "total_amount": total_str})

    df = pd.DataFrame(rows, columns=["filename", "date", "total_amount"])
    df.to_excel(OUT_XLSX, sheet_name="results", index=False)
    print(f"Wrote {OUT_XLSX}")


if __name__ == "__main__":
    main()
