"""Redact author-identifying info from paper1/2/3 for blind review."""
import fitz
import re
import os

os.makedirs('/root/redacted', exist_ok=True)


def redact_pdf(input_path, output_path, references_page, patterns):
    doc = fitz.open(input_path)
    for page_num, page in enumerate(doc):
        if references_page is not None and page_num >= references_page:
            continue
        for pattern in patterns:
            for rect in page.search_for(pattern):
                page.add_redact_annot(rect, fill=(0, 0, 0))
        page.apply_redactions()
    doc.save(output_path)
    doc.close()


def verify(orig_path, out_path):
    o = fitz.open(orig_path)
    r = fitz.open(out_path)
    o_len = sum(len(p.get_text()) for p in o)
    r_len = sum(len(p.get_text()) for p in r)
    print(f'  Pages: {len(o)} -> {len(r)}, chars: {o_len} -> {r_len} ({r_len/o_len:.1%} retained)')
    assert len(o) == len(r), 'page count changed'
    assert r_len >= o_len * 0.7, 'too much removed'
    o.close(); r.close()


def leak_scan(out_path, references_page, known_leaks, regexes):
    doc = fitz.open(out_path)
    hits = []
    for i, page in enumerate(doc):
        if references_page is not None and i >= references_page:
            break
        txt = page.get_text()
        for s in known_leaks:
            if s.lower() in txt.lower():
                hits.append((i, s))
        for pat in regexes:
            for m in re.finditer(pat, txt, flags=re.IGNORECASE):
                hits.append((i, m.group(0)))
    doc.close()
    return hits


# =========================================================================
# PAPER 1: Duke/Adobe VERA paper, references at page 9
# =========================================================================
paper1_patterns = [
    # Author names (full)
    'Yueqian Lin', 'Zhengmian Hu', 'Qinsi Wang', 'Yudong Liu', 'Hengfan Zhang',
    'Jayakumar Subramanian', 'Nikos Vlassis', 'Hai', 'Helen', 'Yiran Chen',
    # Affiliations
    'Duke University, Durham, NC, USA', 'Duke University', 'Duke',
    'Adobe, San Jose, CA, USA', 'Adobe',
    # Emails / correspondence
    'yueqian.lin@duke.edu', 'zhengmianh@adobe.com',
    'Correspondence:',
    # arXiv margin (rotated)
    'arXiv:2509.26542v1  [eess.AS]  30 Sep 2025',
    'arXiv:2509.26542v1', 'arXiv:2509.26542',
    '[eess.AS]', 'eess.AS', '30 Sep 2025',
    # Preprint banner (venue-like tag)
    'Preprint',
    # GitHub URL revealing username
    'https://github.com/linyueqian/VERA',
    'github.com/linyueqian/VERA',
    'linyueqian/VERA',
    'linyueqian',
]

# =========================================================================
# PAPER 2: Interspeech 2024 ACE-Opencpop/KiSing, references at page 4
# =========================================================================
paper2_patterns = [
    # Venue banner
    'Interspeech 2024', '1-5 September 2024, Kos, Greece',
    '10.21437/Interspeech.2024-33',
    # Author names (full)
    'Jiatong Shi', 'Yueqian Lin', 'Xinyi Bai', 'Keyi Zhang',
    'Yuning Wu', 'Yuxun Tang', 'Yifeng Yu', 'Qin', 'Jin', 'Shinji Watanabe',
    # Affiliations
    'Carnegie Mellon University', 'Duke Kunshan University',
    'Cornell University', 'Multimodal Art', 'Projection Community',
    'Renmin University of China', 'Georgia Institute of Technology',
    # Email
    'jiatongs@cs.cmu.edu',
    # Acknowledgements
    'Shengyuan Xu', 'Pengcheng Zhu',
    'Bridges2 system at PSC', 'Delta system at NCSA', 'ACCESS program',
    'CIS210014', 'IRI120008P',
    'NSF grants #2138259, #2138286, #2138307, #2137603, and',
    '#2138296',
    '#2138259', '#2138286', '#2138307', '#2137603',
    'National',
    'Natural Science Foundation of China (No.',
    '62072462',
    'PSC', 'NCSA',
]

# =========================================================================
# PAPER 3: ICML Workshop SPEECHPRUNE, references at page 4
# =========================================================================
paper3_patterns = [
    # Author names (full)
    'Yueqian Lin', 'Yuzhe Fu', 'Jingyang Zhang', 'Yudong Liu',
    'Jianyi Zhang', 'Jingwei Sun', 'Hai Li', 'Yiran Chen',
    # Affiliation
    'Duke University, Durham, USA', 'Duke University', 'Duke',
    # Email
    'yl768@duke.edu', 'yl768',
    # Grants
    'NSF 2112562', 'ARO W911NF-23-2-', 'ARO W911NF-23-2', 'W911NF-23-2-',
    'W911NF-23-2', 'W911NF', '2112562', '0224.',
    'and ARO', 'was supported in part by',
    # Venue
    'ICML Workshop on Machine Learning for Audio, Vancouver,',
    'ICML Workshop on Machine Learning for Audio',
    'ICML Workshop',
    'Vancouver,', 'Canada. Copyright 2025 by the author(s).',
    'Copyright 2025 by the author(s).',
]


jobs = [
    ('/root/paper1.pdf', '/root/redacted/paper1.pdf', 9, paper1_patterns),
    ('/root/paper2.pdf', '/root/redacted/paper2.pdf', 4, paper2_patterns),
    ('/root/paper3.pdf', '/root/redacted/paper3.pdf', 4, paper3_patterns),
]

for inp, outp, ref, pats in jobs:
    print(f'\n=== Redacting {inp} -> {outp} (refs at page {ref}) ===')
    redact_pdf(inp, outp, ref, pats)
    verify(inp, outp)

# Leak scans
common_regex = [
    r'\b\w+@\w+\.\w+',
    r'arXiv:\d{4}\.\d{4,5}',
    r'\[[a-z]+\.[A-Z]{2}\]',
    r'\d{1,2}\s+[A-Z][a-z]{2}\s+20\d{2}',
    r'10\.\d{4,9}/',
    r'W911NF[-\d]*',
]

leak_configs = [
    ('/root/redacted/paper1.pdf', 9,
     ['Yueqian', 'Zhengmian', 'Qinsi', 'Hengfan', 'Jayakumar', 'Vlassis', 'Duke', 'Adobe', 'linyueqian', 'Preprint'],
     common_regex),
    ('/root/redacted/paper2.pdf', 4,
     ['Jiatong', 'Xinyi', 'Yuning', 'Yuxun', 'Yifeng', 'Shinji', 'Watanabe', 'Carnegie', 'Kunshan', 'Cornell', 'Renmin', 'Georgia Institute', 'Shengyuan', 'Pengcheng', 'Interspeech', 'NSF grants', '62072462', 'NCSA', 'PSC'],
     common_regex),
    ('/root/redacted/paper3.pdf', 4,
     ['Yueqian', 'Yuzhe', 'Jingyang', 'Jianyi', 'Jingwei', 'Yiran', 'Duke', 'yl768', 'NSF', 'ARO', 'W911NF', 'ICML Workshop', 'Vancouver', '2112562', 'Copyright 2025'],
     common_regex),
]

print('\n\n=== LEAK SCANS ===')
for outp, ref, leaks, regexes in leak_configs:
    hits = leak_scan(outp, ref, leaks, regexes)
    print(f'\n{outp}:')
    if hits:
        for h in hits:
            print(f'  LEAK: page {h[0]} -> {h[1]!r}')
    else:
        print('  CLEAN')
