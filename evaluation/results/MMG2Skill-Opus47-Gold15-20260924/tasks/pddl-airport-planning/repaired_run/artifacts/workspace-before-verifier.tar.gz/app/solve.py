import json
import sys

from unified_planning.io import PDDLReader
from unified_planning.shortcuts import OneshotPlanner, PlanValidator
from unified_planning.engines import PlanGenerationResultStatus, ValidationResultStatus
import unified_planning.shortcuts as up_shortcuts

up_shortcuts.get_environment().credits_stream = None

with open("problem.json") as f:
    tasks = json.load(f)

for task in tasks:
    tid = task["id"]
    print(f"[{tid}] parsing domain={task['domain']} problem={task['problem']}", flush=True)
    problem = PDDLReader().parse_problem(task["domain"], task["problem"])

    print(f"[{tid}] solving...", flush=True)
    with OneshotPlanner(name="pyperplan") as planner:
        result = planner.solve(problem)

    if result.status != PlanGenerationResultStatus.SOLVED_SATISFICING:
        print(f"[{tid}] FAILED: {result.status}", flush=True)
        sys.exit(1)

    plan = result.plan
    print(f"[{tid}] plan has {len(plan.actions)} actions; validating...", flush=True)

    with PlanValidator(problem_kind=problem.kind) as validator:
        vr = validator.validate(problem, plan)
    if vr.status != ValidationResultStatus.VALID:
        print(f"[{tid}] INVALID plan: {vr.status}", flush=True)
        sys.exit(1)

    lines = [
        f"{a.action.name}({', '.join(str(p) for p in a.actual_parameters)})"
        for a in plan.actions
    ]
    with open(task["plan_output"], "w") as out:
        out.write("\n".join(lines))
    print(f"[{tid}] wrote {task['plan_output']}", flush=True)

print("All tasks done.")
