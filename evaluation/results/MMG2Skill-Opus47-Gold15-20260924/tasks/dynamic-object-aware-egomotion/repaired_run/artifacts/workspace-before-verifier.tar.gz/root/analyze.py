import cv2, json, math, numpy as np
from collections import Counter

VIDEO_PATH = "/root/input.mp4"
INSTR_PATH = "/root/pred_instructions.json"
MASKS_PATH = "/root/pred_dyn_masks.npz"
TARGET_FPS = 5

cap = cv2.VideoCapture(VIDEO_PATH)
n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
src_fps = cap.get(cv2.CAP_PROP_FPS)
H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
step = max(1, round(src_fps / TARGET_FPS))
sample_ids = list(range(0, n, step))
n_samples = len(sample_ids)
print(f"n={n} src_fps={src_fps} step={step} n_samples={n_samples} HxW={H}x{W}")

# Load sampled frames
frames = []
target = set(sample_ids)
i = 0
grabbed = True
while grabbed:
    grabbed, fr = cap.read()
    if not grabbed:
        break
    if i in target:
        frames.append(fr)
    i += 1
cap.release()
assert len(frames) == n_samples
grays = [cv2.cvtColor(f, cv2.COLOR_BGR2GRAY) for f in frames]

# ---------------- Egomotion ----------------
# Thresholds - scale with resolution. Sampling step in source = 12 frames -> per-sample-interval motion.
th_trans = 2.5    # px per sampled interval
th_rot   = 0.005  # radians
th_scale = 0.008  # relative

def classify(prev_gray, curr_gray):
    pts = cv2.goodFeaturesToTrack(prev_gray, maxCorners=800, qualityLevel=0.01,
                                  minDistance=8, blockSize=7)
    if pts is None or len(pts) < 20:
        return ["Stay"]
    nxt, st, _ = cv2.calcOpticalFlowPyrLK(prev_gray, curr_gray, pts, None,
                                          winSize=(21,21), maxLevel=3)
    if nxt is None:
        return ["Stay"]
    st = st.reshape(-1).astype(bool)
    p0 = pts.reshape(-1,2)[st]
    p1 = nxt.reshape(-1,2)[st]
    if len(p0) < 20:
        return ["Stay"]
    M, inl = cv2.estimateAffinePartial2D(p0, p1, method=cv2.RANSAC,
                                         ransacReprojThreshold=3.0, maxIters=2000, confidence=0.99)
    if M is None:
        return ["Stay"]
    dx, dy = M[0,2], M[1,2]
    a, b = M[0,0], M[1,0]
    scale = math.hypot(a, b)
    rot = math.atan2(b, a)
    lbl = []
    if abs(scale - 1) > th_scale:
        lbl.append("Dolly In" if scale > 1 else "Dolly Out")
    if abs(rot) > th_rot:
        # rot>0 means CCW rotation in image; camera roll clockwise about optical axis => "Roll Right"
        lbl.append("Roll Right" if rot > 0 else "Roll Left")
    # features move right (dx>0) => camera panned LEFT
    if abs(dx) > th_trans:
        lbl.append("Pan Left" if dx > 0 else "Pan Right")
    # features move down (dy>0) => camera tilted UP
    if abs(dy) > th_trans:
        lbl.append("Tilt Up" if dy > 0 else "Tilt Down")
    if not lbl:
        lbl.append("Stay")
    return lbl

# Per sampled interval: label for transition (i-1)->i attaches to sample i.
# We need labels for each sampled frame i in [0, n_samples). For i==0, use label of (0->1).
per_frame_labels = [None] * n_samples
transition_labels = []
for i in range(1, n_samples):
    lbl = classify(grays[i-1], grays[i])
    transition_labels.append(lbl)
    print(f"transition {i-1}->{i}: {lbl}")
# Assign: frame i (i>=1) gets its incoming transition label; frame 0 mirrors frame 1
if n_samples == 1:
    per_frame_labels[0] = ["Stay"]
else:
    per_frame_labels[0] = transition_labels[0]
    for i in range(1, n_samples):
        per_frame_labels[i] = transition_labels[i-1]

# Mild temporal smoothing: for isolated single-frame anomalies, only smooth Stay-vs-non-Stay flicker;
# do NOT collapse frames that clearly cross threshold. Simple mode with window 3.
def norm_set(lbls):
    return tuple(sorted(lbls))

smoothed = list(per_frame_labels)
for i in range(1, n_samples-1):
    a, b, c = norm_set(per_frame_labels[i-1]), norm_set(per_frame_labels[i]), norm_set(per_frame_labels[i+1])
    if a == c and a != b:
        # only smooth if neighbor set is same and current is a solitary Stay (likely noise flicker)
        if b == ("Stay",) or a == ("Stay",):
            smoothed[i] = per_frame_labels[i-1]
per_frame_labels = smoothed

# Compress into intervals
intervals = {}
i = 0
while i < n_samples:
    j = i + 1
    cur = norm_set(per_frame_labels[i])
    while j < n_samples and norm_set(per_frame_labels[j]) == cur:
        j += 1
    intervals[f"{i}->{j}"] = list(per_frame_labels[i])
    i = j

with open(INSTR_PATH, "w") as f:
    json.dump(intervals, f, indent=2)
print("Intervals:", intervals)

# ---------------- Dynamic masks ----------------
def compute_dyn_mask(prev_gray, curr_gray):
    Hh, Ww = prev_gray.shape
    flow = cv2.calcOpticalFlowFarneback(prev_gray, curr_gray, None,
                                        0.5, 3, 21, 3, 7, 1.5, 0)
    u = flow[..., 0].astype(np.float64)
    v = flow[..., 1].astype(np.float64)
    ys, xs = np.mgrid[0:Hh, 0:Ww]
    # Subsample for fitting
    ss = 4
    Xs = xs[::ss, ::ss].ravel()
    Ys = ys[::ss, ::ss].ravel()
    Us = u[::ss, ::ss].ravel()
    Vs = v[::ss, ::ss].ravel()
    A = np.stack([np.ones_like(Xs), Xs, Ys], axis=1)  # (N,3)
    # IRLS with Tukey biweight
    w = np.ones(A.shape[0])
    for _ in range(5):
        Wm = w[:, None]
        AtWA = A.T @ (Wm * A)
        cu = np.linalg.lstsq(AtWA, A.T @ (w * Us), rcond=None)[0]
        cv_ = np.linalg.lstsq(AtWA, A.T @ (w * Vs), rcond=None)[0]
        ru = Us - A @ cu
        rv = Vs - A @ cv_
        r = np.hypot(ru, rv)
        med = np.median(r)
        mad = 1.4826 * np.median(np.abs(r - med)) + 1e-6
        c = 4.685 * mad
        z = np.clip(r / c, 0, 1)
        w = (1 - z**2) ** 2
    # Apply model over full image
    u_model = cu[0] + cu[1]*xs + cu[2]*ys
    v_model = cv_[0] + cv_[1]*xs + cv_[2]*ys
    res = np.hypot(u - u_model, v - v_model)
    med = np.median(res)
    mad = 1.4826 * np.median(np.abs(res - med))
    thr = max(3.0, med + 3.0 * mad)
    raw = (res > thr).astype(np.uint8) * 255
    k3 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    k7 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    m = cv2.morphologyEx(raw, cv2.MORPH_OPEN, k3)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k7)
    nlab, cc, stats, _ = cv2.connectedComponentsWithStats((m > 0).astype(np.uint8), connectivity=8)
    mask = np.zeros_like(raw, dtype=bool)
    min_area = max(200, int(0.0005 * Hh * Ww))
    for cid in range(1, nlab):
        if stats[cid, cv2.CC_STAT_AREA] >= min_area:
            mask |= (cc == cid)
    return mask

def to_csr(mask):
    Hh, Ww = mask.shape
    rows, cols = np.nonzero(mask)
    indices = cols.astype(np.int32)
    data = np.ones(indices.size, dtype=np.uint8)
    counts = np.bincount(rows, minlength=Hh)
    indptr = np.concatenate(([0], np.cumsum(counts))).astype(np.int32)
    return data, indices, indptr

npz_out = {"shape": np.array([H, W], dtype=np.int32)}
for i in range(n_samples):
    if i == 0:
        mask = np.zeros((H, W), dtype=bool)
    else:
        mask = compute_dyn_mask(grays[i-1], grays[i])
    d, ind, iptr = to_csr(mask)
    npz_out[f"f_{i}_data"] = d
    npz_out[f"f_{i}_indices"] = ind
    npz_out[f"f_{i}_indptr"] = iptr
    cov = mask.sum() / (H*W) * 100
    print(f"frame {i}: mask coverage {cov:.2f}%")
np.savez_compressed(MASKS_PATH, **npz_out)
print("Wrote", INSTR_PATH, MASKS_PATH)
