package clusterdata.utils;

import clusterdata.datatypes.TaskEvent;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;

/** Bounded source that reads a (possibly gzipped) task-event CSV file line by line. */
public class TaskEventSource implements SourceFunction<TaskEvent> {

    private final String path;
    private volatile boolean running = true;

    public TaskEventSource(String path) {
        this.path = path;
    }

    @Override
    public void run(SourceContext<TaskEvent> ctx) throws Exception {
        try (InputStream in = open(path);
                BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while (running && (line = reader.readLine()) != null) {
                ctx.collect(TaskEvent.fromString(line));
            }
        }
    }

    @Override
    public void cancel() {
        running = false;
    }

    static InputStream open(String path) throws Exception {
        InputStream in = new FileInputStream(path);
        if (path != null && path.endsWith(".gz")) {
            in = new GZIPInputStream(in);
        }
        return in;
    }
}
