package clusterdata.query;

import clusterdata.datatypes.JobEvent;
import clusterdata.datatypes.TaskEvent;
import clusterdata.utils.AppBase;
import clusterdata.utils.FileStringSink;
import clusterdata.utils.JobEventSource;
import clusterdata.utils.TaskEventSource;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.Collector;

/**
 * Identifies, per job, the "stage" (a session of task SUBMIT events with a gap of at most
 * {@code sesssize} seconds) that contains the most tasks, and emits one
 * {@code (jobId, taskCount)} tuple per finished job.
 */
public class LongestSessionPerJob extends AppBase {

    public static void main(String[] args) throws Exception {

        ParameterTool params = ParameterTool.fromArgs(args);
        String taskInput = params.get("task_input", null);
        String jobInput = params.get("job_input", null);
        String outputPath = params.get("output", null);
        System.out.println("task_input  " + taskInput);
        System.out.println("job_input  " + jobInput);

        // Session inactivity threshold. sesssize is expressed in seconds; event time is in
        // microseconds, hence the conversion.
        final long gapMicros = params.getLong("sesssize", 600L) * 1_000_000L;

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        SourceFunction<TaskEvent> taskSource =
                AppBase.taskSourceOrTest(new TaskEventSource(taskInput));
        SourceFunction<JobEvent> jobSource =
                AppBase.jobSourceOrTest(new JobEventSource(jobInput));

        DataStream<TaskEvent> taskEvents = env.addSource(taskSource)
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy.<TaskEvent>forMonotonousTimestamps()
                                .withTimestampAssigner((event, ts) -> event.time));

        DataStream<JobEvent> jobEvents = env.addSource(jobSource)
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy.<JobEvent>forMonotonousTimestamps()
                                .withTimestampAssigner((event, ts) -> event.time));

        // (jobId, eventTimeMicros, isSubmit)
        DataStream<Tuple3<Long, Long, Boolean>> submits = taskEvents
                .filter(t -> t.eventType == TaskEvent.SUBMIT)
                .map(t -> Tuple3.of(t.jobId, t.time, Boolean.TRUE))
                .returns(Types.TUPLE(Types.LONG, Types.LONG, Types.BOOLEAN));

        DataStream<Tuple3<Long, Long, Boolean>> finishes = jobEvents
                .filter(j -> j.eventType == JobEvent.FINISH)
                .map(j -> Tuple3.of(j.jobId, j.time, Boolean.FALSE))
                .returns(Types.TUPLE(Types.LONG, Types.LONG, Types.BOOLEAN));

        DataStream<String> result = submits.union(finishes)
                .keyBy(new KeySelector<Tuple3<Long, Long, Boolean>, Long>() {
                    @Override
                    public Long getKey(Tuple3<Long, Long, Boolean> value) {
                        return value.f0;
                    }
                })
                .process(new StageFunction(gapMicros));

        @SuppressWarnings("unchecked")
        SinkFunction<String> sink =
                (SinkFunction<String>) AppBase.sinkOrTest(new FileStringSink(outputPath));
        result.addSink(sink);

        env.execute("LongestSessionPerJob");
    }

    /**
     * Tracks task SUBMIT sessions per job and emits the longest one once the job has finished.
     *
     * <p>The FINISH event only schedules an event-time timer: the result is emitted when that timer
     * fires, i.e. when the watermark has advanced past the job's FINISH timestamp. At that point all
     * of the job's SUBMIT events (whose timestamps are strictly smaller) have already been delivered,
     * independent of the physical order in which the two source files are read.
     */
    public static final class StageFunction
            extends KeyedProcessFunction<Long, Tuple3<Long, Long, Boolean>, String> {

        private final long gapMicros;
        // f0 = timestamp of the most recent SUBMIT (-1 when none),
        // f1 = number of SUBMITs in the current stage, f2 = longest stage seen so far.
        private transient ValueState<Tuple3<Long, Integer, Integer>> stageState;
        private transient ValueState<Boolean> finishSeen;

        public StageFunction(long gapMicros) {
            this.gapMicros = gapMicros;
        }

        @Override
        public void open(Configuration parameters) throws Exception {
            super.open(parameters);
            stageState = getRuntimeContext().getState(
                    new ValueStateDescriptor<>(
                            "stage-state", Types.TUPLE(Types.LONG, Types.INT, Types.INT)));
            finishSeen = getRuntimeContext().getState(
                    new ValueStateDescriptor<>("finish-seen", Types.BOOLEAN));
        }

        @Override
        public void processElement(
                Tuple3<Long, Long, Boolean> value,
                Context ctx,
                Collector<String> out) throws Exception {
            long time = value.f1;
            if (Boolean.TRUE.equals(value.f2)) {
                // Task SUBMIT event.
                Tuple3<Long, Integer, Integer> acc = stageState.value();
                if (acc == null) {
                    acc = Tuple3.of(-1L, 0, 0);
                }
                long last = acc.f0;
                int current = acc.f1;
                int longest = acc.f2;
                if (last < 0) {
                    current = 1;
                } else if (time - last <= gapMicros) {
                    current += 1;
                } else {
                    longest = Math.max(longest, current);
                    current = 1;
                }
                stageState.update(Tuple3.of(time, current, longest));
            } else {
                // Job FINISH event: defer emission until the watermark passes the FINISH time.
                finishSeen.update(true);
                ctx.timerService().registerEventTimeTimer(time);
            }
        }

        @Override
        public void onTimer(long timestamp, OnTimerContext ctx, Collector<String> out)
                throws Exception {
            Boolean seen = finishSeen.value();
            if (seen == null || !seen) {
                return;
            }
            Tuple3<Long, Integer, Integer> acc = stageState.value();
            int longest = 0;
            if (acc != null) {
                longest = Math.max(acc.f2, acc.f1);
            }
            out.collect("(" + ctx.getCurrentKey() + "," + longest + ")");
            stageState.clear();
            finishSeen.clear();
        }
    }
}
