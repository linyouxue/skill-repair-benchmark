package clusterdata.datatypes;

import java.io.Serializable;

/**
 * A single job scheduling event from the Google cluster-usage traces.
 *
 * <p>CSV column order (see data/format.pdf):
 * time, missing info, job ID, event type, user, scheduling class,
 * job name, logical job name.
 *
 * <p>Timestamps are expressed in microseconds since the epoch.
 */
public class JobEvent implements Serializable {

    public static final int SUBMIT = 0;
    public static final int SCHEDULE = 1;
    public static final int EVICT = 2;
    public static final int FAIL = 3;
    public static final int FINISH = 4;
    public static final int KILL = 5;
    public static final int LOST = 6;

    public long time;
    public int missingInfo;
    public long jobId;
    public int eventType;
    public String user;
    public int schedulingClass;
    public String jobName;
    public String logicalJobName;

    public JobEvent() {
    }

    public JobEvent(
            long time,
            int missingInfo,
            long jobId,
            int eventType,
            String user,
            int schedulingClass,
            String jobName,
            String logicalJobName) {
        this.time = time;
        this.missingInfo = missingInfo;
        this.jobId = jobId;
        this.eventType = eventType;
        this.user = user;
        this.schedulingClass = schedulingClass;
        this.jobName = jobName;
        this.logicalJobName = logicalJobName;
    }

    public static JobEvent fromString(String line) {
        String[] f = line.split(",", -1);
        JobEvent e = new JobEvent();
        e.time = Long.parseLong(f[0].trim());
        e.missingInfo = f[1].trim().isEmpty() ? 0 : Integer.parseInt(f[1].trim());
        e.jobId = Long.parseLong(f[2].trim());
        e.eventType = Integer.parseInt(f[3].trim());
        e.user = f[4];
        e.schedulingClass = Integer.parseInt(f[5].trim());
        e.jobName = f[6];
        e.logicalJobName = f[7];
        return e;
    }

    public long getTime() {
        return time;
    }

    public long getJobId() {
        return jobId;
    }

    public int getEventType() {
        return eventType;
    }

    @Override
    public String toString() {
        return "JobEvent{jobId=" + jobId + ", eventType=" + eventType + ", time=" + time + "}";
    }
}
