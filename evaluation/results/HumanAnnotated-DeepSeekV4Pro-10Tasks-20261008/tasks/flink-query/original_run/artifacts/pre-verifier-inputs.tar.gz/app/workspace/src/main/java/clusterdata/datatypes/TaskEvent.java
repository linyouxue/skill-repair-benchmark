package clusterdata.datatypes;

import java.io.Serializable;

/**
 * A single task scheduling event from the Google cluster-usage traces.
 *
 * <p>CSV column order (see data/format.pdf):
 * time, missing info, job ID, task index, machine ID, event type,
 * user, scheduling class, priority, CPU request, memory request,
 * disk space request, different machines restriction.
 *
 * <p>Timestamps are expressed in microseconds since the epoch.
 */
public class TaskEvent implements Serializable {

    public static final int SUBMIT = 0;
    public static final int SCHEDULE = 1;
    public static final int EVICT = 2;
    public static final int FAIL = 3;
    public static final int FINISH = 4;
    public static final int KILL = 5;
    public static final int LOST = 6;

    public long time;
    public int missingInfo;
    public long jobId;
    public int taskIndex;
    public long machineId;
    public int eventType;
    public String user;
    public int schedulingClass;
    public int priority;
    public float cpuRequest;
    public float memoryRequest;
    public float diskRequest;
    public int differentMachinesRestriction;

    public TaskEvent() {
    }

    public TaskEvent(
            long time,
            int missingInfo,
            long jobId,
            int taskIndex,
            long machineId,
            int eventType,
            String user,
            int schedulingClass,
            int priority,
            float cpuRequest,
            float memoryRequest,
            float diskRequest,
            int differentMachinesRestriction) {
        this.time = time;
        this.missingInfo = missingInfo;
        this.jobId = jobId;
        this.taskIndex = taskIndex;
        this.machineId = machineId;
        this.eventType = eventType;
        this.user = user;
        this.schedulingClass = schedulingClass;
        this.priority = priority;
        this.cpuRequest = cpuRequest;
        this.memoryRequest = memoryRequest;
        this.diskRequest = diskRequest;
        this.differentMachinesRestriction = differentMachinesRestriction;
    }

    public static TaskEvent fromString(String line) {
        String[] f = line.split(",", -1);
        TaskEvent e = new TaskEvent();
        e.time = Long.parseLong(f[0].trim());
        e.missingInfo = parseIntOrZero(f[1]);
        e.jobId = Long.parseLong(f[2].trim());
        e.taskIndex = Integer.parseInt(f[3].trim());
        e.machineId = parseLongOrZero(f[4]);
        e.eventType = Integer.parseInt(f[5].trim());
        e.user = f[6];
        e.schedulingClass = Integer.parseInt(f[7].trim());
        e.priority = Integer.parseInt(f[8].trim());
        e.cpuRequest = Float.parseFloat(f[9].trim());
        e.memoryRequest = Float.parseFloat(f[10].trim());
        e.diskRequest = Float.parseFloat(f[11].trim());
        e.differentMachinesRestriction = Integer.parseInt(f[12].trim());
        return e;
    }

    private static int parseIntOrZero(String s) {
        String t = s.trim();
        return t.isEmpty() ? 0 : Integer.parseInt(t);
    }

    private static long parseLongOrZero(String s) {
        String t = s.trim();
        return t.isEmpty() ? 0L : Long.parseLong(t);
    }

    public long getTime() {
        return time;
    }

    public long getJobId() {
        return jobId;
    }

    public int getEventType() {
        return eventType;
    }

    @Override
    public String toString() {
        return "TaskEvent{jobId=" + jobId + ", taskIndex=" + taskIndex
                + ", eventType=" + eventType + ", time=" + time + "}";
    }
}
