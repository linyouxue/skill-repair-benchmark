package clusterdata.utils;

import clusterdata.datatypes.JobEvent;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/** Bounded source that reads a (possibly gzipped) job-event CSV file line by line. */
public class JobEventSource implements SourceFunction<JobEvent> {

    private final String path;
    private volatile boolean running = true;

    public JobEventSource(String path) {
        this.path = path;
    }

    @Override
    public void run(SourceContext<JobEvent> ctx) throws Exception {
        try (InputStream in = TaskEventSource.open(path);
                BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while (running && (line = reader.readLine()) != null) {
                ctx.collect(JobEvent.fromString(line));
            }
        }
    }

    @Override
    public void cancel() {
        running = false;
    }
}
