package clusterdata.utils;

import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/** Writes each incoming string on its own line to a single local file. */
public class FileStringSink extends RichSinkFunction<String> {

    private final String path;
    private transient BufferedWriter writer;

    public FileStringSink(String path) {
        this.path = path;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        File file = new File(path);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
    }

    @Override
    public void invoke(String value, Context context) throws Exception {
        writer.write(value);
        writer.newLine();
    }

    @Override
    public void close() throws Exception {
        if (writer != null) {
            writer.flush();
            writer.close();
        }
        super.close();
    }
}
