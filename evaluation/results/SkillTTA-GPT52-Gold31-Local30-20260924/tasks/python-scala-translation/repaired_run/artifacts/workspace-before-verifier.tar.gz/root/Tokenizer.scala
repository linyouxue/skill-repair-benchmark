import java.nio.charset.{Charset, StandardCharsets}
import java.time.{Instant, LocalDate, LocalDateTime, ZoneId, ZonedDateTime}
import java.time.format.DateTimeFormatter

import scala.collection.mutable
import scala.util.{Failure, Success, Try}

// Tokenizer module for converting various input types to standardized string tokens.
//
// This file is an idiomatic Scala 2.13 translation of Tokenizer.py. It preserves
// the behavior and surface API while adapting the design toward immutable data,
// variance-aware generics, and Option/Try-based absence/error handling.

// ==========================================================================
// Protocol-like traits (structural typing in Python)
// ==========================================================================

trait Tokenizable {
  def toToken: String
}

trait HasLength {
  def length: Int
}

trait TokenProcessor[-T] {
  def process(item: T): Unit
}

// ==========================================================================
// Token types
// ==========================================================================

sealed trait TokenType {
  def value: String
}

object TokenType {
  case object String extends TokenType { override val value: String = "string" }
  case object Numeric extends TokenType { override val value: String = "numeric" }
  case object Temporal extends TokenType { override val value: String = "temporal" }
  case object Structured extends TokenType { override val value: String = "structured" }
  case object Binary extends TokenType { override val value: String = "binary" }
  case object Null extends TokenType { override val value: String = "null" }

  val all: List[TokenType] = List(String, Numeric, Temporal, Structured, Binary, Null)

  def fromValue(v: String): Option[TokenType] = all.find(_.value == v)
}

// ==========================================================================
// Core token classes
// ==========================================================================

final case class Token(
  value: String,
  tokenType: TokenType,
  metadata: Map[String, Any] = Map.empty
) {
  def withMetadata(entries: (String, Any)*): Token =
    copy(metadata = metadata ++ entries.toMap)

  def withMetadataMap(extra: Map[String, Any]): Token =
    copy(metadata = metadata ++ extra)
}

final class MutableTokenBatch(initial: Seq[Token] = Seq.empty) {
  private val buffer: mutable.ListBuffer[Token] = mutable.ListBuffer.from(initial)
  private var processed: Boolean = false

  def tokens: List[Token] = buffer.toList

  def add(token: Token): Unit = {
    if (processed) throw new IllegalStateException("Batch already processed")
    buffer += token
  }

  def markProcessed(): Unit = processed = true
}

// ==========================================================================
// Generic container classes (variance demonstrations)
// ==========================================================================

final class TokenContainer[+T](items: Seq[T]) {
  private val stored: Vector[T] = items.toVector

  def getAll: Vector[T] = stored

  def mapTokens(f: T => String): List[String] = stored.iterator.map(f).toList
}

final class TokenSink[-T] {
  private val received: mutable.ListBuffer[Any] = mutable.ListBuffer.empty

  def receive(item: T): Unit = received += item

  def drain(): List[Any] = {
    val out = received.toList
    received.clear()
    out
  }
}

final class BivariantHandler[T](default: T) {
  private var current: T = default

  def get: T = current
  def set(value: T): Unit = current = value

  def transform(f: T => T): T = {
    current = f(current)
    current
  }
}

// ==========================================================================
// Tokenizer implementations
// ==========================================================================

trait BaseTokenizer[-T] {
  def tokenize(value: T): Token

  def tokenizeBatch(values: Iterable[T]): Iterator[Token] =
    values.iterator.map(tokenize)

  // Compatibility alias mirroring Python naming.
  final def tokenize_batch(values: Iterable[T]): Iterator[Token] = tokenizeBatch(values)
}

final class StringTokenizer(
  encoding: Charset = StandardCharsets.UTF_8,
  normalizer: String => String = identity
) extends BaseTokenizer[Any] {

  def tokenize(value: String): Token = Token(normalizer(value), TokenType.String)

  def tokenize(value: Array[Byte]): Token = Token(normalizer(new String(value, encoding)), TokenType.String)

  override def tokenize(value: Any): Token = value match {
    case s: String => tokenize(s)
    case bytes: Array[Byte] => tokenize(bytes)
    case other => Token(normalizer(other.toString), TokenType.String, Map("fallback" -> true))
  }
}

final class NumericTokenizer(
  precision: Int = 6,
  formatOptions: Map[String, Any] = Map.empty // kept for API parity with Python
) extends BaseTokenizer[Any] {

  private def formatFloating(d: Double): String =
    String.format(java.util.Locale.ROOT, s"%.${precision}f", java.lang.Double.valueOf(d))

  private def formatDecimal(d: BigDecimal): String = {
    val scaled = d.setScale(precision, BigDecimal.RoundingMode.HALF_UP)
    // Ensure fixed-point formatting (like Python's f-string)
    formatFloating(scaled.toDouble)
  }

  override def tokenize(value: Any): Token = {
    val (strValue, originalType) = value match {
      case bd: BigDecimal => (formatDecimal(bd), "BigDecimal")
      case bd: java.math.BigDecimal => (formatDecimal(BigDecimal(bd)), "BigDecimal")
      case f: Float => (formatFloating(f.toDouble), "Float")
      case d: Double => (formatFloating(d), "Double")
      case b: Byte => (b.toString, "Byte")
      case s: Short => (s.toString, "Short")
      case i: Int => (i.toString, "Int")
      case l: Long => (l.toString, "Long")
      case bi: BigInt => (bi.toString, "BigInt")
      case other => (other.toString, other.getClass.getSimpleName)
    }

    Token(strValue, TokenType.Numeric, Map("original_type" -> originalType))
  }
}

final class TemporalTokenizer(formatStr: Option[String] = None) extends BaseTokenizer[Any] {
  import TemporalTokenizer._

  private def formatterFor(value: Any): DateTimeFormatter = {
    val pattern = formatStr.getOrElse {
      value match {
        case _: LocalDateTime | _: ZonedDateTime | _: Instant => IsoFormat
        case _: LocalDate => DateFormat
        case _ => IsoFormat
      }
    }

    DateTimeFormatter.ofPattern(pattern)
  }

  override def tokenize(value: Any): Token = {
    val fmt = formatterFor(value)

    val rendered = value match {
      case dt: LocalDateTime => dt.format(fmt)
      case d: LocalDate => d.format(fmt)
      case z: ZonedDateTime => z.format(fmt)
      case i: Instant => ZonedDateTime.ofInstant(i, ZoneId.of("UTC")).format(fmt)
      case other => other.toString
    }

    Token(rendered, TokenType.Temporal)
  }
}

object TemporalTokenizer {
  // Mirrors Python patterns: "%Y-%m-%dT%H:%M:%S" and "%Y-%m-%d".
  val IsoFormat: String = "yyyy-MM-dd'T'HH:mm:ss"
  val DateFormat: String = "yyyy-MM-dd"
}

// ==========================================================================
// Universal tokenizer (runtime dispatch)
// ==========================================================================

final class UniversalTokenizer(
  private val stringTokenizer: StringTokenizer = new StringTokenizer(),
  private val numericTokenizer: NumericTokenizer = new NumericTokenizer(),
  private val temporalTokenizer: TemporalTokenizer = new TemporalTokenizer()
) {

  def tokenize(value: Any): Token = value match {
    case null => Token("NULL", TokenType.Null)

    case t: Tokenizable =>
      Token(t.toToken, TokenType.Structured)

    case s: String => stringTokenizer.tokenize(s)
    case b: Array[Byte] => stringTokenizer.tokenize(b)

    case _: Byte | _: Short | _: Int | _: Long | _: BigInt | _: Float | _: Double | _: BigDecimal | _: java.math.BigDecimal =>
      numericTokenizer.tokenize(value)

    case _: LocalDate | _: LocalDateTime | _: ZonedDateTime | _: Instant =>
      temporalTokenizer.tokenize(value)

    // Fallback: str() conversion in Python
    case other => Token(other.toString, TokenType.String, Map("fallback" -> true))
  }
}

// ==========================================================================
// Complex nested generics
// ==========================================================================

final class TokenRegistry[T] {
  private val registry: mutable.Map[String, TokenContainer[T]] = mutable.Map.empty
  private val handlers: mutable.ListBuffer[T => Option[Token]] = mutable.ListBuffer.empty

  def register(key: String, container: TokenContainer[T]): Unit = registry.update(key, container)

  def addHandler(handler: T => Option[Token]): Unit = handlers += handler

  def process(key: String): List[Option[Token]] = {
    registry.get(key) match {
      case None => Nil
      case Some(container) =>
        container.getAll.toList.map { item =>
          handlers.iterator.flatMap(h => h(item).iterator).take(1).toList.headOption
        }
    }
  }
}

// ==========================================================================
// Functor / Monad simulation
// ==========================================================================

final case class TokenFunctor[+T](private val opt: Option[T]) {
  def map[U](f: T => U): TokenFunctor[U] = TokenFunctor(opt.map(f))

  def flatMap[U](f: T => TokenFunctor[U]): TokenFunctor[U] =
    TokenFunctor(opt.flatMap(t => f(t).opt))

  def getOrElse[U >: T](default: => U): U = opt.getOrElse(default)
}

object TokenFunctor {
  def apply[T](value: T): TokenFunctor[T] = TokenFunctor(Option(value))
}

final case class TokenMonad[+T](private val opt: Option[T]) {
  def map[U](f: T => U): TokenMonad[U] = TokenMonad(opt.map(f))

  def flatMap[U](f: T => TokenMonad[U]): TokenMonad[U] =
    TokenMonad(opt.flatMap(t => f(t).opt))

  def getOrElse[U >: T](default: => U): U = opt.getOrElse(default)

  def ap[U](funcWrapped: TokenMonad[T => U]): TokenMonad[U] =
    TokenMonad(for {
      f <- funcWrapped.opt
      v <- opt
    } yield f(v))
}

object TokenMonad {
  def pure[T](value: T): TokenMonad[T] = TokenMonad(Option(value))
}

// ==========================================================================
// JSON structure tokenization (no external JSON dependencies)
// ==========================================================================

final class JsonTokenizer(pretty: Boolean = false) {

  def tokenize(value: Any): Token = {
    val jsonStr = JsonRenderer.render(value, pretty)
    Token(jsonStr, TokenType.Structured, Map("json" -> true))
  }

  def tokenizePath(value: Any, path: String): Option[Token] = {
    val parts = path.split("\\.").toList.filter(_.nonEmpty)

    def step(current: Any, rest: List[String]): Option[Any] = rest match {
      case Nil => Some(current)
      case part :: tail =>
        current match {
          case m: Map[_, _] =>
            m.asInstanceOf[Map[Any, Any]].get(part).flatMap(v => step(v, tail))

          case s: Seq[_] if part.forall(_.isDigit) =>
            val idx = part.toInt
            val seq = s.asInstanceOf[Seq[Any]]
            if (idx >= 0 && idx < seq.length) step(seq(idx), tail) else None

          case _ => None
        }
    }

    step(value, parts).map(tokenize)
  }
}

private object JsonRenderer {
  private def escapeString(s: String): String = {
    val sb = new StringBuilder(s.length + 16)
    sb.append('"')
    s.foreach {
      case '"' => sb.append("\\\"")
      case '\\' => sb.append("\\\\")
      case '\b' => sb.append("\\b")
      case '\f' => sb.append("\\f")
      case '\n' => sb.append("\\n")
      case '\r' => sb.append("\\r")
      case '\t' => sb.append("\\t")
      case c if c.isControl => sb.append(f"\\u${c.toInt}%04x")
      case c => sb.append(c)
    }
    sb.append('"')
    sb.toString
  }

  def render(value: Any, pretty: Boolean): String = {
    val indentSize = 2

    def spaces(n: Int): String = " " * n

    def render0(v: Any, depth: Int): String = v match {
      case null => "null"
      case s: String => escapeString(s)
      case b: Boolean => if (b) "true" else "false"

      case bd: BigDecimal => bd.toString
      case bd: java.math.BigDecimal => BigDecimal(bd).toString
      case bi: BigInt => bi.toString
      case n: Byte => n.toString
      case n: Short => n.toString
      case n: Int => n.toString
      case n: Long => n.toString
      case n: Float =>
        if (n.isNaN || n.isInfinite) throw new IllegalArgumentException("JSON does not support NaN/Infinity")
        java.lang.Float.toString(n)
      case n: Double =>
        if (n.isNaN || n.isInfinite) throw new IllegalArgumentException("JSON does not support NaN/Infinity")
        java.lang.Double.toString(n)

      case seq: Seq[_] =>
        val xs = seq.asInstanceOf[Seq[Any]]
        if (xs.isEmpty) "[]"
        else if (!pretty) xs.map(x => render0(x, depth + 1)).mkString("[", ",", "]")
        else {
          val inner = xs.map(x => spaces((depth + 1) * indentSize) + render0(x, depth + 1)).mkString(",\n")
          s"[\n$inner\n${spaces(depth * indentSize)}]"
        }

      case m: Map[_, _] =>
        val obj = m.asInstanceOf[Map[Any, Any]].toList.map { case (k, vv) => k.toString -> vv }
        if (obj.isEmpty) "{}"
        else if (!pretty) {
          obj
            .map { case (k, vv) => s"${escapeString(k)}:${render0(vv, depth + 1)}" }
            .mkString("{", ",", "}")
        } else {
          val inner = obj
            .map { case (k, vv) =>
              spaces((depth + 1) * indentSize) + s"${escapeString(k)}: ${render0(vv, depth + 1)}"
            }
            .mkString(",\n")
          s"{\n$inner\n${spaces(depth * indentSize)}}"
        }

      case other =>
        throw new IllegalArgumentException(s"Unsupported JSON value: ${other.getClass.getName}")
    }

    render0(value, depth = 0)
  }
}

// ==========================================================================
// Whitespace tokenizer
// ==========================================================================

final class WhitespaceTokenizer(
  lowercase: Boolean = false,
  minLength: Int = 0,
  maxLength: Option[Int] = None,
  stripPunctuation: Boolean = false
) {
  private val punctuation: Set[Char] = ".,!?;:'\"()[]{}".toSet

  private def stripEdgePunctuation(s: String): String = {
    def dropLeading(x: String): String = x.dropWhile(punctuation.contains)
    def dropTrailing(x: String): String = x.reverse.dropWhile(punctuation.contains).reverse
    dropTrailing(dropLeading(s))
  }

  private def processToken(word0: String): Option[String] = {
    val stripped = if (stripPunctuation) stripEdgePunctuation(word0) else word0
    val cased = if (lowercase) stripped.toLowerCase(java.util.Locale.ROOT) else stripped

    if (cased.length < minLength) None
    else {
      val truncated = maxLength match {
        case Some(max) if cased.length > max => cased.take(max)
        case _ => cased
      }
      Option(truncated).filter(_.nonEmpty)
    }
  }

  def tokenize(text: String): List[Token] = {
    val words = text.split("\\s+").toList.filter(_.nonEmpty)
    words.zipWithIndex.flatMap { case (word, i) =>
      processToken(word).map { processed =>
        Token(processed, TokenType.String, Map("position" -> i, "original" -> word))
      }
    }
  }

  def tokenizeToStrings(text: String): List[String] = tokenize(text).map(_.value)

  def tokenizeWithPositions(text: String): List[(String, Int, Int)] = {
    val words = text.split("\\s+").toList.filter(_.nonEmpty)

    var currentPos = 0
    val out = mutable.ListBuffer.empty[(String, Int, Int)]

    words.foreach { word =>
      val start = text.indexOf(word, currentPos)
      val end = if (start >= 0) start + word.length else currentPos

      processToken(word).foreach { processed =>
        out += ((processed, start, end))
      }

      currentPos = end
    }

    out.toList
  }

  def countTokens(text: String): Int = tokenize(text).length
}

// ==========================================================================
// Builder pattern with fluent interface (immutable builder)
// ==========================================================================

final case class TokenizerBuilder[T](
  private val normalizers: Vector[String => String] = Vector.empty,
  private val validators: Vector[T => Boolean] = Vector.empty,
  private val metadata: Map[String, Any] = Map.empty
) {

  def withNormalizer(normalizer: String => String): TokenizerBuilder[T] =
    copy(normalizers = normalizers :+ normalizer)

  def withValidator(validator: T => Boolean): TokenizerBuilder[T] =
    copy(validators = validators :+ validator)

  def withMetadata(entries: (String, Any)*): TokenizerBuilder[T] =
    copy(metadata = metadata ++ entries.toMap)

  def build(): T => Token = {
    val ns = normalizers
    val vs = validators
    val meta = metadata

    (value: T) => {
      val ok = vs.forall(v => v(value))
      if (!ok) throw new IllegalArgumentException(s"Validation failed for $value")

      val normalized = ns.foldLeft(value.toString)((acc, n) => n(acc))
      Token(normalized, TokenType.String, meta)
    }
  }

  def buildEither(): T => Either[String, Token] = {
    val f = build()
    (value: T) =>
      Try(f(value)) match {
        case Success(t) => Right(t)
        case Failure(e) => Left(e.getMessage)
      }
  }
}

// ==========================================================================
// Module-level functions (Scala uses objects instead of top-level defs)
// ==========================================================================

object Tokenizer {
  private val universal = new UniversalTokenizer()

  def tokenize(value: Any): Token = universal.tokenize(value)

  def tokenizeBatch(values: Iterable[Any]): Iterator[Token] = values.iterator.map(tokenize)

  def toToken(value: Any): String = tokenize(value).value

  def withMetadata(token: Token, entries: (String, Any)*): Token = token.withMetadata(entries: _*)
}
