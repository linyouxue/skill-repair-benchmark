'use client';

export default function ProductSkeleton() {
  // Shape and sizing mirror ProductCard (border/shadow, 4:3 image, title line,
  // price line, button) so swapping skeletons for real cards causes no shift.
  return (
    <div
      data-testid="product-skeleton"
      className="bg-[var(--card-bg)] rounded-lg p-4"
      style={{ boxShadow: 'var(--card-shadow)', border: '1px solid var(--border-color)' }}
    >
      <div
        data-testid="skeleton-image"
        className="w-full bg-gray-300 animate-pulse"
        style={{ aspectRatio: '4 / 3' }}
      />
      <div data-testid="skeleton-title" className="mt-3 h-4 w-3/4 bg-gray-300 animate-pulse" />
      <div className="mt-2 h-4 w-1/3 bg-gray-300 animate-pulse" />
      <div className="mt-3 h-10 w-full bg-gray-300 animate-pulse rounded" />
    </div>
  );
}
