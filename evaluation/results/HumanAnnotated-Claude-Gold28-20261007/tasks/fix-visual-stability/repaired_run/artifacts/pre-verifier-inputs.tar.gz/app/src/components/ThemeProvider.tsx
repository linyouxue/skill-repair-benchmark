'use client';

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Theme = 'light' | 'dark';

const ThemeContext = createContext<{
  theme: Theme;
  toggleTheme: () => void;
}>({ theme: 'light', toggleTheme: () => {} });

export function useTheme() {
  return useContext(ThemeContext);
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  // Initialize from the attribute set by ThemeScript so client-side render
  // matches the user's saved preference immediately. On the server there is
  // no document, so we fall back to 'light' — html carries
  // suppressHydrationWarning to allow this intentional mismatch.
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof document !== 'undefined') {
      const t = document.documentElement.getAttribute('data-theme') as Theme | null;
      if (t === 'light' || t === 'dark') return t;
    }
    return 'light';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    try { localStorage.setItem('theme', newTheme); } catch {}
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div data-testid="theme-wrapper" id="theme-wrapper" className="min-h-screen" suppressHydrationWarning>
        {children}
      </div>
    </ThemeContext.Provider>
  );
}
