// Runs synchronously before React hydrates to prevent a light→dark flash
// when the user's saved theme differs from the SSR default. Must stay small
// and inline — any async work would recreate the flicker it is here to kill.
export default function ThemeScript() {
  const code = `(function(){try{var t=localStorage.getItem('theme');if(t!=='light'&&t!=='dark'){t=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';}document.documentElement.setAttribute('data-theme',t);}catch(e){}})();`;
  return <script dangerouslySetInnerHTML={{ __html: code }} />;
}
