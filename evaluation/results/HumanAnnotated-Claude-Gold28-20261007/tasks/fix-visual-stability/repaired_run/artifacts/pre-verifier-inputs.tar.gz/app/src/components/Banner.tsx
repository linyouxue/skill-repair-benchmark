'use client';

import { useState, useEffect } from 'react';

const API_URL = '';

export default function Banner() {
  const [promo, setPromo] = useState<string>('');

  useEffect(() => {
    fetch(`${API_URL}/api/banner`)
      .then(r => r.json())
      .then(data => setPromo(data.text));
  }, []);

  // Always render the container so loaded text does not push the page down.
  // py-24 (6rem top+bottom = 192px) + 1 line of text at text-2xl line-height
  // gives ~224px; min-height keeps the empty state the same size.
  return (
    <div
      data-testid="promo-banner"
      className="bg-[#0070f3] text-white py-24 px-4 text-center font-bold text-2xl"
      style={{ minHeight: '224px' }}
    >
      {promo}
    </div>
  );
}
