import type { Metadata } from 'next';
import { ThemeProvider } from '@/components/ThemeProvider';
import ThemeScript from '@/components/ThemeScript';
import './globals.css';

export const metadata: Metadata = {
  title: 'Modern Marketplace',
  description: 'Your one-stop shop for everything',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link
          rel="preload"
          href="/fonts/custom.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
        <ThemeScript />
      </head>
      <body>
        <ThemeProvider>
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
