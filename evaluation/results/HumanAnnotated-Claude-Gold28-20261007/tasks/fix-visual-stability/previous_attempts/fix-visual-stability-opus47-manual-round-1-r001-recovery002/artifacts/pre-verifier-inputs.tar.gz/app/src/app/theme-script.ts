// Inline script string that runs before React hydration to set the theme
// on <html> from localStorage. Prevents a light→dark (or dark→light) flash.
export const themeInitScript = `(function(){try{var t=localStorage.getItem('theme');if(t!=='light'&&t!=='dark'){t='light';}document.documentElement.setAttribute('data-theme',t);}catch(e){document.documentElement.setAttribute('data-theme','light');}})();`;
