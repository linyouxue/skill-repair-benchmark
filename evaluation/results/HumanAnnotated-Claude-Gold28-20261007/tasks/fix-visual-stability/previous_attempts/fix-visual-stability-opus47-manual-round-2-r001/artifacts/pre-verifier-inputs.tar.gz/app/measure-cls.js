const { chromium } = require('playwright');

async function measureCLS(url, scroll) {
  const browser = await chromium.launch({
    executablePath: '/opt/ms-playwright/chromium-1148/chrome-linux/chrome',
  });
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.addInitScript(() => {
    const state = {
      supported: PerformanceObserver.supportedEntryTypes.includes('layout-shift'),
      cls: 0, score: 0, start: null, last: 0, shifts: [],
    };
    window.__clsResult = state;
    if (!state.supported) return;
    new PerformanceObserver((list) => {
      for (const raw of list.getEntries()) {
        if (raw.hadRecentInput) continue;
        if (state.start === null || raw.startTime - state.last >= 1000 ||
            raw.startTime - state.start >= 5000) {
          state.score = 0;
          state.start = raw.startTime;
        }
        state.score += raw.value;
        state.last = raw.startTime;
        state.cls = Math.max(state.cls, state.score);
        state.shifts.push({ value: raw.value, startTime: raw.startTime });
      }
    }).observe({ type: 'layout-shift', buffered: true });
  });

  await page.goto(url, { waitUntil: 'networkidle' });

  if (scroll) {
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000);
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(500);
  }
  await page.waitForTimeout(2000);

  const observed = await page.evaluate(() => window.__clsResult);
  await browser.close();
  const cls = observed.cls;
  const rating = cls < 0.1 ? 'good' : cls < 0.25 ? 'needs-improvement' : 'poor';
  return { url, cls: Math.round(cls * 1000) / 1000, rating, shifts: observed.shifts.slice(0, 10) };
}

const url = process.argv[2] || 'http://localhost:3000';
const scroll = process.argv.includes('--scroll');
measureCLS(url, scroll).then((r) => console.log(JSON.stringify(r, null, 2)));
