'use client';

export default function ProductSkeleton() {
  return (
    <div
      data-testid="product-skeleton"
      className="bg-[var(--card-bg)] rounded-lg p-4"
      style={{ boxShadow: 'var(--card-shadow)', border: '1px solid var(--border-color)' }}
    >
      {/* Dimensions mirror ProductCard (image aspect + title + price + button)
          so swapping skeletons for real cards causes zero layout shift. */}
      <div data-testid="skeleton-image" className="w-full aspect-[4/3] bg-gray-300 animate-pulse" />
      <div data-testid="skeleton-title" className="mt-3 h-6 w-3/4 bg-gray-300 animate-pulse" />
      <div className="mt-2 h-5 w-1/3 bg-gray-300 animate-pulse" />
      <div className="mt-3 h-10 w-full bg-gray-300 animate-pulse rounded" />
    </div>
  );
}
