const http = require('http');
const fs = require('fs');
const path = require('path');

const products = JSON.parse(
  fs.readFileSync(path.join('/app/src/data/products.json'), 'utf8')
);

function delay(ms, data) {
  return new Promise((resolve) => setTimeout(() => resolve(data), ms));
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.url.startsWith('/api/banner')) {
    const data = await delay(400, { text: 'MEGA SALE – 50% off everything!' });
    res.end(JSON.stringify(data));
  } else if (req.url.startsWith('/api/late-banner')) {
    const data = await delay(1200, { text: 'Free shipping worldwide this week only!' });
    res.end(JSON.stringify(data));
  } else if (req.url.startsWith('/api/side-pane')) {
    const data = await delay(600, {
      categories: [
        { name: 'Electronics', href: '/c/electronics' },
        { name: 'Books', href: '/c/books' },
        { name: 'Fashion', href: '/c/fashion' },
      ],
      filters: [
        { name: 'Under $25', href: '/f/25' },
        { name: '$25–$50', href: '/f/50' },
      ],
    });
    res.end(JSON.stringify(data));
  } else if (req.url.startsWith('/api/results-bar')) {
    const data = await delay(900, { visible: true });
    res.end(JSON.stringify(data));
  } else if (req.url.startsWith('/api/products')) {
    const data = await delay(800, products);
    res.end(JSON.stringify(data));
  } else {
    res.statusCode = 404;
    res.end('{}');
  }
});

server.listen(4000, '127.0.0.1', () => console.log('mock api on 4000'));
