const { chromium } = require('playwright');
const { PNG } = require('pngjs');

function getAverageBrightness(pngBuffer) {
  const png = PNG.sync.read(pngBuffer);
  let total = 0;
  const n = png.width * png.height;
  for (let y = 0; y < png.height; y++) {
    for (let x = 0; x < png.width; x++) {
      const i = (png.width * y + x) << 2;
      total += png.data[i] * 0.299 + png.data[i + 1] * 0.587 + png.data[i + 2] * 0.114;
    }
  }
  return total / n;
}

async function detectFlicker(url, expectedTheme = 'dark') {
  const browser = await chromium.launch({
    executablePath: '/opt/ms-playwright/chromium-1148/chrome-linux/chrome',
  });
  const context = await browser.newContext();
  await context.addInitScript(`localStorage.setItem('theme', '${expectedTheme}');`);
  const page = await context.newPage();
  await page.goto(url, { waitUntil: 'commit' });
  await page.waitForTimeout(50);
  const early = await page.screenshot();
  await page.waitForLoadState('networkidle');
  await page.waitForTimeout(500);
  const final = await page.screenshot();
  await browser.close();

  const eb = getAverageBrightness(early);
  const fb = getAverageBrightness(final);
  const earlyLight = eb > 150;
  const finalLight = fb > 150;
  const expectedLight = expectedTheme === 'light';
  const themeChanged = earlyLight !== finalLight;
  const earlyMatches = earlyLight === expectedLight;

  let diagnosis;
  if (themeChanged) diagnosis = `FLICKER: went from ${earlyLight ? 'light' : 'dark'} to ${finalLight ? 'light' : 'dark'}`;
  else if (!earlyMatches) diagnosis = `WRONG INITIAL: expected ${expectedTheme} got ${earlyLight ? 'light' : 'dark'}`;
  else diagnosis = 'OK: correct theme from first paint';

  return { url, expectedTheme, flickerDetected: themeChanged || !earlyMatches, earlyBrightness: Math.round(eb), finalBrightness: Math.round(fb), diagnosis };
}

const url = process.argv[2] || 'http://localhost:3000';
const theme = process.argv[3] || 'dark';
detectFlicker(url, theme).then((r) => console.log(JSON.stringify(r, null, 2)));
