#!/usr/bin/env python3
"""Calibrate, identify, tune and control the HVAC simulator."""
import json
import numpy as np
from scipy.optimize import curve_fit
from hvac_simulator import HVACSimulator


def run_calibration(sim, heater_power=50.0, duration=60.0):
    """Open-loop step test with safety monitoring."""
    initial_temp = sim.reset()
    data = [{"time": 0.0, "temperature": round(float(initial_temp), 4),
             "heater_power": 0.0}]

    limits = sim.get_safety_limits()
    max_safe = limits["max_temp"]

    steps = int(duration / sim.get_dt())
    cmd = heater_power
    for _ in range(steps):
        r = sim.step(cmd)
        data.append({"time": r["time"], "temperature": r["temperature"],
                     "heater_power": r["heater_power"]})
        # Safety: cut power if we approach max safe temp
        if r["temperature"] >= max_safe - 1.0:
            cmd = 0.0

    return {"phase": "calibration", "heater_power_test": heater_power,
            "data": data}, initial_temp


def estimate_params(cal_log, y_initial):
    """Fit first-order model to step response data."""
    data = cal_log["data"]
    u = cal_log["heater_power_test"]
    # Skip t=0 (power was 0); use data where heater is applied
    rising = [d for d in data if d["heater_power"] > 0]
    t = np.array([d["time"] - rising[0]["time"] for d in rising])
    y = np.array([d["temperature"] for d in rising])

    y0 = float(y_initial)

    def model(tt, K, tau):
        return y0 + K * u * (1.0 - np.exp(-tt / tau))

    K_guess = max((y[-1] - y0) / u, 1e-3)
    tau_guess = max(t[len(t) // 3], 5.0)

    popt, _ = curve_fit(model, t, y, p0=[K_guess, tau_guess],
                        bounds=([1e-4, 1.0], [10.0, 1000.0]))
    K, tau = float(popt[0]), float(popt[1])

    y_pred = model(t, K, tau)
    ss_res = float(np.sum((y - y_pred) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else 0.0
    rmse = float(np.sqrt(np.mean((y - y_pred) ** 2)))

    return {"K": K, "tau": tau, "r_squared": r2, "fitting_error": rmse}


def tune_imc(K, tau, lambda_factor=0.5):
    lam = lambda_factor * tau
    Kp = tau / (K * lam)
    Ki = Kp / tau
    return {"Kp": float(Kp), "Ki": float(Ki), "Kd": 0.0,
            "lambda": float(lam)}


def run_control(sim, gains, setpoint=22.0, duration=200.0):
    initial = sim.reset()
    dt = sim.get_dt()
    Kp, Ki = gains["Kp"], gains["Ki"]
    integral = 0.0
    data = [{"time": 0.0, "temperature": round(float(initial), 4),
             "setpoint": setpoint, "heater_power": 0.0,
             "error": round(setpoint - float(initial), 4)}]

    measurement = float(initial)
    steps = int(duration / dt)
    for _ in range(steps):
        err = setpoint - measurement
        integral += err * dt
        u_raw = Kp * err + Ki * integral
        u = max(0.0, min(100.0, u_raw))
        # Anti-windup: back-calculate integral if saturated
        if u != u_raw and Ki > 0:
            integral -= err * dt  # undo last contribution when saturated

        r = sim.step(u)
        measurement = r["temperature"]
        data.append({"time": r["time"], "temperature": r["temperature"],
                     "setpoint": setpoint, "heater_power": r["heater_power"],
                     "error": round(setpoint - measurement, 4)})

    return {"phase": "control", "setpoint": setpoint, "data": data}


def compute_metrics(control_log):
    data = control_log["data"]
    sp = control_log["setpoint"]
    t = np.array([d["time"] for d in data])
    y = np.array([d["temperature"] for d in data])
    y0 = y[0]
    delta = sp - y0

    # Rise time: 10% -> 90%
    y10, y90 = y0 + 0.1 * delta, y0 + 0.9 * delta
    i10 = np.argmax(y >= y10) if np.any(y >= y10) else -1
    i90 = np.argmax(y >= y90) if np.any(y >= y90) else -1
    rise_time = float(t[i90] - t[i10]) if i10 >= 0 and i90 >= 0 else float("nan")

    # Overshoot (upward step): peak above setpoint, normalized by delta
    peak = float(np.max(y))
    overshoot = max(0.0, peak - sp) / delta if delta > 0 else 0.0

    # Settling time: earliest t after which the RMS error in a 10 s
    # trailing window stays within a 5%-of-delta band for the rest of the
    # record. Using RMS over a window rejects single-sample noise spikes.
    dt_est = float(t[1] - t[0]) if len(t) > 1 else 0.5
    win = max(1, int(round(10.0 / dt_est)))
    band = max(0.05 * delta, 0.15)
    err = y - sp
    rms = np.array([np.sqrt(np.mean(err[max(0, i - win + 1):i + 1] ** 2))
                    for i in range(len(err))])
    outside = np.where(rms > band)[0]
    settling_time = float(t[outside[-1]]) if len(outside) else float(t[0])

    # Steady-state error: mean over last 20s
    last_mask = t >= (t[-1] - 20.0)
    sse = float(np.mean(np.abs(y[last_mask] - sp)))

    return {
        "rise_time": rise_time,
        "overshoot": float(overshoot),
        "settling_time": settling_time,
        "steady_state_error": sse,
        "max_temp": peak,
    }


def main():
    np.random.seed(42)

    # --- Calibration ---
    sim = HVACSimulator()
    cal_log, y_initial = run_calibration(sim, heater_power=50.0, duration=60.0)
    with open("/root/calibration_log.json", "w") as f:
        json.dump(cal_log, f, indent=2)
    print(f"Calibration: {len(cal_log['data'])} points, "
          f"T0={y_initial:.2f}C, T_end={cal_log['data'][-1]['temperature']:.2f}C")

    # --- Parameter estimation ---
    params = estimate_params(cal_log, y_initial)
    with open("/root/estimated_params.json", "w") as f:
        json.dump(params, f, indent=2)
    print(f"Estimated: K={params['K']:.4f}, tau={params['tau']:.2f}, "
          f"R^2={params['r_squared']:.4f}")

    # --- IMC tuning ---
    gains = tune_imc(params["K"], params["tau"], lambda_factor=0.5)
    with open("/root/tuned_gains.json", "w") as f:
        json.dump(gains, f, indent=2)
    print(f"Gains: Kp={gains['Kp']:.3f}, Ki={gains['Ki']:.4f}, "
          f"lambda={gains['lambda']:.2f}")

    # --- Closed-loop control ---
    sim2 = HVACSimulator()
    ctrl_log = run_control(sim2, gains, setpoint=22.0, duration=200.0)
    with open("/root/control_log.json", "w") as f:
        json.dump(ctrl_log, f, indent=2)

    metrics = compute_metrics(ctrl_log)
    with open("/root/metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"Metrics: {metrics}")


if __name__ == "__main__":
    main()
