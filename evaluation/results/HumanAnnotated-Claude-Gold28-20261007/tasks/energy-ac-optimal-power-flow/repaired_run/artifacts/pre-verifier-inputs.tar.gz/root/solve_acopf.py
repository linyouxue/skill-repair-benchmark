"""AC OPF solver for base-case planning.

Builds an AC OPF matching the formulation in math-model.md using CasADi + IPOPT,
then writes a report.json summary.
"""
import json
import math
import numpy as np
import casadi as ca


def build_bus_id_to_idx(buses):
    return {int(buses[i, 0]): i for i in range(buses.shape[0])}


def branch_params(br):
    """Return (g, b, bc, tap, shift_rad) for a branch row."""
    r, x, bc = float(br[2]), float(br[3]), float(br[4])
    tap = float(br[8])
    shift = float(br[9])
    if abs(tap) < 1e-12:
        tap = 1.0
    shift_rad = math.radians(shift)
    denom = r * r + x * x
    if denom < 1e-20:
        g = 0.0
        b = 0.0
    else:
        g = r / denom
        b = -x / denom
    return g, b, bc, tap, shift_rad


def branch_flow_sym(Vmi, Vmj, dij, dji, g, b, bc, tap):
    """Symbolic branch flows (per unit). Returns (P_ij, Q_ij, P_ji, Q_ji)."""
    inv_t = 1.0 / tap
    inv_t2 = inv_t * inv_t
    cos_ij = ca.cos(dij)
    sin_ij = ca.sin(dij)
    cos_ji = ca.cos(dji)
    sin_ji = ca.sin(dji)
    Vij = Vmi * Vmj
    P_ij = g * Vmi * Vmi * inv_t2 - Vij * inv_t * (g * cos_ij + b * sin_ij)
    Q_ij = -(b + bc / 2.0) * Vmi * Vmi * inv_t2 - Vij * inv_t * (g * sin_ij - b * cos_ij)
    P_ji = g * Vmj * Vmj - Vij * inv_t * (g * cos_ji + b * sin_ji)
    Q_ji = -(b + bc / 2.0) * Vmj * Vmj - Vij * inv_t * (g * sin_ji - b * cos_ji)
    return P_ij, Q_ij, P_ji, Q_ji


def branch_flow_np(Vmi, Vmj, dij, dji, g, b, bc, tap):
    inv_t = 1.0 / tap
    inv_t2 = inv_t * inv_t
    cos_ij = math.cos(dij)
    sin_ij = math.sin(dij)
    cos_ji = math.cos(dji)
    sin_ji = math.sin(dji)
    Vij = Vmi * Vmj
    P_ij = g * Vmi * Vmi * inv_t2 - Vij * inv_t * (g * cos_ij + b * sin_ij)
    Q_ij = -(b + bc / 2.0) * Vmi * Vmi * inv_t2 - Vij * inv_t * (g * sin_ij - b * cos_ij)
    P_ji = g * Vmj * Vmj - Vij * inv_t * (g * cos_ji + b * sin_ji)
    Q_ji = -(b + bc / 2.0) * Vmj * Vmj - Vij * inv_t * (g * sin_ji - b * cos_ji)
    return P_ij, Q_ij, P_ji, Q_ji


def main():
    with open("/root/network.json") as f:
        data = json.load(f)

    baseMVA = float(data["baseMVA"])
    buses = np.array(data["bus"], dtype=float)
    gens = np.array(data["gen"], dtype=float)
    branches = np.array(data["branch"], dtype=float)
    gencost = np.array(data["gencost"], dtype=float)

    n_bus = buses.shape[0]
    n_gen = gens.shape[0]
    n_br = branches.shape[0]

    bus_id_to_idx = build_bus_id_to_idx(buses)

    # Bus data
    bus_ids = buses[:, 0].astype(int)
    bus_type = buses[:, 1].astype(int)
    Pd = buses[:, 2] / baseMVA
    Qd = buses[:, 3] / baseMVA
    Gs = buses[:, 4] / baseMVA  # pu at |V|=1
    Bs = buses[:, 5] / baseMVA
    Vm0 = buses[:, 7]
    Va0 = np.deg2rad(buses[:, 8])
    Vmax = buses[:, 11]
    Vmin = buses[:, 12]

    # Generator data
    gen_bus_idx = np.array([bus_id_to_idx[int(g[0])] for g in gens], dtype=int)
    Pg0 = gens[:, 1] / baseMVA
    Qg0 = gens[:, 2] / baseMVA
    Qmax = gens[:, 3] / baseMVA
    Qmin = gens[:, 4] / baseMVA
    Pmax = gens[:, 8] / baseMVA
    Pmin = gens[:, 9] / baseMVA

    # Cost (polynomial c2 P^2 + c1 P + c0 in MW)
    c2 = gencost[:, 4]
    c1 = gencost[:, 5]
    c0 = gencost[:, 6]

    # Reference bus
    ref_bus_idx = int(np.where(bus_type == 3)[0][0])

    # Decision variables
    Vm = ca.MX.sym("Vm", n_bus)
    Va = ca.MX.sym("Va", n_bus)
    Pg = ca.MX.sym("Pg", n_gen)
    Qg = ca.MX.sym("Qg", n_gen)
    x = ca.vertcat(Vm, Va, Pg, Qg)

    # Objective (MW)
    Pg_MW = Pg * baseMVA
    obj = ca.MX(0)
    for k in range(n_gen):
        obj += c2[k] * Pg_MW[k] ** 2 + c1[k] * Pg_MW[k] + c0[k]

    # Per-bus accumulators
    P_out = [ca.MX(0) for _ in range(n_bus)]
    Q_out = [ca.MX(0) for _ in range(n_bus)]

    g_expr = []
    lbg = []
    ubg = []

    # Branch flow equations and limits
    for e in range(n_br):
        br = branches[e]
        i = bus_id_to_idx[int(br[0])]
        j = bus_id_to_idx[int(br[1])]
        g_s, b_s, bc, tap, shift_rad = branch_params(br)
        rate_a = float(br[5]) / baseMVA  # MVA -> pu
        ang_min = math.radians(float(br[11]))
        ang_max = math.radians(float(br[12]))

        dij = Va[i] - Va[j] - shift_rad
        dji = Va[j] - Va[i] + shift_rad

        P_ij, Q_ij, P_ji, Q_ji = branch_flow_sym(Vm[i], Vm[j], dij, dji, g_s, b_s, bc, tap)

        P_out[i] += P_ij
        Q_out[i] += Q_ij
        P_out[j] += P_ji
        Q_out[j] += Q_ji

        # Thermal MVA limits (both directions): |S|^2 <= rateA^2
        if rate_a > 0.0:
            lim2 = rate_a * rate_a
            g_expr.append(P_ij * P_ij + Q_ij * Q_ij)
            lbg.append(-ca.inf); ubg.append(lim2)
            g_expr.append(P_ji * P_ji + Q_ji * Q_ji)
            lbg.append(-ca.inf); ubg.append(lim2)

        # Angle difference bounds
        g_expr.append(Va[i] - Va[j])
        lbg.append(ang_min); ubg.append(ang_max)

    # Per-bus generation sums
    Pg_bus = [ca.MX(0) for _ in range(n_bus)]
    Qg_bus = [ca.MX(0) for _ in range(n_bus)]
    for k in range(n_gen):
        bi = int(gen_bus_idx[k])
        Pg_bus[bi] += Pg[k]
        Qg_bus[bi] += Qg[k]

    # Nodal power balance: Pg - Pd - Gs|V|^2 = P_out ; Qg - Qd + Bs|V|^2 = Q_out
    for i in range(n_bus):
        g_expr.append(Pg_bus[i] - Pd[i] - Gs[i] * Vm[i] ** 2 - P_out[i])
        lbg.append(0.0); ubg.append(0.0)
        g_expr.append(Qg_bus[i] - Qd[i] + Bs[i] * Vm[i] ** 2 - Q_out[i])
        lbg.append(0.0); ubg.append(0.0)

    # Reference angle = 0
    g_expr.append(Va[ref_bus_idx])
    lbg.append(0.0); ubg.append(0.0)

    g = ca.vertcat(*g_expr)

    # Variable bounds
    lbx = np.concatenate([Vmin, -2 * np.pi * np.ones(n_bus), Pmin, Qmin]).tolist()
    ubx = np.concatenate([Vmax, 2 * np.pi * np.ones(n_bus), Pmax, Qmax]).tolist()

    # Initializations
    x0_data = np.concatenate([Vm0, Va0, Pg0, Qg0])
    # Clip to bounds
    x0_data = np.clip(x0_data, lbx, ubx)
    # Enforce reference angle
    x0_data[n_bus + ref_bus_idx] = 0.0

    x0_flat = np.concatenate([
        np.ones(n_bus),
        np.zeros(n_bus),
        np.clip((Pmin + Pmax) / 2.0, Pmin, Pmax),
        np.clip((Qmin + Qmax) / 2.0, Qmin, Qmax),
    ])

    nlp = {"x": x, "f": obj, "g": g}
    opts = {
        "ipopt.print_level": 0,
        "ipopt.max_iter": 3000,
        "ipopt.tol": 1e-8,
        "ipopt.acceptable_tol": 1e-6,
        "ipopt.mu_strategy": "adaptive",
        "print_time": False,
    }
    solver = ca.nlpsol("solver", "ipopt", nlp, opts)

    best = None
    best_obj = float("inf")
    for label, x0 in [("data", x0_data), ("flat", x0_flat)]:
        try:
            sol = solver(x0=x0, lbx=lbx, ubx=ubx, lbg=lbg, ubg=ubg)
            stats = solver.stats()
            if not stats.get("success", False):
                print(f"[{label}] not successful: {stats.get('return_status')}")
                continue
            fval = float(sol["f"])
            print(f"[{label}] obj = {fval:.4f}, status = {stats.get('return_status')}")
            if fval < best_obj:
                best_obj = fval
                best = (sol, stats, label)
        except Exception as ex:
            print(f"[{label}] exception: {ex}")

    if best is None:
        raise RuntimeError("Solver failed from all initializations")

    sol, stats, best_label = best
    print(f"Best init: {best_label}, obj = {best_obj:.4f}")

    x_opt = np.array(sol["x"]).flatten()
    Vm_s = x_opt[:n_bus]
    Va_s = x_opt[n_bus:2 * n_bus]
    Pg_s = x_opt[2 * n_bus:2 * n_bus + n_gen]
    Qg_s = x_opt[2 * n_bus + n_gen:]

    # Build report
    total_cost = best_obj
    total_load_MW = float(np.sum(buses[:, 2]))
    total_load_MVAr = float(np.sum(buses[:, 3]))
    total_gen_MW = float(np.sum(Pg_s * baseMVA))
    total_gen_MVAr = float(np.sum(Qg_s * baseMVA))

    # Compute branch flows and feasibility metrics
    P_out_np = np.zeros(n_bus)
    Q_out_np = np.zeros(n_bus)
    branch_results = []
    max_overload = 0.0
    for e in range(n_br):
        br = branches[e]
        i = bus_id_to_idx[int(br[0])]
        j = bus_id_to_idx[int(br[1])]
        g_s, b_s, bc, tap, shift_rad = branch_params(br)
        rate_a_MVA = float(br[5])
        rate_a_pu = rate_a_MVA / baseMVA
        dij = Va_s[i] - Va_s[j] - shift_rad
        dji = Va_s[j] - Va_s[i] + shift_rad
        P_ij, Q_ij, P_ji, Q_ji = branch_flow_np(Vm_s[i], Vm_s[j], dij, dji, g_s, b_s, bc, tap)
        P_out_np[i] += P_ij; Q_out_np[i] += Q_ij
        P_out_np[j] += P_ji; Q_out_np[j] += Q_ji
        S_ij_MVA = math.hypot(P_ij, Q_ij) * baseMVA
        S_ji_MVA = math.hypot(P_ji, Q_ji) * baseMVA
        S_max_MVA = max(S_ij_MVA, S_ji_MVA)
        if rate_a_MVA > 0:
            loading = 100.0 * S_max_MVA / rate_a_MVA
            over = max(0.0, S_max_MVA - rate_a_MVA)
            if over > max_overload:
                max_overload = over
        else:
            loading = 0.0
        branch_results.append({
            "from_bus": int(br[0]),
            "to_bus": int(br[1]),
            "loading_pct": round(loading, 4),
            "flow_from_MVA": round(S_ij_MVA, 6),
            "flow_to_MVA": round(S_ji_MVA, 6),
            "limit_MVA": round(rate_a_MVA, 6),
        })

    # Nodal mismatch
    Pg_bus_np = np.zeros(n_bus)
    Qg_bus_np = np.zeros(n_bus)
    for k in range(n_gen):
        bi = int(gen_bus_idx[k])
        Pg_bus_np[bi] += Pg_s[k]
        Qg_bus_np[bi] += Qg_s[k]

    P_mismatch_pu = Pg_bus_np - Pd - Gs * Vm_s ** 2 - P_out_np
    Q_mismatch_pu = Qg_bus_np - Qd + Bs * Vm_s ** 2 - Q_out_np
    max_p_mismatch_MW = float(np.max(np.abs(P_mismatch_pu)) * baseMVA)
    max_q_mismatch_MVAr = float(np.max(np.abs(Q_mismatch_pu)) * baseMVA)

    # Voltage violations
    v_viol = np.maximum.reduce([Vmin - Vm_s, Vm_s - Vmax, np.zeros(n_bus)])
    max_v_viol = float(np.max(v_viol))

    # Losses: generation - demand (MW)
    total_losses_MW = total_gen_MW - total_load_MW

    # Status
    ret_status = stats.get("return_status", "unknown")
    solver_status = "optimal" if ret_status == "Solve_Succeeded" else ret_status

    # Generators list
    gen_list = []
    for k in range(n_gen):
        gen_list.append({
            "id": k + 1,
            "bus": int(gens[k, 0]),
            "pg_MW": round(float(Pg_s[k] * baseMVA), 6),
            "qg_MVAr": round(float(Qg_s[k] * baseMVA), 6),
            "pmin_MW": round(float(gens[k, 9]), 6),
            "pmax_MW": round(float(gens[k, 8]), 6),
            "qmin_MVAr": round(float(gens[k, 4]), 6),
            "qmax_MVAr": round(float(gens[k, 3]), 6),
        })

    # Buses list
    bus_list = []
    for i in range(n_bus):
        bus_list.append({
            "id": int(bus_ids[i]),
            "vm_pu": round(float(Vm_s[i]), 6),
            "va_deg": round(float(math.degrees(Va_s[i])), 6),
            "vmin_pu": round(float(Vmin[i]), 6),
            "vmax_pu": round(float(Vmax[i]), 6),
        })

    # Most loaded branches: top 10 by loading_pct
    most_loaded = sorted(branch_results, key=lambda b: b["loading_pct"], reverse=True)[:10]

    report = {
        "summary": {
            "total_cost_per_hour": round(float(total_cost), 2),
            "total_load_MW": round(total_load_MW, 6),
            "total_load_MVAr": round(total_load_MVAr, 6),
            "total_generation_MW": round(total_gen_MW, 6),
            "total_generation_MVAr": round(total_gen_MVAr, 6),
            "total_losses_MW": round(total_losses_MW, 6),
            "solver_status": solver_status,
        },
        "generators": gen_list,
        "buses": bus_list,
        "most_loaded_branches": most_loaded,
        "feasibility_check": {
            "max_p_mismatch_MW": round(max_p_mismatch_MW, 9),
            "max_q_mismatch_MVAr": round(max_q_mismatch_MVAr, 9),
            "max_voltage_violation_pu": round(max_v_viol, 9),
            "max_branch_overload_MVA": round(max_overload, 9),
        },
    }

    with open("/root/report.json", "w") as f:
        json.dump(report, f, indent=2)

    print("\nReport summary:")
    print(json.dumps(report["summary"], indent=2))
    print("\nFeasibility:")
    print(json.dumps(report["feasibility_check"], indent=2))
    print(f"\nTop 3 loaded branches:")
    for b in most_loaded[:3]:
        print(f"  {b['from_bus']} -> {b['to_bus']}: {b['loading_pct']:.2f}% "
              f"({b['flow_from_MVA']:.1f}/{b['flow_to_MVA']:.1f} / {b['limit_MVA']:.1f} MVA)")


if __name__ == "__main__":
    main()
