import java.nio.charset.{Charset, StandardCharsets}
import java.time.{LocalDate, LocalDateTime}
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAccessor

import scala.collection.mutable.ListBuffer
import scala.util.Try

/**
 * Tokenizer module for converting various input types to standardized string tokens.
 *
 * This module demonstrates several Scala abstractions that mirror the flexibility of
 * the original Python implementation:
 *   - Variance annotations for generic containers (+T / -T)
 *   - Sealed hierarchies for algebraic data types (TokenType, JsonValue)
 *   - Type-class-style dispatch instead of runtime duck typing
 *   - Option/Try for natural handling of absence and errors
 */
object Tokenizer {

  // ============================================================================
  // Structural typing (Python Protocols) -> Scala traits
  // ============================================================================

  /** Anything that can be converted to a token string. */
  trait Tokenizable {
    def toToken: String
  }

  /** Anything that exposes a length. */
  trait HasLength {
    def length: Int
  }

  /** Contravariant processor that consumes tokens. */
  trait TokenProcessor[-A] {
    def process(item: A): Unit
  }

  // ============================================================================
  // Enums and Constants
  // ============================================================================

  /** Token categories, modeled as a sealed hierarchy of singletons. */
  sealed abstract class TokenType(val value: String)

  object TokenType {
    case object STRING extends TokenType("string")
    case object NUMERIC extends TokenType("numeric")
    case object TEMPORAL extends TokenType("temporal")
    case object STRUCTURED extends TokenType("structured")
    case object BINARY extends TokenType("binary")
    case object NULL extends TokenType("null")

    val values: List[TokenType] =
      List(STRING, NUMERIC, TEMPORAL, STRUCTURED, BINARY, NULL)

    def fromValue(value: String): Option[TokenType] =
      values.find(_.value == value)
  }

  // ============================================================================
  // Core Token Classes
  // ============================================================================

  /** Immutable token representation. */
  final case class Token(
      value: String,
      tokenType: TokenType,
      metadata: Map[String, Any] = Map.empty
  ) {

    /** Return a new token with additional metadata merged in. */
    def withMetadata(additional: (String, Any)*): Token =
      copy(metadata = metadata ++ additional)
  }

  /** Mutable batch of tokens - contrast with immutable [[Token]]. */
  final class MutableTokenBatch {
    private val _tokens: ListBuffer[Token] = ListBuffer.empty
    private var processed: Boolean = false

    def add(token: Token): Unit = {
      if (processed) throw new IllegalStateException("Batch already processed")
      _tokens += token
    }

    def markProcessed(): Unit =
      processed = true

    def tokens: List[Token] = _tokens.toList
  }

  // ============================================================================
  // Generic Container Classes
  // ============================================================================

  /** Covariant container - can return subtypes. */
  final class TokenContainer[+T](items: Seq[T]) {
    private val stored: Vector[T] = items.toVector

    def getAll: Vector[T] = stored

    def mapTokens[B >: T](f: B => String): List[String] =
      stored.iterator.map(f).toList
  }

  /** Contravariant sink - can accept supertypes. */
  final class TokenSink[-T] {
    private val received: ListBuffer[Any] = ListBuffer.empty

    def receive(item: T): Unit =
      received += item

    def drain(): List[Any] = {
      val result = received.toList
      received.clear()
      result
    }
  }

  /** Invariant handler - exact type matching required. */
  final class BivariantHandler[T](default: T) {
    private var value: T = default

    def get: T = value

    def set(value: T): Unit =
      this.value = value

    def transform(f: T => T): T = {
      value = f(value)
      value
    }
  }

  // ============================================================================
  // Tokenizer Implementations
  // ============================================================================

  /** Abstract base tokenizer with generic input type. */
  trait BaseTokenizer[T] {

    /** Convert a value to a token. */
    def tokenize(value: T): Token

    /** Lazily tokenize multiple values. */
    def tokenizeBatch(values: Iterable[T]): Iterator[Token] =
      values.iterator.map(tokenize)
  }

  /** Tokenizer for string and byte-array types. */
  final class StringTokenizer(
      val encoding: Charset = StandardCharsets.UTF_8,
      normalizer: String => String = identity
  ) extends BaseTokenizer[String] {

    override def tokenize(value: String): Token =
      Token(normalizer(value), TokenType.STRING)

    def tokenize(value: Array[Byte]): Token =
      tokenize(new String(value, encoding))
  }

  /** Tokenizer for numeric types with precision handling. */
  final class NumericTokenizer(
      val precision: Int = 6,
      val formatOptions: Map[String, Any] = Map.empty
  ) extends BaseTokenizer[BigDecimal] {

    override def tokenize(value: BigDecimal): Token =
      Token(format(value), TokenType.NUMERIC, Map("original_type" -> "BigDecimal"))

    def tokenize(value: Double): Token =
      Token(format(BigDecimal(value)), TokenType.NUMERIC, Map("original_type" -> "Double"))

    def tokenize(value: Float): Token =
      Token(format(BigDecimal(value.toDouble)), TokenType.NUMERIC, Map("original_type" -> "Float"))

    def tokenize(value: Int): Token =
      Token(value.toString, TokenType.NUMERIC, Map("original_type" -> "Int"))

    def tokenize(value: Long): Token =
      Token(value.toString, TokenType.NUMERIC, Map("original_type" -> "Long"))

    private def format(value: BigDecimal): String =
      value.setScale(precision, BigDecimal.RoundingMode.HALF_EVEN).toString
  }

  /** Tokenizer for date/time types. */
  final class TemporalTokenizer(format: Option[DateTimeFormatter] = None)
      extends BaseTokenizer[TemporalAccessor] {

    override def tokenize(value: TemporalAccessor): Token = {
      val formatter = format.getOrElse {
        value match {
          case _: LocalDateTime => TemporalTokenizer.IsoFormatter
          case _                => TemporalTokenizer.DateFormatter
        }
      }
      Token(formatter.format(value), TokenType.TEMPORAL)
    }
  }

  object TemporalTokenizer {
    val IsoFormatter: DateTimeFormatter =
      DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
    val DateFormatter: DateTimeFormatter =
      DateTimeFormatter.ofPattern("yyyy-MM-dd")
  }

  // ============================================================================
  // Advanced: Runtime Type Dispatch
  // ============================================================================

  /** Tokenizer that handles multiple types via pattern matching. */
  final class UniversalTokenizer {
    private val stringTokenizer = new StringTokenizer()
    private val numericTokenizer = new NumericTokenizer()
    private val temporalTokenizer = new TemporalTokenizer()

    def tokenize(value: Any): Token = value match {
      case null                    => Token("NULL", TokenType.NULL)
      case t: Tokenizable          => Token(t.toToken, TokenType.STRUCTURED)
      case s: String               => stringTokenizer.tokenize(s)
      case b: Array[Byte]          => stringTokenizer.tokenize(b)
      case d: BigDecimal           => numericTokenizer.tokenize(d)
      case d: Double               => numericTokenizer.tokenize(d)
      case f: Float                => numericTokenizer.tokenize(f)
      case i: Int                  => numericTokenizer.tokenize(i)
      case l: Long                 => numericTokenizer.tokenize(l)
      case dt: LocalDateTime       => temporalTokenizer.tokenize(dt)
      case d: LocalDate            => temporalTokenizer.tokenize(d)
      case other                   => Token(other.toString, TokenType.STRING, Map("fallback" -> true))
    }
  }

  // ============================================================================
  // Complex Nested Generics
  // ============================================================================

  /** Registry with nested generic types and pluggable handlers. */
  final class TokenRegistry[T] {
    private var registry: Map[String, TokenContainer[T]] = Map.empty
    private val handlers: ListBuffer[T => Option[Token]] = ListBuffer.empty

    def register(key: String, container: TokenContainer[T]): Unit =
      registry = registry.updated(key, container)

    def addHandler(handler: T => Option[Token]): Unit =
      handlers += handler

    def process(key: String): List[Option[Token]] =
      registry.get(key) match {
        case None => List.empty
        case Some(container) =>
          container.getAll.map { item =>
            handlers.iterator
              .map(handler => handler(item))
              .collectFirst { case Some(token) => token }
          }.toList
      }
  }

  // ============================================================================
  // Functor / Monad Simulation
  // ============================================================================

  /**
   * Minimal functor. In idiomatic Scala, [[Option]] already provides these
   * operations; this type exists only to mirror the original structure.
   */
  class TokenFunctor[A](val value: A) {
    def map[B](f: A => B): TokenFunctor[B] =
      new TokenFunctor(f(value))

    def flatMap[B](f: A => TokenFunctor[B]): TokenFunctor[B] =
      f(value)

    def getOrElse(default: A): A =
      Option(value).getOrElse(default)
  }

  /** Extended monad operations over [[TokenFunctor]]. */
  class TokenMonad[A](value: A) extends TokenFunctor[A](value) {

    /** Applicative apply. */
    def ap[B](funcWrapped: TokenMonad[A => B]): TokenMonad[B] =
      new TokenMonad(funcWrapped.value(value))
  }

  object TokenMonad {
    def pure[A](value: A): TokenMonad[A] = new TokenMonad(value)
  }

  // ============================================================================
  // JSON Structure Tokenization
  // ============================================================================

  /** Recursive JSON value, modeled as a sealed algebraic data type. */
  sealed trait JsonValue

  object JsonValue {
    case object JsonNull extends JsonValue
    final case class JsonBool(value: Boolean) extends JsonValue
    final case class JsonNumber(value: BigDecimal) extends JsonValue
    final case class JsonString(value: String) extends JsonValue
    final case class JsonArray(values: Vector[JsonValue]) extends JsonValue
    final case class JsonObject(fields: Vector[(String, JsonValue)]) extends JsonValue

    /** Serialize a JSON value to its textual representation. */
    def render(value: JsonValue, pretty: Boolean = false): String =
      renderValue(value, pretty, 0)

    private def renderValue(value: JsonValue, pretty: Boolean, level: Int): String = {
      val indent = if (pretty) "  " * level else ""
      val childIndent = if (pretty) "  " * (level + 1) else ""
      val newline = if (pretty) "\n" else ""

      value match {
        case JsonNull          => "null"
        case JsonBool(b)       => b.toString
        case JsonNumber(n)     => n.bigDecimal.toPlainString
        case JsonString(s)     => "\"" + escape(s) + "\""
        case JsonArray(values) =>
          if (values.isEmpty) "[]"
          else {
            val body = values
              .map(renderValue(_, pretty, level + 1))
              .mkString("," + newline + childIndent)
            "[" + newline + childIndent + body + newline + indent + "]"
          }
        case JsonObject(fields) =>
          if (fields.isEmpty) "{}"
          else {
            val body = fields
              .map { case (k, v) =>
                "\"" + escape(k) + "\":" + (if (pretty) " " else "") +
                  renderValue(v, pretty, level + 1)
              }
              .mkString("," + newline + childIndent)
            "{" + newline + childIndent + body + newline + indent + "}"
          }
      }
    }

    private def escape(s: String): String = {
      val sb = new StringBuilder
      s.foreach {
        case '"'  => sb.append("\\\"")
        case '\\' => sb.append("\\\\")
        case '\b' => sb.append("\\b")
        case '\f' => sb.append("\\f")
        case '\n' => sb.append("\\n")
        case '\r' => sb.append("\\r")
        case '\t' => sb.append("\\t")
        case c if c < ' ' => sb.append(f"\\u${c.toInt}%04x")
        case c    => sb.append(c)
      }
      sb.toString()
    }
  }

  /** Tokenizer for JSON structures with recursive types. */
  final class JsonTokenizer(pretty: Boolean = false) {
    import JsonValue._

    def tokenize(value: JsonValue): Token =
      Token(JsonValue.render(value, pretty), TokenType.STRUCTURED, Map("json" -> true))

    /** Extract and tokenize the value located at a dotted JSON path. */
    def tokenizePath(value: JsonValue, path: String): Option[Token] = {
      val parts = path.split('.').toVector
      parts
        .foldLeft(Option(value)) { (current, part) =>
          current.flatMap {
            case JsonObject(fields) =>
              fields.collectFirst { case (k, v) if k == part => v }
            case JsonArray(values) if part.nonEmpty && part.forall(_.isDigit) =>
              Try(part.toInt).toOption.flatMap { idx =>
                if (idx >= 0 && idx < values.length) Some(values(idx)) else None
              }
            case _ => None
          }
        }
        .map(v => tokenize(v))
    }
  }

  // ============================================================================
  // Whitespace Tokenizer - Basic Text Tokenization
  // ============================================================================

  /** Splits text by whitespace into a sequence of tokens. */
  final class WhitespaceTokenizer(
      val lowercase: Boolean = false,
      val minLength: Int = 0,
      val maxLength: Option[Int] = None,
      val stripPunctuation: Boolean = false
  ) {
    private val punctuation: Set[Char] = ".,!?;:'\"()[]{}".toSet

    /** Process a single word into an optional token string. */
    private def processToken(word: String): Option[String] = {
      val stripped =
        if (stripPunctuation) word.dropWhile(punctuation).reverse.dropWhile(punctuation).reverse
        else word

      val lowered =
        if (lowercase) stripped.toLowerCase
        else stripped

      if (lowered.length < minLength) None
      else {
        val truncated = maxLength.fold(lowered) { max =>
          if (lowered.length > max) lowered.take(max) else lowered
        }
        Option.when(truncated.nonEmpty)(truncated)
      }
    }

    /** Split text by whitespace and return one token per word. */
    def tokenize(text: String): List[Token] =
      words(text).zipWithIndex.flatMap { case (word, i) =>
        processToken(word).map { processed =>
          Token(processed, TokenType.STRING, Map("position" -> i, "original" -> word))
        }
      }

    /** Convenience method returning only the token string values. */
    def tokenizeToStrings(text: String): List[String] =
      tokenize(text).map(_.value)

    /** Tokenize text and return tokens with their character offsets. */
    def tokenizeWithPositions(text: String): List[(String, Int, Int)] = {
      val result = ListBuffer.empty[(String, Int, Int)]
      var currentPos = 0

      words(text).foreach { word =>
        val start = text.indexOf(word, currentPos)
        val end = start + word.length
        processToken(word).foreach(processed => result += ((processed, start, end)))
        currentPos = end
      }

      result.toList
    }

    /** Return the number of tokens produced for the given text. */
    def countTokens(text: String): Int =
      tokenize(text).size

    /** Split on runs of whitespace, ignoring leading/trailing/empty tokens. */
    private def words(text: String): List[String] =
      text.split("\\s+").toList.filter(_.nonEmpty)
  }

  // ============================================================================
  // Builder Pattern with Fluent Interface
  // ============================================================================

  /** Fluent builder for creating tokenizers. */
  final class TokenizerBuilder[T] {
    private val normalizers: ListBuffer[String => String] = ListBuffer.empty
    private val validators: ListBuffer[T => Boolean] = ListBuffer.empty
    private var metadata: Map[String, Any] = Map.empty

    def withNormalizer(normalizer: String => String): TokenizerBuilder[T] = {
      normalizers += normalizer
      this
    }

    def withValidator(validator: T => Boolean): TokenizerBuilder[T] = {
      validators += validator
      this
    }

    def withMetadata(additional: (String, Any)*): TokenizerBuilder[T] = {
      metadata = metadata ++ additional
      this
    }

    /** Build the final tokenizer function. */
    def build(): T => Token = {
      val ns = normalizers.toList
      val vs = validators.toList
      val md = metadata

      (value: T) => {
        vs.foreach { validator =>
          if (!validator(value))
            throw new IllegalArgumentException(s"Validation failed for $value")
        }

        val strValue = ns.foldLeft(value.toString)((acc, f) => f(acc))
        Token(strValue, TokenType.STRING, md)
      }
    }
  }
}
