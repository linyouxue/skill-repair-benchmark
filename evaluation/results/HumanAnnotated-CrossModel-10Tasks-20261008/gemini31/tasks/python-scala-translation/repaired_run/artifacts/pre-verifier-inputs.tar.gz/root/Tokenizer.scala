package tokenizer

import java.time.{LocalDate, LocalDateTime}
import java.time.format.DateTimeFormatter
import io.circe.Json

trait Tokenizable {
  def toToken: String
}
trait HasLength {
  def length: Int
}

trait TokenProcessor[-T] {
  def process(item: T): Unit
}

case class MutableTokenBatch(
  var tokens: List[Token] = List.empty,
  private var _processed: Boolean = false
) {
  def add(token: Token): Unit = {
    if (_processed) {
      throw new RuntimeException("Batch already processed")
    }
    tokens = tokens :+ token
  }

  def markProcessed(): Unit = {
    _processed = true
  }
}
sealed trait TokenType {
  def value: String
}
object TokenType {
  case object STRING extends TokenType { val value = "string" }
  case object NUMERIC extends TokenType { val value = "numeric" }
  case object TEMPORAL extends TokenType { val value = "temporal" }
  case object STRUCTURED extends TokenType { val value = "structured" }
  case object BINARY extends TokenType { val value = "binary" }
  case object NULL extends TokenType { val value = "null" }
}

// Token
object Token {
  def apply(value: String, tokenType: TokenType): Token = {
    new Token(value, tokenType)
  }
}
case class Token(value: String, tokenType: TokenType, metadata: Map[String, Any] = Map.empty) {
  def withMetadata(newMetadata: (String, Any)*): Token = {
    copy(metadata = metadata ++ newMetadata)
  }
}

trait BaseTokenizer[T] {
  def tokenize(value: T): Token
  def tokenizeBatch(values: Iterable[T]): Iterator[Token] = values.iterator.map(tokenize)
}

class StringTokenizer(encoding: String = "utf-8", normalizer: String => String = identity) extends BaseTokenizer[String] {
  def tokenize(value: String): Token = {
    Token(normalizer(value), TokenType.STRING)
  }
}

class NumericTokenizer(precision: Int = 6, formatOptions: Map[String, Any] = Map.empty) extends BaseTokenizer[Number] {
  def tokenize(value: Number): Token = {
    val strValue = value match {
      case d: java.math.BigDecimal => s"%.${precision}f".format(d)
      case f: java.lang.Float => s"%.${precision}f".format(f)
      case d: java.lang.Double => s"%.${precision}f".format(d)
      case _ => value.toString
    }
    Token(strValue, TokenType.NUMERIC, Map("original_type" -> value.getClass.getSimpleName))
  }
}

class TemporalTokenizer(formatStr: Option[String] = None) extends BaseTokenizer[Either[LocalDate, LocalDateTime]] {
  val ISO_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE_TIME
  val DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE

  def tokenize(value: Either[LocalDate, LocalDateTime]): Token = {
    val fmt = formatStr.map(DateTimeFormatter.ofPattern).getOrElse {
      value match {
        case Right(_) => ISO_FORMAT
        case Left(_) => DATE_FORMAT
      }
    }

    val str = value match {
      case Right(dt) => dt.format(fmt)
      case Left(d) => d.format(fmt)
    }

    Token(str, TokenType.TEMPORAL)
  }
}

class UniversalTokenizer {
  private val stringTokenizer = new StringTokenizer()
  private val numericTokenizer = new NumericTokenizer()
  private val temporalTokenizer = new TemporalTokenizer()

  def tokenizeNull: Token = Token("NULL", TokenType.NULL)
  
  def tokenize(value: Any): Token = {
    value match {
      case null => tokenizeNull
      case t: Tokenizable => Token(t.toToken, TokenType.STRUCTURED)
      case s: String => stringTokenizer.tokenize(s)
      case n: Number => numericTokenizer.tokenize(n)
      case dt: LocalDateTime => temporalTokenizer.tokenize(Right(dt))
      case d: LocalDate => temporalTokenizer.tokenize(Left(d))
      case _ => Token(value.toString, TokenType.STRING, Map("fallback" -> true))
    }
  }
}

class TokenContainer[+T](items: Seq[T]) {
  private val _items = items.toVector
  def getAll: Vector[T] = _items
  def size: Int = _items.size
  def mapTokens(f: T => String): Seq[String] = _items.map(f)
}

class TokenSink[-T] {
  private var _received: List[Any] = List.empty

  def receive(item: T): Unit = {
    _received = _received :+ item
  }

  def drain(): List[Any] = {
    val result = _received
    _received = List.empty
    result
  }
}

class BivariantHandler[T](default: T) {
  private var _value: T = default

  def get(): T = _value

  def set(value: T): Unit = {
    _value = value
  }

  def transform(func: T => T): T = {
    _value = func(_value)
    _value
  }
}

class TokenRegistry[T] {
  private var _registry = Map.empty[String, TokenContainer[T]]
  private var _handlers = List.empty[T => Option[Token]]

  def register(key: String, container: TokenContainer[T]): Unit = {
    _registry = _registry + (key -> container)
  }

  def addHandler(handler: T => Option[Token]): Unit = {
    _handlers = _handlers :+ handler
  }

  def process(key: String): List[Option[Token]] = {
    _registry.get(key) match {
      case None => Nil
      case Some(container) =>
        container.getAll.map { item =>
          _handlers.iterator.map(h => h(item)).find(_.isDefined).flatten
        }.toList
    }
  }
}

class TokenFunctor[T](value: T) {
  def map[U](f: T => U): TokenFunctor[U] = new TokenFunctor(f(value))
  def flatMap[U](f: T => TokenFunctor[U]): TokenFunctor[U] = f(value)
  def getOrElse(default: => T): T = if (value != null) value else default
  def get: T = value
}

class TokenMonad[T](value: T) extends TokenFunctor[T](value) {
  def ap[U](funcWrapped: TokenMonad[T => U]): TokenMonad[U] = {
    new TokenMonad(funcWrapped.get(value))
  }
}

object TokenMonad {
  def pure[T](value: T): TokenMonad[T] = new TokenMonad(value)
}

class JsonTokenizer(pretty: Boolean = false) {
  def tokenize(value: Json): Token = {
    val jsonStr = if (pretty) value.spaces2 else value.noSpaces
    Token(jsonStr, TokenType.STRUCTURED, Map("json" -> true))
  }

  def tokenizePath(value: Json, path: String): Option[Token] = {
    val parts = path.split("\\.")
    var current: Option[Json] = Some(value)

    for (part <- parts) {
      current = current.flatMap { json =>
        json.asObject.flatMap(_.apply(part)).orElse {
          if (part.forall(_.isDigit)) {
            json.asArray.flatMap { arr =>
              val idx = part.toInt
              if (idx >= 0 && idx < arr.length) Some(arr(idx)) else None
            }
          } else None
        }
      }
    }

    current.map(tokenize)
  }
}

class WhitespaceTokenizer(
  lowercase: Boolean = false,
  minLength: Int = 0,
  maxLength: Option[Int] = None,
  stripPunctuation: Boolean = false
) {
  private val punctuation = Set('.', ',', '!', '?', ';', ':', '\'', '"', '(', ')', '[', ']', '{', '}')

  private def processToken(word: String): Option[String] = {
    var processed = word
    if (stripPunctuation) {
      processed = processed.dropWhile(punctuation.contains).reverse.dropWhile(punctuation.contains).reverse
    }
    if (lowercase) {
      processed = processed.toLowerCase
    }
    if (processed.length < minLength) return None
    
    maxLength match {
      case Some(max) if processed.length > max => Some(processed.take(max))
      case _ => if (processed.isEmpty) None else Some(processed)
    }
  }

  def tokenize(text: String): List[Token] = {
    text.split("\\s+").filter(_.nonEmpty).toList.zipWithIndex.flatMap { case (word, i) =>
      processToken(word).map { processed =>
        Token(processed, TokenType.STRING, Map("position" -> i, "original" -> word))
      }
    }
  }

  def tokenizeToStrings(text: String): List[String] = tokenize(text).map(_.value)
  
  def tokenizeWithPositions(text: String): List[(String, Int, Int)] = {
    var result: List[(String, Int, Int)] = Nil
    var currentPos = 0

    for (word <- text.split("\\s+").filter(_.nonEmpty)) {
      val start = text.indexOf(word, currentPos)
      val end = start + word.length

      processToken(word) match {
        case Some(processed) => result = result :+ (processed, start, end)
        case None => ()
      }

      currentPos = end
    }
    result
  }

  def countTokens(text: String): Int = tokenize(text).length
}

class TokenizerBuilder[T] {
  private var _normalizers: List[String => String] = Nil
  private var _validators: List[T => Boolean] = Nil
  private var _metadata: Map[String, Any] = Map.empty

  def withNormalizer(normalizer: String => String): TokenizerBuilder[T] = {
    _normalizers = _normalizers :+ normalizer
    this
  }

  def withValidator(validator: T => Boolean): TokenizerBuilder[T] = {
    _validators = _validators :+ validator
    this
  }

  def withMetadata(metadata: (String, Any)*): TokenizerBuilder[T] = {
    _metadata = _metadata ++ metadata
    this
  }

  def build(): T => Token = {
    val normalizers = _normalizers
    val validators = _validators
    val metadata = _metadata

    (value: T) => {
      if (!validators.forall(v => v(value))) {
        throw new IllegalArgumentException(s"Validation failed for $value")
      }
      val strValue = value.toString
      val normalized = normalizers.foldLeft(strValue)((str, norm) => norm(str))
      Token(normalized, TokenType.STRING, metadata)
    }
  }
}

object TokenizerBuilder {
  def apply[T](): TokenizerBuilder[T] = new TokenizerBuilder[T]()
}
