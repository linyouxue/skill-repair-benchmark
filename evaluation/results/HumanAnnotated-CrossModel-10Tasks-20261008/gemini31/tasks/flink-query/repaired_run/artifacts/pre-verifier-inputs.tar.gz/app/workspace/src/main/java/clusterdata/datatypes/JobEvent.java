package clusterdata.datatypes;

public class JobEvent {
    public long timestamp;
    public long missingInfo;
    public long jobId;
    public int eventType;
    public String userName;
    public int schedulingClass;
    public String jobName;
    public String logicalJobName;

    public JobEvent(long timestamp, long missingInfo, long jobId, int eventType, String userName, int schedulingClass, String jobName, String logicalJobName) {
        this.timestamp = timestamp;
        this.missingInfo = missingInfo;
        this.jobId = jobId;
        this.eventType = eventType;
        this.userName = userName;
        this.schedulingClass = schedulingClass;
        this.jobName = jobName;
        this.logicalJobName = logicalJobName;
    }

    public JobEvent() {}
}
