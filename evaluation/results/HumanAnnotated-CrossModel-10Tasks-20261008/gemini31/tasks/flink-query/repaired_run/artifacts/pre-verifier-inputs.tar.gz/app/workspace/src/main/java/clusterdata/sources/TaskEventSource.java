package clusterdata.sources;

import clusterdata.datatypes.TaskEvent;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.io.FileInputStream;

public class TaskEventSource implements SourceFunction<TaskEvent>, ResultTypeQueryable<TaskEvent> {
    private final String filePath;
    private volatile boolean isRunning = true;

    public TaskEventSource(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public void run(SourceContext<TaskEvent> sourceContext) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(filePath))))) {
            String line;
            while (isRunning && (line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                TaskEvent event = new TaskEvent();
                event.timestamp = parts[0].isEmpty() ? 0 : Long.parseLong(parts[0]);
                event.missingInfo = parts[1].isEmpty() ? 0 : Long.parseLong(parts[1]);
                event.jobId = parts[2].isEmpty() ? 0 : Long.parseLong(parts[2]);
                event.taskIndex = parts[3].isEmpty() ? 0 : Integer.parseInt(parts[3]);
                event.machineId = parts[4].isEmpty() ? 0 : Long.parseLong(parts[4]);
                event.eventType = parts[5].isEmpty() ? 0 : Integer.parseInt(parts[5]);
                event.userName = parts[6];
                event.schedulingClass = parts[7].isEmpty() ? 0 : Integer.parseInt(parts[7]);
                event.priority = parts[8].isEmpty() ? 0 : Integer.parseInt(parts[8]);
                event.resourceRequestCpu = parts[9].isEmpty() ? 0 : Double.parseDouble(parts[9]);
                event.resourceRequestRam = parts[10].isEmpty() ? 0 : Double.parseDouble(parts[10]);
                event.resourceRequestLocalDisk = parts[11].isEmpty() ? 0 : Double.parseDouble(parts[11]);
                event.differentMachineConstraint = parts[12].isEmpty() ? 0 : Integer.parseInt(parts[12]);
                sourceContext.collectWithTimestamp(event, event.timestamp);
            }
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }

    @Override
    public TypeInformation<TaskEvent> getProducedType() {
        return TypeInformation.of(TaskEvent.class);
    }
}