package clusterdata.datatypes;

public class TaskEvent {
    public long timestamp;
    public long missingInfo;
    public long jobId;
    public int taskIndex;
    public long machineId;
    public int eventType;
    public String userName;
    public int schedulingClass;
    public int priority;
    public double resourceRequestCpu;
    public double resourceRequestRam;
    public double resourceRequestLocalDisk;
    public int differentMachineConstraint;

    public TaskEvent() {}
}
