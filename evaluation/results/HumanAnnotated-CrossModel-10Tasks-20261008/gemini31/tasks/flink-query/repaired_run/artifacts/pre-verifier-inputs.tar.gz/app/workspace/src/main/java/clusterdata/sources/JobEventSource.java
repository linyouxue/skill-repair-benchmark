package clusterdata.sources;

import clusterdata.datatypes.JobEvent;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.ResultTypeQueryable;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.io.FileInputStream;

public class JobEventSource implements SourceFunction<JobEvent>, ResultTypeQueryable<JobEvent> {
    private final String filePath;
    private volatile boolean isRunning = true;

    public JobEventSource(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public void run(SourceContext<JobEvent> sourceContext) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(filePath))))) {
            String line;
            while (isRunning && (line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                JobEvent event = new JobEvent();
                event.timestamp = parts[0].isEmpty() ? 0 : Long.parseLong(parts[0]);
                event.missingInfo = parts[1].isEmpty() ? 0 : Long.parseLong(parts[1]);
                event.jobId = parts[2].isEmpty() ? 0 : Long.parseLong(parts[2]);
                event.eventType = parts[3].isEmpty() ? 0 : Integer.parseInt(parts[3]);
                event.userName = parts[4];
                event.schedulingClass = parts[5].isEmpty() ? 0 : Integer.parseInt(parts[5]);
                event.jobName = parts[6];
                event.logicalJobName = parts[7];
                sourceContext.collectWithTimestamp(event, event.timestamp);
            }
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }

    @Override
    public TypeInformation<JobEvent> getProducedType() {
        return TypeInformation.of(JobEvent.class);
    }
}