package clusterdata.datatypes;

public class JobEvent {
    public long timestamp;
    public long jobId;
    public int eventType;

    public JobEvent() {}

    public JobEvent(long timestamp, long jobId, int eventType) {
        this.timestamp = timestamp;
        this.jobId = jobId;
        this.eventType = eventType;
    }

    public static JobEvent fromString(String line) {
        String[] parts = line.split(",");
        long timestamp = Long.parseLong(parts[0]);
        long jobId = Long.parseLong(parts[2]);
        int eventType = Integer.parseInt(parts[3]);
        return new JobEvent(timestamp, jobId, eventType);
    }
}