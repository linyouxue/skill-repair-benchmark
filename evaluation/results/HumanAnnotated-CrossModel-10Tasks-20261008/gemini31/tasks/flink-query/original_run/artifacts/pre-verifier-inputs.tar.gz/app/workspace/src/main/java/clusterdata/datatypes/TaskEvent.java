package clusterdata.datatypes;

public class TaskEvent {
    public long timestamp;
    public long jobId;
    public int eventType;

    public TaskEvent() {}

    public TaskEvent(long timestamp, long jobId, int eventType) {
        this.timestamp = timestamp;
        this.jobId = jobId;
        this.eventType = eventType;
    }

    public static TaskEvent fromString(String line) {
        String[] parts = line.split(",");
        long timestamp = Long.parseLong(parts[0]);
        long jobId = Long.parseLong(parts[2]);
        int eventType = Integer.parseInt(parts[5]);
        return new TaskEvent(timestamp, jobId, eventType);
    }
}