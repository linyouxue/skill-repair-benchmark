package clusterdata.datatypes;

public class TaskEvent {
    public long timestamp;
    public String missingInfo;
    public long jobId;
    public int taskIndex;
    public long machineId;
    public int eventType;
    public String userName;
    public int schedulingClass;
    public int priority;
    public double cpuRequest;
    public double ramRequest;
    public double diskRequest;
    public int differentMachineConstraint;

    public TaskEvent() {}
}
