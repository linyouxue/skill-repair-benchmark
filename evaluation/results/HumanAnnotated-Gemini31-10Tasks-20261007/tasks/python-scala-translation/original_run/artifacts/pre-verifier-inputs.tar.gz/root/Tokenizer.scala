import scala.collection.mutable
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime}

// ============================================================================
// Enums and Constants
// ============================================================================

sealed trait TokenType {
  def value: String
}
object TokenType {
  case object STRING extends TokenType { val value = "string" }
  case object NUMERIC extends TokenType { val value = "numeric" }
  case object TEMPORAL extends TokenType { val value = "temporal" }
  case object STRUCTURED extends TokenType { val value = "structured" }
  case object BINARY extends TokenType { val value = "binary" }
  case object NULL extends TokenType { val value = "null" }
}

// ============================================================================
// Protocol definitions
// ============================================================================

trait Tokenizable {
  def toToken(): String
}

trait HasLength {
  def length: Int
}

trait TokenProcessor[-T] {
  def process(item: T): Unit
}

// ============================================================================
// Core Token Classes
// ============================================================================

case class Token(
  value: String,
  tokenType: TokenType,
  metadata: Map[String, Any] = Map.empty
) {
  def withMetadata(kwargs: (String, Any)*): Token = {
    copy(metadata = metadata ++ kwargs.toMap)
  }
}

class MutableTokenBatch(
  val tokens: mutable.ListBuffer[Token] = mutable.ListBuffer.empty
) {
  private var _processed: Boolean = false

  def add(token: Token): Unit = {
    if (_processed) throw new RuntimeException("Batch already processed")
    tokens += token
  }

  def markProcessed(): Unit = {
    _processed = true
  }
}

// ============================================================================
// Generic Container Classes
// ============================================================================

class TokenContainer[+T](items: Seq[T]) {
  private val _items: Seq[T] = items

  def getAll(): Seq[T] = _items

  def mapTokens(func: T => String): Seq[String] = {
    _items.map(func)
  }
}

class TokenSink[-T] {
  private var _received: List[Any] = Nil

  def receive(item: T): Unit = {
    _received = item :: _received
  }

  def drain(): List[Any] = {
    val result = _received.reverse
    _received = Nil
    result
  }
}

class BivariantHandler[T](private var _value: T) {
  def get(): T = _value

  def set(value: T): Unit = {
    _value = value
  }

  def transform(func: T => T): T = {
    _value = func(_value)
    _value
  }
}

// ============================================================================
// Tokenizer Implementations
// ============================================================================

trait BaseTokenizer[T] {
  def tokenize(value: T): Token

  def tokenizeBatch(values: Iterable[T]): Iterator[Token] = {
    values.iterator.map(tokenize)
  }
}

// StringTokenizer using Type Class
trait StringOrBytes[T] {
  def asString(value: T, encoding: String): String
}
object StringOrBytes {
  implicit val stringInst: StringOrBytes[String] = (value, _) => value
  implicit val bytesInst: StringOrBytes[Array[Byte]] = (value, encoding) => new String(value, encoding)
}

class StringTokenizer[T: StringOrBytes](
  val encoding: String = "utf-8",
  val normalizer: String => String = identity
) extends BaseTokenizer[T] {
  def tokenize(value: T): Token = {
    val strValue = implicitly[StringOrBytes[T]].asString(value, encoding)
    val normalized = normalizer(strValue)
    Token(normalized, TokenType.STRING)
  }
}

// NumericTokenizer using Type Class
trait NumericValue[T] {
  def asString(value: T, precision: Int): String
  def typeName(value: T): String
}
object NumericValue {
  implicit val intInst: NumericValue[Int] = new NumericValue[Int] {
    def asString(value: Int, p: Int) = value.toString
    def typeName(value: Int) = "int"
  }
  implicit val longInst: NumericValue[Long] = new NumericValue[Long] {
    def asString(value: Long, p: Int) = value.toString
    def typeName(value: Long) = "int"
  }
  implicit val doubleInst: NumericValue[Double] = new NumericValue[Double] {
    def asString(value: Double, p: Int) = s"%.${p}f".formatLocal(java.util.Locale.US, value)
    def typeName(value: Double) = "float"
  }
  implicit val floatInst: NumericValue[Float] = new NumericValue[Float] {
    def asString(value: Float, p: Int) = s"%.${p}f".formatLocal(java.util.Locale.US, value)
    def typeName(value: Float) = "float"
  }
  implicit val bigDecimalInst: NumericValue[BigDecimal] = new NumericValue[BigDecimal] {
    def asString(value: BigDecimal, p: Int) = value.setScale(p, scala.math.BigDecimal.RoundingMode.HALF_UP).toString()
    def typeName(value: BigDecimal) = "Decimal"
  }
}

class NumericTokenizer[T: NumericValue](
  val precision: Int = 6,
  val formatOptions: Map[String, Any] = Map.empty
) extends BaseTokenizer[T] {
  def tokenize(value: T): Token = {
    val nv = implicitly[NumericValue[T]]
    val strValue = nv.asString(value, precision)
    Token(strValue, TokenType.NUMERIC, Map("original_type" -> nv.typeName(value)))
  }
}

// TemporalTokenizer using Type Class
trait TemporalValue[T] {
  def asString(value: T, formatStr: Option[String]): String
}
object TemporalValue {
  implicit val dateTimeInst: TemporalValue[LocalDateTime] = (value, formatStr) => {
    val fmt = formatStr.map(DateTimeFormatter.ofPattern).getOrElse(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
    value.format(fmt)
  }

  implicit val dateInst: TemporalValue[LocalDate] = (value, formatStr) => {
    val fmt = formatStr.map(DateTimeFormatter.ofPattern).getOrElse(DateTimeFormatter.ISO_LOCAL_DATE)
    value.format(fmt)
  }
}

class TemporalTokenizer[T: TemporalValue](
  val formatStr: Option[String] = None
) extends BaseTokenizer[T] {
  def tokenize(value: T): Token = {
    Token(implicitly[TemporalValue[T]].asString(value, formatStr), TokenType.TEMPORAL)
  }
}

// ============================================================================
// Advanced: Union Types and Overloads
// ============================================================================

class UniversalTokenizer {
  private val stringStringTokenizer = new StringTokenizer[String]()
  private val bytesStringTokenizer = new StringTokenizer[Array[Byte]]()
  private val intTokenizer = new NumericTokenizer[Int]()
  private val doubleTokenizer = new NumericTokenizer[Double]()
  private val decimalTokenizer = new NumericTokenizer[BigDecimal]()
  private val dateTimeTokenizer = new TemporalTokenizer[LocalDateTime]()
  private val dateTokenizer = new TemporalTokenizer[LocalDate]()

  def tokenize(value: String): Token = stringStringTokenizer.tokenize(value)
  def tokenize(value: Array[Byte]): Token = bytesStringTokenizer.tokenize(value)
  def tokenize(value: Int): Token = intTokenizer.tokenize(value)
  def tokenize(value: Double): Token = doubleTokenizer.tokenize(value)
  def tokenize(value: BigDecimal): Token = decimalTokenizer.tokenize(value)
  def tokenize(value: LocalDateTime): Token = dateTimeTokenizer.tokenize(value)
  def tokenize(value: LocalDate): Token = dateTokenizer.tokenize(value)
  def tokenize(value: Tokenizable): Token = Token(value.toToken(), TokenType.STRUCTURED)

  def tokenize(value: Any): Token = value match {
    case null => Token("NULL", TokenType.NULL)
    case t: Tokenizable => tokenize(t)
    case s: String => tokenize(s)
    case b: Array[Byte] => tokenize(b)
    case i: Int => tokenize(i)
    case l: Long => intTokenizer.tokenize(l.toInt) // fallback to int tokenizer or use a long one
    case d: Double => tokenize(d)
    case f: Float => doubleTokenizer.tokenize(f.toDouble)
    case bd: BigDecimal => tokenize(bd)
    case ldt: LocalDateTime => tokenize(ldt)
    case ld: LocalDate => tokenize(ld)
    case other => Token(other.toString, TokenType.STRING, Map("fallback" -> true))
  }
}

// ============================================================================
// Complex Nested Generics
// ============================================================================

class TokenRegistry[T] {
  private val _registry = mutable.Map.empty[String, TokenContainer[T]]
  private val _handlers = mutable.ListBuffer.empty[T => Option[Token]]

  def register(key: String, container: TokenContainer[T]): Unit = {
    _registry(key) = container
  }

  def addHandler(handler: T => Option[Token]): Unit = {
    _handlers += handler
  }

  def process(key: String): List[Option[Token]] = {
    _registry.get(key) match {
      case None => Nil
      case Some(container) =>
        container.getAll().map { item =>
          _handlers.iterator.map(h => h(item)).find(_.isDefined).flatten
        }.toList
    }
  }
}

// ============================================================================
// Higher-Kinded Type Simulation
// ============================================================================

class TokenFunctor[T](protected val _value: T) {
  def map[U](func: T => U): TokenFunctor[U] = {
    new TokenFunctor(func(_value))
  }

  def flatMap[U](func: T => TokenFunctor[U]): TokenFunctor[U] = {
    func(_value)
  }

  def getOrElse(default: T): T = {
    if (_value != null) _value else default
  }
}

class TokenMonad[T](value: T) extends TokenFunctor[T](value) {
  def ap[U](funcWrapped: TokenMonad[T => U]): TokenMonad[U] = {
    new TokenMonad(funcWrapped._value(this._value))
  }
}

object TokenMonad {
  def pure[T](value: T): TokenMonad[T] = new TokenMonad(value)
}

// ============================================================================
// JSON Structure Tokenization
// ============================================================================

sealed trait JsonValue
case class JsonString(value: String) extends JsonValue
case class JsonNumber(value: Double) extends JsonValue
case class JsonBoolean(value: Boolean) extends JsonValue
case object JsonNull extends JsonValue
case class JsonArray(values: Seq[JsonValue]) extends JsonValue
case class JsonObject(values: Map[String, JsonValue]) extends JsonValue

class JsonTokenizer(val pretty: Boolean = false) {
  private def toJsonString(value: JsonValue, indentLevel: Int = 0): String = {
    val indent = if (pretty) "  " * indentLevel else ""
    val innerIndent = if (pretty) "  " * (indentLevel + 1) else ""
    val nl = if (pretty) "\n" else ""
    val space = if (pretty) " " else ""

    value match {
      case JsonString(s) => s""""${s.replace("\"", "\\\"")}""""
      case JsonNumber(n) => if (n.isWhole) n.toLong.toString else n.toString
      case JsonBoolean(b) => b.toString
      case JsonNull => "null"
      case JsonArray(arr) =>
        if (arr.isEmpty) "[]"
        else {
          val items = arr.map(toJsonString(_, indentLevel + 1)).mkString(s",$nl$innerIndent")
          s"[$nl$innerIndent$items$nl$indent]"
        }
      case JsonObject(obj) =>
        if (obj.isEmpty) "{}"
        else {
          val items = obj.map { case (k, v) =>
            s""""${k.replace("\"", "\\\"")}":$space${toJsonString(v, indentLevel + 1)}"""
          }.mkString(s",$nl$innerIndent")
          s"{$nl$innerIndent$items$nl$indent}"
        }
    }
  }

  def tokenize(value: JsonValue): Token = {
    Token(toJsonString(value), TokenType.STRUCTURED, Map("json" -> true))
  }

  def tokenizePath(value: JsonValue, path: String): Option[Token] = {
    val parts = path.split('.')
    var current: Option[JsonValue] = Some(value)

    for (part <- parts) {
      current match {
        case Some(JsonObject(obj)) if obj.contains(part) =>
          current = Some(obj(part))
        case Some(JsonArray(arr)) if part.forall(_.isDigit) =>
          val idx = part.toInt
          if (idx >= 0 && idx < arr.length) {
            current = Some(arr(idx))
          } else {
            current = None
          }
        case _ =>
          current = None
      }
    }

    current.map(tokenize)
  }
}

// ============================================================================
// Whitespace Tokenizer - Basic Text Tokenization
// ============================================================================

class WhitespaceTokenizer(
  val lowercase: Boolean = false,
  val minLength: Int = 0,
  val maxLength: Option[Int] = None,
  val stripPunctuation: Boolean = false
) {
  private val punctuation = Set('.', ',', '!', '?', ';', ':', '\'', '"', '(', ')', '[', ']', '{', '}')

  private def processToken(word: String): Option[String] = {
    var processed = word
    
    if (stripPunctuation) {
      processed = processed.dropWhile(punctuation.contains).reverse.dropWhile(punctuation.contains).reverse
    }

    if (lowercase) {
      processed = processed.toLowerCase
    }

    if (processed.length < minLength) {
      return None
    }

    maxLength match {
      case Some(max) if processed.length > max => processed = processed.substring(0, max)
      case _ =>
    }

    if (processed.isEmpty) None else Some(processed)
  }

  def tokenize(text: String): List[Token] = {
    val words = text.split("\\s+")
    words.zipWithIndex.flatMap { case (word, i) =>
      processToken(word).map { processed =>
        Token(processed, TokenType.STRING, Map("position" -> i, "original" -> word))
      }
    }.toList
  }

  def tokenizeToStrings(text: String): List[String] = {
    tokenize(text).map(_.value)
  }

  def tokenizeWithPositions(text: String): List[(String, Int, Int)] = {
    val words = text.split("\\s+")
    var currentPos = 0
    val result = mutable.ListBuffer.empty[(String, Int, Int)]

    for (word <- words if word.nonEmpty) {
      val start = text.indexOf(word, currentPos)
      if (start != -1) { 
        val end = start + word.length
        
        processToken(word).foreach { processed =>
          result += ((processed, start, end))
        }
        
        currentPos = end
      }
    }

    result.toList
  }

  def countTokens(text: String): Int = tokenize(text).length
}

// ============================================================================
// Builder Pattern with Fluent Interface
// ============================================================================

class TokenizerBuilder[T] {
  private val _normalizers = mutable.ListBuffer.empty[String => String]
  private val _validators = mutable.ListBuffer.empty[T => Boolean]
  private var _metadata = Map.empty[String, Any]

  def withNormalizer(normalizer: String => String): TokenizerBuilder[T] = {
    _normalizers += normalizer
    this
  }

  def withValidator(validator: T => Boolean): TokenizerBuilder[T] = {
    _validators += validator
    this
  }

  def withMetadata(kwargs: (String, Any)*): TokenizerBuilder[T] = {
    _metadata = _metadata ++ kwargs
    this
  }

  def build(): T => Token = {
    val normalizers = _normalizers.toList
    val validators = _validators.toList
    val metadata = _metadata

    (value: T) => {
      for (validator <- validators) {
        if (!validator(value)) {
          throw new IllegalArgumentException(s"Validation failed for $value")
        }
      }

      var strValue = value.toString
      for (normalizer <- normalizers) {
        strValue = normalizer(strValue)
      }

      Token(strValue, TokenType.STRING, metadata)
    }
  }
}
