package clusterdata.query;

import clusterdata.datatypes.JobEvent;
import clusterdata.datatypes.TaskEvent;
import clusterdata.utils.AppBase;
import clusterdata.utils.JobEventParser;
import clusterdata.utils.TaskEventParser;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.KeyedCoProcessFunction;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.api.windowing.assigners.EventTimeSessionWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import java.time.Duration;

public class LongestSessionPerJob extends AppBase {

    public static void main(String[] args) throws Exception {

        ParameterTool params = ParameterTool.fromArgs(args);
        String taskInput = params.get("task_input", null);
        String jobInput = params.get("job_input", null);
        String outputPath = params.get("output", null);
        System.out.println("task_input  " + taskInput);
        System.out.println("job_input  " + jobInput);
        final int sesssize = params.getInt("sesssize", 600); // in seconds = 10 mins

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DataStream<TaskEvent> taskEvents;
        if (AppBase.taskEvents == null) {
            taskEvents = env.readTextFile(taskInput)
                    .flatMap(new TaskEventParser());
        } else {
            taskEvents = env.addSource(AppBase.taskSourceOrTest(null));
        }

        DataStream<JobEvent> jobEvents;
        if (AppBase.jobEvents == null) {
            jobEvents = env.readTextFile(jobInput)
                    .flatMap(new JobEventParser());
        } else {
            jobEvents = env.addSource(AppBase.jobSourceOrTest(null));
        }

        SingleOutputStreamOperator<Tuple2<Long, Integer>> sessionCounts = taskEvents
                .filter(t -> t.eventType == 0) // SUBMIT
                .assignTimestampsAndWatermarks(WatermarkStrategy.<TaskEvent>forBoundedOutOfOrderness(Duration.ofSeconds(60))
                        .withTimestampAssigner((e, t) -> e.timestamp / 1000)) // to milliseconds
                .map(t -> new Tuple2<>(t.jobId, 1))
                .returns(Types.TUPLE(Types.LONG, Types.INT))
                .keyBy(t -> t.f0)
                .window(EventTimeSessionWindows.withGap(Time.seconds(sesssize)))
                .sum(1);

        DataStream<JobEvent> terminalJobs = jobEvents
                .filter(j -> j.eventType >= 3 && j.eventType <= 6)
                .assignTimestampsAndWatermarks(WatermarkStrategy.<JobEvent>forBoundedOutOfOrderness(Duration.ofSeconds(60))
                        .withTimestampAssigner((e, t) -> e.timestamp / 1000));

        SingleOutputStreamOperator<Tuple2<Long, Integer>> result = sessionCounts.connect(terminalJobs)
                .keyBy(t -> t.f0, j -> j.jobId)
                .process(new KeyedCoProcessFunction<Long, Tuple2<Long, Integer>, JobEvent, Tuple2<Long, Integer>>() {
                    private ValueState<Integer> maxCount;
                    private ValueState<Boolean> jobFinished;
                    private ValueState<Boolean> emitted;

                    @Override
                    public void open(Configuration parameters) {
                        maxCount = getRuntimeContext().getState(new ValueStateDescriptor<>("maxCount", Integer.class));
                        jobFinished = getRuntimeContext().getState(new ValueStateDescriptor<>("jobFinished", Boolean.class));
                        emitted = getRuntimeContext().getState(new ValueStateDescriptor<>("emitted", Boolean.class));
                    }

                    @Override
                    public void processElement1(Tuple2<Long, Integer> value, Context ctx, Collector<Tuple2<Long, Integer>> out) throws Exception {
                        Integer currentMax = maxCount.value();
                        if (currentMax == null) currentMax = 0;
                        if (value.f1 > currentMax) {
                            maxCount.update(value.f1);
                        }
                    }

                    @Override
                    public void processElement2(JobEvent value, Context ctx, Collector<Tuple2<Long, Integer>> out) throws Exception {
                        jobFinished.update(true);
                        // register a timer to output after all sessions should have ended
                        ctx.timerService().registerEventTimeTimer(value.timestamp / 1000 + sesssize * 1000L);
                    }

                    @Override
                    public void onTimer(long timestamp, OnTimerContext ctx, Collector<Tuple2<Long, Integer>> out) throws Exception {
                        if (emitted.value() != null && emitted.value()) {
                            return;
                        }
                        if (jobFinished.value() != null && jobFinished.value()) {
                            Integer mc = maxCount.value();
                            if (mc == null) mc = 0;
                            out.collect(new Tuple2<>(ctx.getCurrentKey(), mc));
                            emitted.update(true);
                            maxCount.clear();
                            jobFinished.clear();
                        }
                    }
                });

        DataStream<String> resultStr = result.map(t -> "(" + t.f0 + "," + t.f1 + ")");

        if (AppBase.out == null) {
            resultStr.writeAsText(outputPath, FileSystem.WriteMode.OVERWRITE).setParallelism(1);
        } else {
            resultStr.addSink((SinkFunction<String>) AppBase.sinkOrTest(null));
        }

        env.execute("LongestSessionPerJob");
    }
}
