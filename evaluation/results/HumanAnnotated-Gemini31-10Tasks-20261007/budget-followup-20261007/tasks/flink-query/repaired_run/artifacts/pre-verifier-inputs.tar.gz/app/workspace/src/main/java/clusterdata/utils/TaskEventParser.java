package clusterdata.utils;

import clusterdata.datatypes.TaskEvent;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.util.Collector;

public class TaskEventParser implements FlatMapFunction<String, TaskEvent> {
    @Override
    public void flatMap(String line, Collector<TaskEvent> out) {
        try {
            String[] parts = line.split(",", -1);
            if (parts.length >= 13) {
                TaskEvent event = new TaskEvent();
                event.timestamp = Long.parseLong(parts[0]);
                event.missingInfo = parts[1];
                event.jobId = Long.parseLong(parts[2]);
                event.taskIndex = parts[3].isEmpty() ? -1 : Integer.parseInt(parts[3]);
                event.machineId = parts[4];
                event.eventType = parts[5].isEmpty() ? -1 : Integer.parseInt(parts[5]);
                event.userName = parts[6];
                event.schedulingClass = parts[7].isEmpty() ? -1 : Integer.parseInt(parts[7]);
                event.priority = parts[8].isEmpty() ? -1 : Integer.parseInt(parts[8]);
                event.cpuReq = parts[9].isEmpty() ? 0.0 : Double.parseDouble(parts[9]);
                event.ramReq = parts[10].isEmpty() ? 0.0 : Double.parseDouble(parts[10]);
                event.diskReq = parts[11].isEmpty() ? 0.0 : Double.parseDouble(parts[11]);
                event.diffMachineConstraint = parts[12].isEmpty() ? 0 : Integer.parseInt(parts[12]);
                out.collect(event);
            }
        } catch (Exception e) {
            // ignore malformed lines
        }
    }
}
