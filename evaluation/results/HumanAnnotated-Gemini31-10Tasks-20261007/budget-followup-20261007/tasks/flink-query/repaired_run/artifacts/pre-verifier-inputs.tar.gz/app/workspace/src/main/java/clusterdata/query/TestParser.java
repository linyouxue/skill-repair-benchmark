package clusterdata.query;
import clusterdata.utils.TaskEventParser;
import clusterdata.utils.JobEventParser;
import clusterdata.datatypes.TaskEvent;
import clusterdata.datatypes.JobEvent;
import org.apache.flink.util.Collector;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.zip.GZIPInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class TestParser {
    public static void main(String[] args) throws Exception {
        TaskEventParser tp = new TaskEventParser();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream("/app/workspace/data/task_events/part-00001-of-00500.csv.gz"))))) {
            String line;
            int count = 0;
            while ((line = br.readLine()) != null && count < 10) {
                tp.flatMap(line, new Collector<TaskEvent>() {
                    @Override public void collect(TaskEvent e) { System.out.println("Task: " + e.jobId + ", eventType: " + e.eventType); }
                    @Override public void close() {}
                });
                count++;
            }
        }
        JobEventParser jp = new JobEventParser();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream("/app/workspace/data/job_events/part-00001-of-00500.csv.gz"))))) {
            String line;
            int count = 0;
            while ((line = br.readLine()) != null && count < 10) {
                jp.flatMap(line, new Collector<JobEvent>() {
                    @Override public void collect(JobEvent e) { System.out.println("Job: " + e.jobId + ", eventType: " + e.eventType); }
                    @Override public void close() {}
                });
                count++;
            }
        }
    }
}
