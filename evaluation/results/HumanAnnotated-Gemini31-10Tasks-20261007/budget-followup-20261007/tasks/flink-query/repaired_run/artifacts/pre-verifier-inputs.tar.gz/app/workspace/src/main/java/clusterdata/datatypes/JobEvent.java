package clusterdata.datatypes;

public class JobEvent {
    public long timestamp;
    public String missingInfo;
    public long jobId;
    public int eventType;
    public String userName;
    public int schedulingClass;
    public String jobName;
    public String logicalJobName;

    public JobEvent() {}
}
