package clusterdata.datatypes;

public class TaskEvent {
    public long timestamp;
    public String missingInfo;
    public long jobId;
    public int taskIndex;
    public String machineId;
    public int eventType;
    public String userName;
    public int schedulingClass;
    public int priority;
    public double cpuReq;
    public double ramReq;
    public double diskReq;
    public int diffMachineConstraint;

    public TaskEvent() {}
}
