package clusterdata.utils;

import clusterdata.datatypes.JobEvent;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.util.Collector;

public class JobEventParser implements FlatMapFunction<String, JobEvent> {
    @Override
    public void flatMap(String line, Collector<JobEvent> out) {
        try {
            String[] parts = line.split(",", -1);
            if (parts.length >= 8) {
                JobEvent event = new JobEvent();
                event.timestamp = Long.parseLong(parts[0]);
                event.missingInfo = parts[1];
                event.jobId = Long.parseLong(parts[2]);
                event.eventType = parts[3].isEmpty() ? -1 : Integer.parseInt(parts[3]);
                event.userName = parts[4];
                event.schedulingClass = parts[5].isEmpty() ? -1 : Integer.parseInt(parts[5]);
                event.jobName = parts[6];
                event.logicalJobName = parts[7];
                out.collect(event);
            }
        } catch (Exception e) {
            // ignore malformed lines
        }
    }
}
