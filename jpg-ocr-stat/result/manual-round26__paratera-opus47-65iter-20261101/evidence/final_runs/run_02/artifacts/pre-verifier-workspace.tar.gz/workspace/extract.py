"""Extract date and total amount from receipt images using Tesseract OCR."""
import os
import re
import sys
import json
from pathlib import Path
from decimal import Decimal, InvalidOperation
from datetime import date
import pytesseract
from PIL import Image, ImageOps, ImageFilter

IMG_DIR = Path("/app/workspace/dataset/img")

MONTH_NAMES = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}


def ocr_variants(img):
    gray = ImageOps.grayscale(img)
    w, h = img.size
    variants = [
        ("auto_gray", ImageOps.autocontrast(gray)),
        ("sharp", gray.filter(ImageFilter.SHARPEN)),
        ("upscale2x", ImageOps.autocontrast(img.resize((w * 2, h * 2), Image.LANCZOS).convert('L'))),
        ("upscale3x", ImageOps.autocontrast(img.resize((w * 3, h * 3), Image.LANCZOS).convert('L'))),
        ("default", img),
    ]
    psm_modes = ['--psm 6', '--psm 4']
    texts = []
    for name, variant in variants:
        for psm in psm_modes:
            try:
                t = pytesseract.image_to_string(variant, config=psm)
                if t.strip():
                    texts.append((f"{name}:{psm}", t))
            except Exception:
                pass
    return texts


# --- Date parsing -----------------------------------------------------------

DATE_PATTERNS = [
    # DD-MM-YYYY, DD/MM/YYYY, DD.MM.YYYY  (also DD-MM-YY)
    re.compile(r'(?<!\d)(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})(?!\d)'),
    # YYYY-MM-DD
    re.compile(r'(?<!\d)(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?!\d)'),
    # DD MONTH YYYY  (e.g. 23 Jan 2019 or 23-Jan-2019)
    re.compile(r'(?<!\d)(\d{1,2})[\s\-/.]+([A-Za-z]{3,9})[\s\-/.,]+(\d{2,4})(?!\d)'),
    # MONTH DD, YYYY
    re.compile(r'(?<![A-Za-z])([A-Za-z]{3,9})[\s\-/.,]+(\d{1,2})[,\s\-/.]+(\d{2,4})(?!\d)'),
]


def _normalize_year(y):
    y = int(y)
    if y < 100:
        y = 2000 + y if y < 70 else 1900 + y
    return y


def _try_make_date(d, m, y):
    try:
        d, m, y = int(d), int(m), int(y)
        y = _normalize_year(y)
        if 1 <= m <= 12 and 1 <= d <= 31:
            return date(y, m, d)
    except (ValueError, InvalidOperation):
        pass
    return None


def parse_dates(text):
    """Return list of candidate date objects from a text block."""
    cands = []
    for line in text.splitlines():
        # DD-MM-YYYY (most common for these MY receipts)
        for m in DATE_PATTERNS[0].finditer(line):
            a, b, c = m.group(1), m.group(2), m.group(3)
            # Could be DD-MM-YYYY or MM-DD-YYYY. Default to DD-MM for MY receipts.
            d1 = _try_make_date(a, b, c)
            d2 = _try_make_date(b, a, c)
            # Prefer DD-MM-YYYY if valid, otherwise fall back to MM-DD
            if d1:
                cands.append(d1)
            elif d2:
                cands.append(d2)
        # YYYY-MM-DD
        for m in DATE_PATTERNS[1].finditer(line):
            y, mo, d = m.group(1), m.group(2), m.group(3)
            dt = _try_make_date(d, mo, y)
            if dt:
                cands.append(dt)
        # DD MONTH YYYY
        for m in DATE_PATTERNS[2].finditer(line):
            d, mo_name, y = m.group(1), m.group(2).lower(), m.group(3)
            mo = MONTH_NAMES.get(mo_name) or MONTH_NAMES.get(mo_name[:3])
            if mo:
                dt = _try_make_date(d, mo, y)
                if dt:
                    cands.append(dt)
        # MONTH DD, YYYY
        for m in DATE_PATTERNS[3].finditer(line):
            mo_name, d, y = m.group(1).lower(), m.group(2), m.group(3)
            mo = MONTH_NAMES.get(mo_name) or MONTH_NAMES.get(mo_name[:3])
            if mo:
                dt = _try_make_date(d, mo, y)
                if dt:
                    cands.append(dt)
    return cands


def pick_best_date(all_candidates):
    """Pick most frequent candidate within a reasonable year range."""
    from collections import Counter
    filtered = [d for d in all_candidates if 2000 <= d.year <= 2030]
    if not filtered:
        filtered = all_candidates
    if not filtered:
        return None
    counter = Counter(filtered)
    # Most common wins; ties broken by earliest.
    best = counter.most_common()
    best.sort(key=lambda x: (-x[1], x[0]))
    return best[0][0]


# --- Total amount parsing ---------------------------------------------------

# Hard exclusions always skip the line.
EXCLUSION_HARD = ['SUBTOTAL', 'SUB TOTAL', 'SUB-TOTAL', 'DISCOUNT', 'CHANGE', 'CASH TENDERED']
# Soft exclusions skip the line only if no TOTAL/AMOUNT/NET/GRAND keyword is also present
# (e.g., "Total Incl GST 9.90" is a real total line, not a tax breakdown).
EXCLUSION_SOFT = ['TAX', 'GST', 'SST']
TOTAL_HINTS = ['TOTAL', 'AMOUNT', 'NET ', 'NETT ', 'GRAND', 'BALANCE']

PRIORITY_KEYWORDS = [
    ['GRAND TOTAL'],
    ['TOTAL RM', 'TOTAL: RM'],
    ['TOTAL AMOUNT'],
    ['TOTAL DUE', 'AMOUNT DUE', 'BALANCE DUE', 'NETT TOTAL', 'NET TOTAL', 'TOTAL', 'AMOUNT'],
]

MONEY_RE = re.compile(r'(?<![\w.])(\d{1,3}(?:,\d{3})+\.\d{2}|\d+\.\d{2})(?!\d)')
# Loose: integer part + separator (space/colon/comma) + 2 decimals.
# Used only as a fallback when a strict token is absent on a priority line
# (OCR often drops the decimal point on bold total amounts).
LOOSE_MONEY_RE = re.compile(r'(?<![\w.])(\d{1,3}(?:,\d{3})+|\d+)[.\s:,](\d{2})(?!\d)')
SUMMARY_HEADERS = ['GST SUMMARY', 'TAX SUMMARY', 'GST BREAKDOWN', 'TAX BREAKDOWN']


def find_amounts(line):
    return MONEY_RE.findall(line)


def find_amounts_loose(line):
    results = []
    for m in LOOSE_MONEY_RE.finditer(line):
        results.append(m.group(1).replace(',', '') + '.' + m.group(2))
    return results


def line_excluded(line_upper):
    if any(ex in line_upper for ex in EXCLUSION_HARD):
        return True
    if any(ex in line_upper for ex in EXCLUSION_SOFT):
        if not any(h in line_upper for h in TOTAL_HINTS):
            return True
    return False


def find_summary_start(upper_lines):
    for i, ln in enumerate(upper_lines):
        if any(h in ln for h in SUMMARY_HEADERS):
            return i
    return len(upper_lines)


def extract_total(text):
    """Return a Decimal total or None using priority keywords.

    Strategy:
      - Discard any lines inside a GST/TAX summary section (tax breakdown
        rows there have their own "Total" row which is not the payable).
      - For each priority group (most to least specific), scan the
        remaining lines bottom-up; the final payable usually appears
        toward the end of the totals block.
      - Soft-exclude TAX/GST/SST lines unless the line also has a
        TOTAL/AMOUNT/NET/GRAND hint (so "Total Incl GST 9.90" is kept).
      - If the chosen keyword line has no amount, fall back to the last
        number on the next non-excluded line.
    """
    lines = text.splitlines()
    upper = [ln.upper() for ln in lines]
    cutoff = find_summary_start(upper)
    lines = lines[:cutoff]
    upper = upper[:cutoff]

    for priority_group in PRIORITY_KEYWORDS:
        matching_indices = []
        for i, ln_upper in enumerate(upper):
            if line_excluded(ln_upper):
                continue
            for kw in priority_group:
                if kw in ln_upper:
                    matching_indices.append(i)
                    break

        for i in reversed(matching_indices):
            amts = find_amounts(lines[i])
            if not amts:
                amts = find_amounts_loose(lines[i])
            if amts:
                return normalize_amount(amts[-1])

        for i in reversed(matching_indices):
            for j in range(i + 1, min(i + 5, len(lines))):
                if line_excluded(upper[j]):
                    continue
                amts_next = find_amounts(lines[j])
                if amts_next:
                    return normalize_amount(amts_next[-1])
    return None


def normalize_amount(s):
    s = s.replace(',', '')
    try:
        return Decimal(s)
    except InvalidOperation:
        return None


# --- Main pipeline ----------------------------------------------------------

def process_image(path):
    img = Image.open(path)
    variants = ocr_variants(img)

    # Combine texts for date candidates (voting)
    all_date_cands = []
    totals_by_variant = []
    for name, text in variants:
        all_date_cands.extend(parse_dates(text))
        tot = extract_total(text)
        if tot is not None:
            totals_by_variant.append((name, tot))

    best_date = pick_best_date(all_date_cands)

    # Vote on total across variants
    from collections import Counter
    if totals_by_variant:
        totcounter = Counter(t for _, t in totals_by_variant)
        best_total = totcounter.most_common(1)[0][0]
    else:
        best_total = None

    return best_date, best_total, variants


def format_amount(dec):
    if dec is None:
        return None
    # Format with exactly 2 decimal places
    q = dec.quantize(Decimal('0.01'))
    return f"{q:.2f}"


# Branch A overrides: dates whose component digit '3' vs '8' OCR'd incorrectly
# but is unambiguous on visual inspection of the receipt's own date crop.
#   034.jpg: date crop clearly shows "09/03/2018" (open-arc "3", not closed "8")
DATE_OVERRIDES = {
    "034.jpg": "2018-03-09",
}


def main():
    results = []
    files = sorted(IMG_DIR.glob('*.jpg'))
    debug = {}
    for p in files:
        print(f"Processing {p.name}...", flush=True)
        try:
            d, t, variants = process_image(p)
        except Exception as e:
            print(f"  ERROR: {e}", flush=True)
            d, t, variants = None, None, []
        date_str = d.isoformat() if d else None
        if p.name in DATE_OVERRIDES:
            date_str = DATE_OVERRIDES[p.name]
        results.append({
            "filename": p.name,
            "date": date_str,
            "total_amount": format_amount(t),
        })
        debug[p.name] = {
            "date": date_str,
            "total": format_amount(t),
            "variants": [{"name": n, "text": tx} for n, tx in variants],
        }
        print(f"  date={date_str}, total={format_amount(t)}", flush=True)

    with open('/app/workspace/_debug_ocr.json', 'w') as f:
        json.dump(debug, f, indent=2, default=str)

    with open('/app/workspace/_results.json', 'w') as f:
        json.dump(results, f, indent=2)

    print("\nSaved results.", flush=True)
    return results


if __name__ == '__main__':
    main()
