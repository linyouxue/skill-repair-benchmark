"""Build the final results XLSX from extraction results."""
import json
from openpyxl import Workbook

with open('/app/workspace/_results.json') as f:
    results = json.load(f)

results.sort(key=lambda r: r['filename'])

wb = Workbook()
# Remove default sheet, create "results" sheet.
wb.remove(wb.active)
ws = wb.create_sheet('results')
ws.append(['filename', 'date', 'total_amount'])
for r in results:
    ws.append([r['filename'], r['date'], r['total_amount']])

wb.save('/app/workspace/stat_ocr.xlsx')
print(f"Wrote {len(results)} rows to stat_ocr.xlsx")

# Verify
from openpyxl import load_workbook
wb2 = load_workbook('/app/workspace/stat_ocr.xlsx')
print("Sheet names:", wb2.sheetnames)
ws2 = wb2['results']
for row in ws2.iter_rows(values_only=True):
    print(row)
