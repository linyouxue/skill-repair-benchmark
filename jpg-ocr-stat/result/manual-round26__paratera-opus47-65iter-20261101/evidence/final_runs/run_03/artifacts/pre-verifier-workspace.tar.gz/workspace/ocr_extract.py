"""OCR receipts and extract date + total amount into stat_ocr.xlsx."""
import os
import re
from pathlib import Path
from decimal import Decimal, InvalidOperation
from datetime import datetime

import pytesseract
from PIL import Image, ImageOps, ImageFilter
from openpyxl import Workbook

IMG_DIR = Path("/app/workspace/dataset/img")
OUT_XLSX = Path("/app/workspace/stat_ocr.xlsx")

EXCLUSION_KWS = (
    "SUBTOTAL",
    "SUB TOTAL",
    "TAX",
    "GST",
    "SST",
    "DISCOUNT",
    "CHANGE",
    "CASH TENDERED",
)

# Priority: lower = more specific/preferred.
PRIORITY_KEYWORDS = [
    (0, ["GRAND TOTAL"]),
    (1, ["TOTAL RM", "TOTAL: RM"]),
    (2, ["TOTAL AMOUNT"]),
    (3, ["TOTAL DUE", "AMOUNT DUE", "BALANCE DUE", "NETT TOTAL", "NET TOTAL"]),
    (4, ["TOTAL", "AMOUNT"]),
]

MONEY_RE = re.compile(r"(?<![\d.])(\d{1,3}(?:,\d{3})+\.\d{2}|\d+\.\d{2})(?!\d)")


def preprocess_variants(img):
    """Yield (name, PIL image) preprocessing variants for OCR."""
    gray = img.convert("L")
    w, h = img.size
    yield "orig", img
    yield "gray_ac", ImageOps.autocontrast(gray)
    big = img.resize((w * 2, h * 2), Image.LANCZOS).convert("L")
    yield "2x_ac", ImageOps.autocontrast(big)
    yield "2x_sharp", ImageOps.autocontrast(big).filter(ImageFilter.SHARPEN)


def ocr_text(img):
    """Multi-pass OCR, returning the longest / richest text."""
    texts = []
    for _, v in preprocess_variants(img):
        for psm in ("--psm 6", "--psm 4", "--psm 11"):
            try:
                t = pytesseract.image_to_string(v, config=psm)
            except Exception:
                t = ""
            if t.strip():
                texts.append(t)
    # Also return concatenation; downstream logic uses per-line scanning.
    return texts


def parse_money(tok):
    """Return Decimal if token looks like money, else None."""
    tok = tok.replace(",", "")
    try:
        d = Decimal(tok)
    except InvalidOperation:
        return None
    return d


def find_amount_from_lines(lines):
    """Walk lines of text and pick best amount by priority ranking."""
    best = None  # (priority, line_index, Decimal, raw_token)
    n = len(lines)
    for i, raw in enumerate(lines):
        line = raw.strip()
        if not line:
            continue
        up = line.upper()
        if any(kw in up for kw in EXCLUSION_KWS):
            continue
        # Match the most specific keyword present in this line.
        pri_hit = None
        for pri, kws in PRIORITY_KEYWORDS:
            if any(kw in up for kw in kws):
                pri_hit = pri
                break
        if pri_hit is None:
            continue
        tokens = MONEY_RE.findall(line)
        amount = None
        if tokens:
            amount = parse_money(tokens[-1])
        else:
            # Fallback: next non-empty line's last number.
            for j in range(i + 1, min(i + 3, n)):
                nxt = lines[j].strip()
                if not nxt:
                    continue
                t2 = MONEY_RE.findall(nxt)
                if t2:
                    amount = parse_money(t2[-1])
                    break
                # Also try bare integers on the next line (fallback case).
                m_int = re.findall(r"(?<![\d.])(\d+)(?!\d)", nxt)
                if m_int:
                    amount = parse_money(m_int[-1])
                    break
                break
        if amount is None:
            continue
        cand = (pri_hit, i, amount, line)
        if best is None or cand[0] < best[0] or (cand[0] == best[0] and cand[1] > best[1]):
            # Prefer more specific keyword; on tie, prefer later line (later total).
            best = cand
    return best


def extract_amount(texts):
    """Try each OCR variant text, aggregate candidates by priority."""
    best = None
    for text in texts:
        lines = text.splitlines()
        cand = find_amount_from_lines(lines)
        if cand is None:
            continue
        if best is None or cand[0] < best[0]:
            best = cand
    if best is None:
        return None
    return best[2]


# ----- date extraction -----

DATE_PATTERNS = [
    # d-m-y or d/m/y with 4-digit year  e.g. 23-01-2019, 23/01/2019
    (re.compile(r"\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b"), "dmy"),
    # y-m-d  e.g. 2019-01-23, 2019/01/23
    (re.compile(r"\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b"), "ymd"),
    # d-m-y with 2-digit year
    (re.compile(r"\b(\d{1,2})[-/](\d{1,2})[-/](\d{2})\b"), "dmy2"),
    # dd Mon yyyy  e.g. 23 Jan 2019 or 23-JAN-2019
    (re.compile(r"\b(\d{1,2})[-\s/]([A-Za-z]{3,9})[-\s/](\d{2,4})\b"), "dMy"),
    # Mon dd, yyyy
    (re.compile(r"\b([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{2,4})\b"), "Mdy"),
]

MONTH_MAP = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "SEPT": 9, "OCT": 10, "NOV": 11, "DEC": 12,
    "JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4, "JUNE": 6,
    "JULY": 7, "AUGUST": 8, "SEPTEMBER": 9, "OCTOBER": 10, "NOVEMBER": 11, "DECEMBER": 12,
}


def try_build_date(y, m, d):
    try:
        y = int(y)
        m = int(m)
        d = int(d)
    except (TypeError, ValueError):
        return None
    if y < 100:
        y += 2000 if y < 70 else 1900
    if not (1 <= m <= 12 and 1 <= d <= 31 and 1990 <= y <= 2099):
        return None
    try:
        return datetime(y, m, d).strftime("%Y-%m-%d")
    except ValueError:
        return None


def extract_date(texts):
    """Return ISO date string or None."""
    candidates = []  # (score, iso, original_text)
    for text in texts:
        for pattern, kind in DATE_PATTERNS:
            for m in pattern.finditer(text):
                groups = m.groups()
                iso = None
                score = 0
                if kind == "dmy":
                    iso = try_build_date(groups[2], groups[1], groups[0])
                    score = 3
                elif kind == "ymd":
                    iso = try_build_date(groups[0], groups[1], groups[2])
                    score = 3
                elif kind == "dmy2":
                    iso = try_build_date(groups[2], groups[1], groups[0])
                    score = 1
                elif kind == "dMy":
                    mon = MONTH_MAP.get(groups[1].upper())
                    if mon:
                        iso = try_build_date(groups[2], mon, groups[0])
                        score = 3
                elif kind == "Mdy":
                    mon = MONTH_MAP.get(groups[0].upper())
                    if mon:
                        iso = try_build_date(groups[2], mon, groups[1])
                        score = 3
                if iso:
                    candidates.append((score, iso))
    if not candidates:
        return None
    # Pick highest score; break ties by most frequent.
    from collections import Counter
    best_score = max(s for s, _ in candidates)
    pool = [iso for s, iso in candidates if s == best_score]
    counter = Counter(pool)
    return counter.most_common(1)[0][0]


def process_image(path):
    img = Image.open(path)
    texts = ocr_text(img)
    date_iso = extract_date(texts)
    amount = extract_amount(texts)
    amount_str = None
    if amount is not None:
        q = amount.quantize(Decimal("0.01"))
        amount_str = f"{q:.2f}"
    return date_iso, amount_str, texts


def main():
    rows = []
    for fname in sorted(os.listdir(IMG_DIR)):
        path = IMG_DIR / fname
        try:
            date_iso, amount_str, _ = process_image(path)
        except Exception as e:
            print(f"[{fname}] ERROR: {e}")
            date_iso, amount_str = None, None
        print(f"{fname}: date={date_iso} total={amount_str}")
        rows.append((fname, date_iso, amount_str))

    wb = Workbook()
    ws = wb.active
    ws.title = "results"
    ws.append(["filename", "date", "total_amount"])
    for r in rows:
        ws.append(list(r))
    wb.save(OUT_XLSX)
    print(f"\nWrote {OUT_XLSX}")


if __name__ == "__main__":
    main()
