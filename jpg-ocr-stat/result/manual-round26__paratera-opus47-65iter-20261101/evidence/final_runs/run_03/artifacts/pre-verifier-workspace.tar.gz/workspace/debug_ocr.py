"""Dump OCR text for specific receipts, for debugging."""
import sys
from PIL import Image, ImageOps
import pytesseract

for fname in sys.argv[1:]:
    path = f"/app/workspace/dataset/img/{fname}"
    img = Image.open(path)
    gray = ImageOps.autocontrast(img.convert("L"))
    w, h = gray.size
    big = ImageOps.autocontrast(img.resize((w * 2, h * 2), Image.LANCZOS).convert("L"))
    for name, variant in [("gray_ac", gray), ("2x_ac", big)]:
        for psm in ("--psm 6", "--psm 4"):
            print(f"=== {fname} {name} {psm} ===")
            print(pytesseract.image_to_string(variant, config=psm))
            print()
