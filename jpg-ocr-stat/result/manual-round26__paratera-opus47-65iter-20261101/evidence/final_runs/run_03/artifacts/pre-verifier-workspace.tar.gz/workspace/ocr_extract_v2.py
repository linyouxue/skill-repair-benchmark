"""OCR receipts and extract date + total amount into stat_ocr.xlsx."""
import os
import re
from collections import Counter
from pathlib import Path
from decimal import Decimal, InvalidOperation
from datetime import datetime

import pytesseract
from PIL import Image, ImageOps, ImageFilter
from openpyxl import Workbook

IMG_DIR = Path("/app/workspace/dataset/img")
OUT_XLSX = Path("/app/workspace/stat_ocr.xlsx")

EXCLUSION_KWS = (
    "SUBTOTAL",
    "SUB TOTAL",
    "TAX",
    "GST",
    "SST",
    "DISCOUNT",
    "CHANGE",
    "CASH TENDERED",
)

PRIORITY_KEYWORDS = [
    (0, ["GRAND TOTAL"]),
    (1, ["TOTAL RM", "TOTAL: RM"]),
    (2, ["TOTAL AMOUNT"]),
    (3, ["TOTAL DUE", "AMOUNT DUE", "BALANCE DUE", "NETT TOTAL", "NET TOTAL"]),
    (4, ["TOTAL", "AMOUNT"]),
]

# Standard money: 123.45 or 1,234.56.
MONEY_RE = re.compile(r"(?<![\d.])(\d{1,3}(?:,\d{3})+\.\d{2}|\d+\.\d{2})(?!\d)")


def preprocess_variants(img):
    gray = img.convert("L")
    w, h = img.size
    big2 = img.resize((w * 2, h * 2), Image.LANCZOS).convert("L")
    big3 = img.resize((w * 3, h * 3), Image.LANCZOS).convert("L")
    yield img
    yield ImageOps.autocontrast(gray)
    yield ImageOps.autocontrast(big2)
    yield ImageOps.autocontrast(big2).filter(ImageFilter.SHARPEN)
    # Threshold variants help separate thin strokes (e.g., open "3" from "8").
    yield big3.point(lambda p: 255 if p > 160 else 0)
    yield big2.point(lambda p: 255 if p > 180 else 0)


def ocr_texts(img):
    texts = []
    for v in preprocess_variants(img):
        for psm in ("--psm 6", "--psm 4"):
            try:
                t = pytesseract.image_to_string(v, config=psm)
            except Exception:
                t = ""
            if t.strip():
                texts.append(t)
    return texts


def parse_money(tok):
    try:
        return Decimal(tok.replace(",", ""))
    except InvalidOperation:
        return None


def find_candidates_in_text(text):
    """Return list of (priority, is_fallback, num_tokens, line_idx, Decimal) candidates."""
    lines = text.splitlines()
    candidates = []
    for i, raw in enumerate(lines):
        line = raw.strip()
        if not line:
            continue
        up = line.upper()
        if any(kw in up for kw in EXCLUSION_KWS):
            continue
        pri_hit = None
        for pri, kws in PRIORITY_KEYWORDS:
            if any(kw in up for kw in kws):
                pri_hit = pri
                break
        if pri_hit is None:
            continue
        tokens = MONEY_RE.findall(line)
        if tokens:
            amt = parse_money(tokens[-1])
            if amt is not None:
                # Direct hit: num_tokens matters for tiebreak (prefer 1-token lines).
                candidates.append((pri_hit, 0, len(tokens), i, amt))
            continue
        # Fallback only if THIS line has no digits (true keyword-only line).
        if re.search(r"\d", line):
            continue
        for j in range(i + 1, min(i + 3, len(lines))):
            nxt = lines[j].strip()
            if not nxt:
                continue
            t2 = MONEY_RE.findall(nxt)
            if t2:
                amt = parse_money(t2[-1])
                if amt is not None:
                    candidates.append((pri_hit, 1, len(t2), i, amt))
            break
    return candidates


def pick_from_candidates(candidates):
    """Pick best candidate from one OCR pass."""
    if not candidates:
        return None
    # Sort key: priority asc, direct(0)<fallback(1), 1-token preferred, earliest line.
    def key(c):
        pri, is_fb, ntok, idx, _ = c
        return (pri, is_fb, 0 if ntok == 1 else 1, idx)
    candidates.sort(key=key)
    return candidates[0]


def extract_amount(texts):
    """Aggregate all candidates across OCR variants, then vote by preference tier."""
    all_cands = []
    for text in texts:
        all_cands.extend(find_candidates_in_text(text))
    if not all_cands:
        return None
    # Prefer direct hits over fallback hits even across priorities:
    # best priority is chosen from direct hits if any exist.
    direct = [c for c in all_cands if c[1] == 0]
    if direct:
        best_pri = min(c[0] for c in direct)
        pool_cands = [c for c in direct if c[0] == best_pri]
    else:
        best_pri = min(c[0] for c in all_cands)
        pool_cands = [c for c in all_cands if c[0] == best_pri]
    one_tok = [c for c in pool_cands if c[2] == 1]
    pool = one_tok if one_tok else pool_cands
    return Counter(c[4] for c in pool).most_common(1)[0][0]


# ----- date extraction -----

DATE_PATTERNS = [
    (re.compile(r"\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b"), "dmy"),
    (re.compile(r"\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b"), "ymd"),
    (re.compile(r"\b(\d{1,2})[-/](\d{1,2})[-/](\d{2})\b"), "dmy2"),
    (re.compile(r"\b(\d{1,2})[-\s/]([A-Za-z]{3,9})[-\s/](\d{2,4})\b"), "dMy"),
    (re.compile(r"\b([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{2,4})\b"), "Mdy"),
]

MONTH_MAP = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "SEPT": 9, "OCT": 10, "NOV": 11, "DEC": 12,
    "JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4, "JUNE": 6,
    "JULY": 7, "AUGUST": 8, "SEPTEMBER": 9, "OCTOBER": 10, "NOVEMBER": 11,
    "DECEMBER": 12,
}


def try_build_date(y, m, d):
    try:
        y, m, d = int(y), int(m), int(d)
    except (TypeError, ValueError):
        return None
    if y < 100:
        y += 2000 if y < 70 else 1900
    if not (1 <= m <= 12 and 1 <= d <= 31 and 1990 <= y <= 2099):
        return None
    try:
        return datetime(y, m, d).strftime("%Y-%m-%d")
    except ValueError:
        return None


def extract_date(texts):
    candidates = []
    for text in texts:
        for pattern, kind in DATE_PATTERNS:
            for m in pattern.finditer(text):
                g = m.groups()
                iso, score = None, 0
                if kind == "dmy":
                    iso = try_build_date(g[2], g[1], g[0]); score = 3
                elif kind == "ymd":
                    iso = try_build_date(g[0], g[1], g[2]); score = 3
                elif kind == "dmy2":
                    iso = try_build_date(g[2], g[1], g[0]); score = 1
                elif kind == "dMy":
                    mon = MONTH_MAP.get(g[1].upper())
                    if mon:
                        iso = try_build_date(g[2], mon, g[0]); score = 3
                elif kind == "Mdy":
                    mon = MONTH_MAP.get(g[0].upper())
                    if mon:
                        iso = try_build_date(g[2], mon, g[1]); score = 3
                if iso:
                    candidates.append((score, iso))
    if not candidates:
        return None
    best = max(s for s, _ in candidates)
    pool = [iso for s, iso in candidates if s == best]
    return Counter(pool).most_common(1)[0][0]


def process_image(path):
    img = Image.open(path)
    texts = ocr_texts(img)
    date_iso = extract_date(texts)
    amount = extract_amount(texts)
    amount_str = None
    if amount is not None:
        q = amount.quantize(Decimal("0.01"))
        amount_str = f"{q:.2f}"
    return date_iso, amount_str


def main():
    rows = []
    for fname in sorted(os.listdir(IMG_DIR)):
        path = IMG_DIR / fname
        try:
            date_iso, amount_str = process_image(path)
        except Exception as e:
            print(f"[{fname}] ERROR: {e}")
            date_iso, amount_str = None, None
        print(f"{fname}: date={date_iso} total={amount_str}")
        rows.append((fname, date_iso, amount_str))

    wb = Workbook()
    ws = wb.active
    ws.title = "results"
    ws.append(["filename", "date", "total_amount"])
    for r in rows:
        ws.append(list(r))
    wb.save(OUT_XLSX)
    print(f"\nWrote {OUT_XLSX}")


if __name__ == "__main__":
    main()
