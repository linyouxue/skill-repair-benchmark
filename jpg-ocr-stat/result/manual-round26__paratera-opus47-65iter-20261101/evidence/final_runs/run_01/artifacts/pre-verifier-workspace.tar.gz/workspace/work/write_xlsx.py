"""Write final results to /app/workspace/stat_ocr.xlsx.

Applies verified Branch A date corrections before writing.
"""
import json
from pathlib import Path

from openpyxl import Workbook

import parse_ocr3


# Branch A visual-inspection overrides. Each entry: (filename, iso_date, note).
# Recorded after actually viewing the receipt's date crop and comparing the
# ambiguous digit against unambiguous same-font digits on the same receipt.
DATE_OVERRIDES = {
    # OCR voted 2018-08-09 (6 votes) vs 2018-03-09 (4 votes). Crop at
    # 034_date_crop.png shows "Date: 09/03/2018" with the month glyph as a
    # 3 (two right-opening lobes, open on the left). The time "08:49:00" on
    # the next line provides the same-font 8 for comparison and is distinct.
    "034.jpg": "2018-03-09",
}


def main():
    raw = json.loads(Path("/app/workspace/work/ocr_raw.json").read_text())
    rows = []
    for fname in sorted(raw.keys()):
        variants = raw[fname]
        texts = list(variants.values())
        date = parse_ocr3.best_date_across_variants(texts)
        if fname in DATE_OVERRIDES:
            date = DATE_OVERRIDES[fname]
        total_tok = parse_ocr3.best_total_across_variants(texts)
        total = parse_ocr3.format_money(total_tok) if total_tok else None
        rows.append((fname, date, total))
        print(f"{fname}: date={date} total={total}")

    wb = Workbook()
    ws = wb.active
    ws.title = "results"
    ws.append(["filename", "date", "total_amount"])
    for fname, date, total in rows:
        ws.append([fname, date, total])
    out_path = "/app/workspace/stat_ocr.xlsx"
    wb.save(out_path)
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
