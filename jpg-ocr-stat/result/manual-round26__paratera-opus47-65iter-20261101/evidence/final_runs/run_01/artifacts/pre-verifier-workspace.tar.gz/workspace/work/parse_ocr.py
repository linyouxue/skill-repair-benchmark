"""Parse OCR results to extract date and total_amount per receipt.

Priority order for total amount keywords (most specific first):
  1. GRAND TOTAL
  2. TOTAL RM / TOTAL: RM
  3. TOTAL AMOUNT
  4. TOTAL / AMOUNT / TOTAL DUE / AMOUNT DUE / BALANCE DUE / NETT TOTAL / NET TOTAL

Exclusion keywords (lines skipped): SUBTOTAL, SUB TOTAL, TAX, GST, SST,
DISCOUNT, CHANGE, CASH TENDERED.

Fallback: when the keyword line itself has no numeric amount, use the last
number on the next line.
"""
import json
import re
from collections import Counter
from decimal import Decimal
from pathlib import Path


# Priority tiers. Lower index = higher priority.
TOTAL_KEYWORD_TIERS = [
    [r"GRAND\s*TOTAL"],
    [r"TOTAL\s*RM", r"TOTAL\s*:\s*RM"],
    [r"TOTAL\s*AMOUNT"],
    [
        r"TOTAL\s*DUE",
        r"AMOUNT\s*DUE",
        r"BALANCE\s*DUE",
        r"NETT?\s*TOTAL",
        r"\bTOTAL\b",
        r"\bAMOUNT\b",
    ],
]

EXCLUSION_PATTERNS = [
    r"SUB\s*TOTAL",
    r"SUBTOTAL",
    r"\bTAX\b",
    r"\bGST\b",
    r"\bSST\b",
    r"DISCOUNT",
    r"CHANGE",
    r"CASH\s*TENDERED",
    r"ROUND",  # rounding adjustment lines carry small deltas, not the total
]

# Monetary token: optional sign, with required 2-decimal fraction.
MONEY_RE = re.compile(r"(?<![\d.])([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2})(?!\d)")


def is_excluded(line_upper):
    return any(re.search(p, line_upper) for p in EXCLUSION_PATTERNS)


def find_moneys(text):
    return MONEY_RE.findall(text)


def normalize_money(tok):
    return Decimal(tok.replace(",", ""))


def pick_total_from_text(text):
    """Return list of candidate (priority, value_str, line) found in text.

    Priority is an int (0 = highest). Also handles the next-line fallback.
    """
    lines = [ln.rstrip() for ln in text.splitlines()]
    candidates = []
    for i, line in enumerate(lines):
        upper = line.upper()
        if is_excluded(upper):
            continue
        for tier_idx, patterns in enumerate(TOTAL_KEYWORD_TIERS):
            for pat in patterns:
                if re.search(pat, upper):
                    moneys = find_moneys(line)
                    if moneys:
                        # Take the last monetary token on this line.
                        candidates.append((tier_idx, moneys[-1], line))
                    else:
                        # Fallback: look at next non-empty line, take last number.
                        for j in range(i + 1, min(i + 3, len(lines))):
                            nxt = lines[j]
                            nxt_upper = nxt.upper()
                            if not nxt.strip():
                                continue
                            if is_excluded(nxt_upper):
                                break
                            nxt_moneys = find_moneys(nxt)
                            if nxt_moneys:
                                candidates.append((tier_idx, nxt_moneys[-1], line + " || " + nxt))
                            break
                    break  # Only match first matching pattern in this tier for this line.
    return candidates


DATE_PATTERNS = [
    # DD/MM/YYYY or DD-MM-YYYY (with optional 2-digit year)
    re.compile(r"(?<!\d)(\d{1,2})[/-](\d{1,2})[/-](\d{2}|\d{4})(?!\d)"),
    # DD MMM YYYY (e.g., 25 JAN 2019)
    re.compile(
        r"(?<!\w)(\d{1,2})[ -]"
        r"(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[A-Z]*"
        r"[ -](\d{2}|\d{4})(?!\w)",
        re.IGNORECASE,
    ),
    # YYYY-MM-DD
    re.compile(r"(?<!\d)(\d{4})-(\d{1,2})-(\d{1,2})(?!\d)"),
]

MONTH_MAP = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
}


def iso_from_match(pat_idx, m):
    """Return ISO date string or None if clearly invalid."""
    try:
        if pat_idx == 0:
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if len(m.group(3)) == 2:
                y += 2000 if y < 70 else 1900
            if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
        elif pat_idx == 1:
            d = int(m.group(1))
            mo = MONTH_MAP[m.group(2).upper()[:3]]
            y = int(m.group(3))
            if len(m.group(3)) == 2:
                y += 2000 if y < 70 else 1900
            if not (1 <= d <= 31 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
        elif pat_idx == 2:
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
    except (ValueError, KeyError):
        return None
    return None


def pick_date_from_text(text):
    """Return list of ISO dates found in text in order of appearance."""
    found = []
    for pat_idx, pat in enumerate(DATE_PATTERNS):
        for m in pat.finditer(text):
            iso = iso_from_match(pat_idx, m)
            if iso:
                found.append(iso)
    return found


def best_total_across_variants(variant_texts):
    """Vote across OCR variants for the best total amount.

    Strategy: collect candidates from every variant with their priority tier.
    Among candidates at the top (lowest) tier, pick the most frequent value
    (with ties broken by the one appearing first).
    """
    all_candidates = []
    for text in variant_texts:
        all_candidates.extend(pick_total_from_text(text))
    if not all_candidates:
        return None
    best_tier = min(c[0] for c in all_candidates)
    top = [c for c in all_candidates if c[0] == best_tier]
    counts = Counter(c[1] for c in top)
    # Return the mode value (most frequent). On tie, pick largest Decimal
    # (final totals are usually >= sub-items like rounding) -- but we already
    # filter out rounding/sub lines above, so mode suffices.
    best_val, _ = counts.most_common(1)[0]
    return best_val


def best_date_across_variants(variant_texts):
    counts = Counter()
    for text in variant_texts:
        for d in pick_date_from_text(text):
            counts[d] += 1
    if not counts:
        return None
    # Most frequent date wins.
    return counts.most_common(1)[0][0]


def format_money(tok):
    """Normalize monetary string to 'X.YY' (strip commas, keep 2 decimals)."""
    d = normalize_money(tok)
    # Always 2 decimals.
    return f"{d:.2f}"


def main():
    raw = json.loads(Path("/app/workspace/work/ocr_raw.json").read_text())
    results = {}
    for fname, variants in raw.items():
        texts = list(variants.values())
        date = best_date_across_variants(texts)
        total_tok = best_total_across_variants(texts)
        total = format_money(total_tok) if total_tok else None
        results[fname] = {"date": date, "total_amount": total}
        print(f"{fname}: date={date} total={total}")
    Path("/app/workspace/work/parsed.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
