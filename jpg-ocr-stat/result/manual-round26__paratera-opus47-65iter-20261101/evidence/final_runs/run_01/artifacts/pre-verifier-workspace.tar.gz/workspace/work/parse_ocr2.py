"""Parse OCR results to extract date and total_amount per receipt.

Priority order for total amount keywords (most specific first):
  tier 0: GRAND TOTAL
  tier 1: TOTAL RM / TOTAL: RM
  tier 2: TOTAL AMOUNT
  tier 3: TOTAL / AMOUNT / TOTAL DUE / AMOUNT DUE / BALANCE DUE / NETT TOTAL / NET TOTAL

Exclusion keywords (lines skipped): SUBTOTAL, SUB TOTAL, TAX, GST, SST,
DISCOUNT, CHANGE, CASH TENDERED.

Fallback: when the keyword line itself has no numeric amount, use the last
number on the next non-empty line, unless the keyword line is a column header.
"""
import json
import re
from collections import Counter
from decimal import Decimal
from pathlib import Path


TOTAL_KEYWORD_TIERS = [
    [r"GRAND\s*TOTAL"],
    [r"TOTAL\s*:?\s*RM"],
    [r"TOTAL\s*AMOUNT"],
    [
        r"TOTAL\s*DUE",
        r"AMOUNT\s*DUE",
        r"BALANCE\s*DUE",
        r"NETT?\s*TOTAL",
        r"\bTOTAL\b",
        r"\bAMOUNT\b",
    ],
]

EXCLUSION_PATTERNS = [
    r"SUB\s*TOTAL",
    r"SUBTOTAL",
    r"\bTAX\b",
    r"\bGST\b",
    r"\bSST\b",
    r"DISCOUNT",
    r"CHANGE",
    r"CASH\s*TENDERED",
]

# Column header words -- when present alongside TOTAL, treat as header row and
# do not use next-line fallback.
HEADER_WORDS = [r"\bQTY\b", r"\bITEM\b", r"DESCRIPTION", r"\bDESC\b",
                r"\bPRICE\b", r"U\.?PRICE"]

MONEY_RE = re.compile(r"(?<![\d.])([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2})(?!\d)")
# Secondary European-style: `XX,YY` with exactly 2 trailing digits, no 3-digit
# grouping. Repair to `XX.YY`.
EURO_MONEY_RE = re.compile(r"(?<![\d.,])(\d+),(\d{2})(?!\d)")


def is_excluded(line_upper):
    return any(re.search(p, line_upper) for p in EXCLUSION_PATTERNS)


def is_column_header(line_upper):
    return any(re.search(p, line_upper) for p in HEADER_WORDS)


def find_moneys(text, repair_decimal=False):
    toks = MONEY_RE.findall(text)
    if repair_decimal:
        for m in EURO_MONEY_RE.finditer(text):
            toks.append(f"{m.group(1)}.{m.group(2)}")
    return toks


def normalize_money(tok):
    return Decimal(tok.replace(",", ""))


def pick_total_from_text(text):
    """Return list of (tier, is_fallback, value_str, line) candidates.

    `is_fallback` is True when the amount came from a subsequent line.
    """
    lines = [ln.rstrip() for ln in text.splitlines()]
    candidates = []
    for i, line in enumerate(lines):
        upper = line.upper()
        if is_excluded(upper):
            continue
        for tier_idx, patterns in enumerate(TOTAL_KEYWORD_TIERS):
            matched = False
            for pat in patterns:
                if re.search(pat, upper):
                    matched = True
                    break
            if not matched:
                continue
            # Prefer standard money token on same line; also try repair.
            moneys = find_moneys(line, repair_decimal=True)
            if moneys:
                candidates.append((tier_idx, False, moneys[-1], line))
            elif not is_column_header(upper):
                # Fallback: scan next non-empty, non-excluded line.
                for j in range(i + 1, min(i + 3, len(lines))):
                    nxt = lines[j]
                    nxt_upper = nxt.upper()
                    if not nxt.strip():
                        continue
                    if is_excluded(nxt_upper):
                        break
                    nxt_moneys = find_moneys(nxt, repair_decimal=True)
                    if nxt_moneys:
                        candidates.append(
                            (tier_idx, True, nxt_moneys[-1], line + " || " + nxt)
                        )
                    break
            break  # Only process the first matching tier per line.
    return candidates


DATE_PATTERNS = [
    re.compile(r"(?<!\d)(\d{1,2})[/-](\d{1,2})[/-](\d{2}|\d{4})(?!\d)"),
    re.compile(
        r"(?<!\w)(\d{1,2})[ -]"
        r"(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[A-Z]*"
        r"[ -](\d{2}|\d{4})(?!\w)",
        re.IGNORECASE,
    ),
    re.compile(r"(?<!\d)(\d{4})-(\d{1,2})-(\d{1,2})(?!\d)"),
]

MONTH_MAP = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
}


def iso_from_match(pat_idx, m):
    try:
        if pat_idx == 0:
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if len(m.group(3)) == 2:
                y += 2000 if y < 70 else 1900
            if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
        elif pat_idx == 1:
            d = int(m.group(1))
            mo = MONTH_MAP[m.group(2).upper()[:3]]
            y = int(m.group(3))
            if len(m.group(3)) == 2:
                y += 2000 if y < 70 else 1900
            if not (1 <= d <= 31 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
        elif pat_idx == 2:
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
    except (ValueError, KeyError):
        return None
    return None


def pick_date_from_text(text):
    found = []
    for pat_idx, pat in enumerate(DATE_PATTERNS):
        for m in pat.finditer(text):
            iso = iso_from_match(pat_idx, m)
            if iso:
                found.append(iso)
    return found


def best_total_across_variants(variant_texts):
    """Pick best total using tier > same-line-preference > frequency voting."""
    all_candidates = []
    for text in variant_texts:
        all_candidates.extend(pick_total_from_text(text))
    if not all_candidates:
        return None
    best_tier = min(c[0] for c in all_candidates)
    tier_cands = [c for c in all_candidates if c[0] == best_tier]
    same_line = [c for c in tier_cands if not c[1]]
    pool = same_line if same_line else tier_cands
    counts = Counter(c[2] for c in pool)
    best_val, _ = counts.most_common(1)[0]
    return best_val


def best_date_across_variants(variant_texts):
    counts = Counter()
    for text in variant_texts:
        for d in pick_date_from_text(text):
            counts[d] += 1
    if not counts:
        return None
    return counts.most_common(1)[0][0]


def format_money(tok):
    d = normalize_money(tok)
    return f"{d:.2f}"


def main():
    raw = json.loads(Path("/app/workspace/work/ocr_raw.json").read_text())
    results = {}
    for fname, variants in raw.items():
        texts = list(variants.values())
        date = best_date_across_variants(texts)
        total_tok = best_total_across_variants(texts)
        total = format_money(total_tok) if total_tok else None
        results[fname] = {"date": date, "total_amount": total}
        print(f"{fname}: date={date} total={total}")
    Path("/app/workspace/work/parsed.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
