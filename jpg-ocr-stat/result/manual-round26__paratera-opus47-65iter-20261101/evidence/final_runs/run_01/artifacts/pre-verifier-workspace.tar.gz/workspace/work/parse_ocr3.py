"""Parse OCR results to extract date and total_amount per receipt."""
import json
import re
from collections import Counter
from decimal import Decimal
from pathlib import Path


# Priority tiers for TOTAL keywords. Lower tier index = higher priority.
TOTAL_KEYWORD_TIERS = [
    [r"GRAND\s*TOTAL"],
    [r"TOTAL\s*:?\s*RM"],
    [r"TOTAL\s*AMOUNT"],
    [
        r"TOTAL\s*DUE",
        r"AMOUNT\s*DUE",
        r"BALANCE\s*DUE",
        r"NETT?\s*TOTAL",
        r"\bTOTAL\b",
        r"\bAMOUNT\b",
    ],
]

# Lines whose leftmost keyword match is one of these are skipped.
# Note: SUB-TOTAL uses an optional dash. EXCL(uding) marks pre-tax amounts.
EXCLUSION_PATTERNS = [
    r"SUB[-\s]*TOTAL",
    r"\bTAX\b",
    r"\bGST\b",
    r"\bSST\b",
    r"DISCOUNT",
    r"CHANGE",
    r"CASH\s*TENDERED",
    r"\bEXCL",  # Excluding / Excl. of GST = pre-tax subtotal
]

# Column header words -- skip next-line fallback on these.
HEADER_WORDS = [r"\bQTY\b", r"\bITEM\b", r"DESCRIPTION", r"\bDESC\b",
                r"\bPRICE\b", r"U\.?PRICE"]

MONEY_RE = re.compile(r"(?<![\d.])([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2})(?!\d)")
DIGIT_RE = re.compile(r"\d")

# A "clean total" line is TOTAL (optionally NETT/GRAND prefix) directly
# followed by the amount, with no other descriptive words in between.
# Allows "TOTAL: 23.25" / "Total  20.00" / "Grand Total : RM 15.00" but
# rejects "Total (Inclusive of GST): 23.26" or "Total Sales Incl GST 17.70".
CLEAN_TOTAL_RE = re.compile(
    r"^\s*(?:GRAND\s+|NETT?\s+)?TOTAL\s*[:.\-]*\s*(?:RM\s*)?"
    r"[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2}\s*[.\-]*\s*$",
    re.IGNORECASE,
)


def _leftmost(line_upper, patterns):
    """Return (pos, pat) for the leftmost regex match from `patterns`."""
    best = None
    for pat in patterns:
        m = re.search(pat, line_upper)
        if m:
            if best is None or m.start() < best[0]:
                best = (m.start(), pat)
    return best


def classify_line(line):
    """Return (kind, tier) or (None, None).

    kind: 'exclude' | 'priority' | None
    """
    upper = line.upper()
    excl = _leftmost(upper, EXCLUSION_PATTERNS)
    pri_best = None  # (pos, tier)
    for tier_idx, patterns in enumerate(TOTAL_KEYWORD_TIERS):
        m = _leftmost(upper, patterns)
        if m is None:
            continue
        if pri_best is None or m[0] < pri_best[0]:
            pri_best = (m[0], tier_idx)
    if excl is None and pri_best is None:
        return (None, None)
    if excl is None:
        return ("priority", pri_best[1])
    if pri_best is None:
        return ("exclude", None)
    # Both present -> whichever starts earlier wins.
    if excl[0] < pri_best[0]:
        return ("exclude", None)
    return ("priority", pri_best[1])


def is_column_header(line_upper):
    return any(re.search(p, line_upper) for p in HEADER_WORDS)


def find_moneys(text):
    return MONEY_RE.findall(text)


def pick_total_from_text(text):
    """Return list of (tier, is_fallback, value_str, line, position, is_clean).

    `is_clean` is True when the keyword line looks like a bare "TOTAL amount"
    without additional descriptors (GST, Sales, Rounded, Inclusive, etc.).
    """
    lines = [ln.rstrip() for ln in text.splitlines()]
    candidates = []
    for i, line in enumerate(lines):
        kind, tier = classify_line(line)
        if kind != "priority":
            continue
        moneys = find_moneys(line)
        if len(moneys) >= 2:
            # Likely a tax-summary row ("Total 16.71 0.99"). Skip.
            continue
        if moneys:
            clean = bool(CLEAN_TOTAL_RE.match(line))
            candidates.append((tier, False, moneys[0], line, i, clean))
        else:
            # Fallback only if the keyword line has no digits at all and
            # it is not a column header.
            if DIGIT_RE.search(line):
                continue
            if is_column_header(line.upper()):
                continue
            for j in range(i + 1, min(i + 3, len(lines))):
                nxt = lines[j]
                if not nxt.strip():
                    continue
                nxt_kind, _ = classify_line(nxt)
                if nxt_kind == "exclude":
                    break
                nxt_moneys = find_moneys(nxt)
                if nxt_moneys:
                    candidates.append(
                        (tier, True, nxt_moneys[-1], line + " || " + nxt, i, False)
                    )
                break
    return candidates


DATE_PATTERNS = [
    re.compile(r"(?<!\d)(\d{1,2})[/-](\d{1,2})[/-](\d{2}|\d{4})(?!\d)"),
    re.compile(
        r"(?<!\w)(\d{1,2})[ -]"
        r"(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[A-Z]*"
        r"[ -](\d{2}|\d{4})(?!\w)",
        re.IGNORECASE,
    ),
    re.compile(r"(?<!\d)(\d{4})-(\d{1,2})-(\d{1,2})(?!\d)"),
]

MONTH_MAP = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
}


def iso_from_match(pat_idx, m):
    try:
        if pat_idx == 0:
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if len(m.group(3)) == 2:
                y += 2000 if y < 70 else 1900
            if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
        elif pat_idx == 1:
            d = int(m.group(1))
            mo = MONTH_MAP[m.group(2).upper()[:3]]
            y = int(m.group(3))
            if len(m.group(3)) == 2:
                y += 2000 if y < 70 else 1900
            if not (1 <= d <= 31 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
        elif pat_idx == 2:
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2099):
                return None
            return f"{y:04d}-{mo:02d}-{d:02d}"
    except (ValueError, KeyError):
        return None
    return None


def pick_date_from_text(text):
    found = []
    for pat_idx, pat in enumerate(DATE_PATTERNS):
        for m in pat.finditer(text):
            iso = iso_from_match(pat_idx, m)
            if iso:
                found.append(iso)
    return found


def best_total_across_variants(variant_texts):
    """Pick best total.

    Preference order:
      1. Lowest keyword tier (GRAND TOTAL > TOTAL RM > TOTAL AMOUNT > TOTAL)
      2. Clean-TOTAL lines over modified-TOTAL lines (within the same tier)
      3. Same-line amount over next-line fallback
      4. Frequency vote across OCR variants
      5. Text-corroboration (same value appearing elsewhere) as tiebreaker
      6. Positional-last within the receipt as final tiebreaker
    """
    all_candidates = []
    for text in variant_texts:
        all_candidates.extend(pick_total_from_text(text))
    if not all_candidates:
        return None
    best_tier = min(c[0] for c in all_candidates)
    tier_cands = [c for c in all_candidates if c[0] == best_tier]
    # Clean-TOTAL preference only kicks in at generic tier (tier >= 3).
    if best_tier >= 3:
        clean_cands = [c for c in tier_cands if c[5]]
        if clean_cands:
            tier_cands = clean_cands
    same_line = [c for c in tier_cands if not c[1]]
    pool = same_line if same_line else tier_cands
    counts = Counter(c[2] for c in pool)
    top_count = counts.most_common(1)[0][1]
    tied = [v for v, cnt in counts.items() if cnt == top_count]
    if len(tied) == 1:
        return tied[0]
    # Text-corroboration tiebreak: how many times value appears anywhere in
    # the raw text across variants (as a monetary token).
    corrob = Counter()
    for text in variant_texts:
        for tok in find_moneys(text):
            if tok in tied:
                corrob[tok] += 1
    if corrob:
        top_corrob = max(corrob.values())
        top_corrob_vals = [v for v, cnt in corrob.items() if cnt == top_corrob]
        if len(top_corrob_vals) == 1:
            return top_corrob_vals[0]
        tied = top_corrob_vals
    # Positional-last tiebreak: among tied values, pick the one whose
    # candidate most often appears latest in a variant that saw both.
    last_pos = {}
    for c in pool:
        if c[2] in tied:
            last_pos[c[2]] = max(last_pos.get(c[2], -1), c[4])
    return max(tied, key=lambda v: last_pos.get(v, -1))


def best_date_across_variants(variant_texts):
    counts = Counter()
    for text in variant_texts:
        for d in pick_date_from_text(text):
            counts[d] += 1
    if not counts:
        return None
    return counts.most_common(1)[0][0]


def format_money(tok):
    return f"{Decimal(tok.replace(',', '')):.2f}"


def main():
    raw = json.loads(Path("/app/workspace/work/ocr_raw.json").read_text())
    results = {}
    for fname, variants in raw.items():
        texts = list(variants.values())
        date = best_date_across_variants(texts)
        total_tok = best_total_across_variants(texts)
        total = format_money(total_tok) if total_tok else None
        results[fname] = {"date": date, "total_amount": total}
        print(f"{fname}: date={date} total={total}")
    Path("/app/workspace/work/parsed.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
