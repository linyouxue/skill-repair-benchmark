"""Extract raw OCR text (multi-variant) for each receipt and dump to JSON."""
import json
import os
from pathlib import Path

import pytesseract
from PIL import Image, ImageFilter, ImageOps


def multi_variants(path):
    img = Image.open(path)
    gray = ImageOps.grayscale(img)
    w, h = img.size
    variants = {
        "gray_auto": ImageOps.autocontrast(gray),
        "inverted": ImageOps.invert(ImageOps.autocontrast(gray)),
        "sharpen": gray.filter(ImageFilter.SHARPEN),
        "up3x": ImageOps.autocontrast(img.resize((w * 3, h * 3), Image.LANCZOS).convert("L")),
    }
    return variants


def ocr_image(path):
    variants = multi_variants(path)
    psm_modes = ["--psm 6", "--psm 4", "--psm 11"]
    results = {}
    for vname, vimg in variants.items():
        for psm in psm_modes:
            key = f"{vname}|{psm}"
            try:
                text = pytesseract.image_to_string(vimg, config=psm)
            except Exception as e:
                text = f"__ERROR__: {e}"
            results[key] = text
    return results


def main():
    img_dir = Path("/app/workspace/dataset/img")
    out_path = Path("/app/workspace/work/ocr_raw.json")
    out = {}
    for p in sorted(img_dir.iterdir()):
        if p.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
            continue
        print(f"OCR {p.name}")
        out[p.name] = ocr_image(p)
    out_path.write_text(json.dumps(out, indent=2))
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
