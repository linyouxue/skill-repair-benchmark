# Repository Notes

## Task: receipt OCR -> `/app/workspace/stat_ocr.xlsx`

Images live under `/app/workspace/dataset/img/` (22 Malaysian retail receipts,
`.jpg`). Final output: one sheet "results" with columns `filename`, `date` (ISO),
`total_amount` (string with exactly two decimals, or null), rows sorted by filename.

### Working files
- `work/ocr_extract.py` -- runs multi-variant Tesseract OCR (gray_auto, inverted,
  sharpen, 3x-upscaled) across PSM 6/4/11 and dumps `work/ocr_raw.json`.
- `work/parse_ocr3.py` -- date + total parsing library.
- `work/write_xlsx.py` -- composes final workbook, applies Branch A overrides.

### Key extraction logic (parse_ocr3)
- **Leftmost-match classification per line**: compute leftmost position of any
  exclusion keyword vs any priority keyword; whichever starts first wins. This
  avoids blanket exclusion of lines like "Total Sales Incl GST 17.70".
- **Priority tiers (lower = higher priority)**: 0 `GRAND TOTAL`, 1 `TOTAL(:)? RM`,
  2 `TOTAL AMOUNT`, 3 `TOTAL`/`AMOUNT`/`TOTAL DUE`/`AMOUNT DUE`/`BALANCE DUE`/
  `NET(T)? TOTAL`.
- **Exclusions**: `SUB[-\s]*TOTAL`, `\bTAX\b`, `\bGST\b`, `\bSST\b`, `DISCOUNT`,
  `CHANGE`, `CASH\s*TENDERED`, `\bEXCL` (Excluding/Excl. => pre-tax subtotal).
  `ROUND` is NOT excluded (so "Total Rounded" is kept).
- **Tax-summary skip**: any priority line with 2+ monetary tokens is dropped
  (e.g., "Total 16.71 0.99" in a GST summary table).
- **Fallback to next line**: only when the keyword line has NO digits at all,
  and is not a column header (QTY/ITEM/DESC/PRICE).
- **Within tier >=3, prefer "clean TOTAL" lines**: `^TOTAL ... amount$` with no
  descriptor between keyword and amount beats "Total (Inclusive of GST): X" etc.
  Needed for 077.jpg where TOTAL: 23.25 (post-rounding) beats Total (Inclusive
  of GST): 23.26.
- **Vote tiebreakers**: same-line > fallback; freq -> text-corroboration ->
  positional-last.

### Date handling
- Accept `DD/MM/YYYY`, `DD-MM-YYYY`, `DD MMM YYYY`, `YYYY-MM-DD`.
- Vote across variants.
- **Branch A override** required for 034.jpg: OCR voted `2018-08-09` (sharpening
  closed the `3`'s left opening into an `8`-like loop); the raw crop and the
  neighboring `Time: 08:49:00` line (same-font 8 for comparison) confirm the
  month is `03`. Correct date = `2018-03-09`.

### Known good spot-checks
Values verified by actually viewing the receipt images:
007 (20.00/2019-01-23), 009 (26.60/2018-01-18), 010 (14.10/2017-12-29),
011 (15.00/2017-06-15), 019 (86.00/2018-03-18), 034 (332.30/2018-03-09),
039 (189.75/2018-03-30), 063 (85.54/2018-02-26), 064 (88.17/2018-02-21),
069 (9.90/2018-02-20), 071 (17.70/2018-02-19), 074 (102.00/2018-03-20),
077 (23.25/2017-10-29), 078 (92.80/2017-02-02), 087 (538.00/2017-07-27),
088 (99.80/2017-08-09), 094 (5.90/2018-02-09).
